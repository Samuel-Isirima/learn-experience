<?php namespace SCS\Insights;

use Backend;
use System\Classes\PluginBase;

/**
 * Insights Plugin Information File
 */
class Plugin extends PluginBase
{
    /**
     * Returns information about this plugin.
     *
     * @return array
     */
    public function pluginDetails()
    {
        return [
            'name'        => 'Insights',
            'description' => 'Insights feature',
            'author'      => 'SCS',
            'icon'        => 'icon-exclamation'
        ];
    }

    /**
     * Register method, called when the plugin is first registered.
     *
     * @return void
     */
    public function register()
    {

    }

    /**
     * Boot method, called right before the request route.
     *
     * @return array
     */
    public function boot()
    {

    }

    /**
     * Registers any front-end components implemented in this plugin.
     *
     * @return array
     */
    public function registerComponents()
    {
        return [
            'SCS\Insights\Components\InsightsList' => 'insightsList',
        ];
    }

    /**
     * Registers any back-end permissions used by this plugin.
     *
     * @return array
     */
    public function registerPermissions()
    {
        return []; // Remove this line to activate

        return [
            'scs.insights.some_permission' => [
                'tab' => 'Insights',
                'label' => 'Some permission'
            ],
        ];
    }

    /**
     * Registers back-end navigation items for this plugin.
     *
     * @return array
     */
    public function registerNavigation()
    {
        return []; // Remove this line to activate

        return [
            'insights' => [
                'label'       => 'Insights',
                'url'         => Backend::url('scs/insights/mycontroller'),
                'icon'        => 'icon-exclamation',
                'permissions' => ['scs.insights.*'],
                'order'       => 500,
            ],
        ];
    }
}
