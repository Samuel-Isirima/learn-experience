(($) => {

  const carouselBreakpoints = (itemWidth, itemGap, widthStep, minScreen, maxScreen) => {
    const breakpoints = {};
    for (let screenWidth = minScreen; screenWidth <= maxScreen; screenWidth += widthStep) {
      const items = Math.max(1, Math.floor((screenWidth + itemGap) / (itemWidth + itemGap)));
      const stagePadding = Math.max(itemGap, (screenWidth - items * itemWidth + (items - 1) * itemGap) / 2);
      breakpoints[screenWidth] = {items, stagePadding};
    }
    return breakpoints;
  }

  const initCarousel = ($carousel, itemGap) => {
    $carousel.owlCarousel({
      autoplay: true,
      autoplayTimeout: 7000,
      autoplayHoverPause: true,
      lazyLoad: true,
      center: false,
      nav: true,
      dots: false,
      loop: false,
      margin: itemGap,
      mouseDrag: true,
      touchDrag: true,
      navText: [nextIcon, prevIcon],
      stagePadding: itemGap,
      responsiveClass: true,
      responsive: carouselBreakpoints(400, itemGap, itemGap * 2, 0, 2600)
    });
  };

  const initModalCarousel = ($carousel) => {
    $carousel.owlCarousel({
      autoplay: false,
      lazyLoad: true,
      center: false,
      nav: true,
      dots: false,
      loop: false,
      margin: 60,
      mouseDrag: true,
      touchDrag: true,
      navText: [nextIcon, prevIcon],
      stagePadding: 60,
      responsiveClass: true,
      responsive: {
        ...carouselBreakpoints(1000, 0, 40, 0, 768),
        ...carouselBreakpoints(1000, 20, 40, 769, 1100),
        ...carouselBreakpoints(1000, 60, 120, 1101, 2600),
      }
    });
  };

  const leagueFilterTemplate = (state) => {
    if (!state.id) return state.text;
    return $('<span><img src="' + state.element.dataset.icon + '"/> ' + state.text + '</span>');
  }

  $('.owl-carousel-insights').each((i, e) => {
    const $carousel = $(e);
    const $section = $carousel.closest('section');
    const $leagueFilter = $section.find('select.insights-league-filter');
    const $modal = $section.next('dialog.modal-insights');
    const $modalCarousel = $modal.find('.owl-carousel-modal-insights');
    const limit = 10;
    let playersInUse = [];
    let teamsInUse = [];

    let offset = 0;
    let request = '';

    const loadItems = () => {
      clearTimeout(loadMoreTimeout);
      if (request) return;
      if (offset > 50) return;

      if (offset === 0) {
        $section.addClass('loading');
      }

      const data = {
        offset: offset,
        limit: limit,
        league: $carousel.data('league') || $leagueFilter.val(),
        team: $carousel.data('team'),
        player: $carousel.data('player'),
        type: $carousel.data('type')
      };
      const r = JSON.stringify(data);
      request = r;

      console.log('[Insights Request]', data);
      $.request($carousel.data('url'), {

        data,
        success: (response) => {
          if (r !== request) {
            return;
          }
          request = '';
          $section.removeClass('loading');
          if (!response || !response.items || !response.items.length) {
            if (offset === 0) {
              $section.addClass('empty');
            }
            return;
          }
          console.log('[Insights Response]', response);
          var startTime = new Date(response.startTime);
          var endTime = new Date(response.endTime);
          console.log('[Insights Request] API started at ' + startTime.toISOString()
              + ' finished at ' + endTime.toISOString()
              + ' and took ' + response.took + ' ms');
          const filteredItems = filterItems(response.items);
          console.log('[Insights Filtered Items]', filteredItems);
          if (offset === 0) {
            $carousel.owlCarousel('destroy');
            $carousel.empty().append(filteredItems.map(item => item.main));
            $modalCarousel.owlCarousel('destroy');
            $modalCarousel.empty().append(filteredItems.map(item => initModalItem(item.modal)));
            initCarousel($carousel, data.type === 'player' ? 40 : 10);
            initModalCarousel($modalCarousel);
          } else {
            $(filteredItems).each((i, item) => {
              $carousel.owlCarousel('add', item.main);
              $modalCarousel.owlCarousel('add', initModalItem(item.modal));
            });
            $carousel.owlCarousel('update');
            $modalCarousel.owlCarousel('update');
          }
          offset += limit;
          loadMore();
        },
        error: (xhr, status, error) => {
          request = '';
          console.error(error);
        }
      });
    };

    const filterItems = (items) => {
      const result = [];
      $(items).each((i, item) => {
        if (playersInUse.indexOf(item.playerId) < 0) {
          if (teamsInUse.indexOf(item.teamId) < 0) {
            result.push(item);
            playersInUse.push(item.playerId);
            teamsInUse.push(item.teamId);
            //console.log('News with player processed', item.playerId);
          }
        }
      });
      return result;
    }

    let loadMoreTimeout = -1;
    const loadMore = () => {
      clearTimeout(loadMoreTimeout);
      loadMoreTimeout = setTimeout(loadItems, 50 * 1000);
    };

    const openModal = () => {
      $modal.addClass('open animating');
      $('body').addClass('modal-open');
      setTimeout(() => $modal.removeClass('animating'), 400);
    }

    const initModalItem = (item) => {
      const $item = $(item);
      const $button = $item.find('.share-links-button');
      const $popover = $item.find('[id^="share-popover-"]');
      $button.popover({
        trigger: 'manual',
        placement: 'top',
        html: true,
        content: function () {
          return $popover.html();
        },
      });
      $button.on('mouseover', (e) => {
        e.stopPropagation();
        if (!osdbst.mmSmall.matches) {
          $button.popover('show');
        }
      });
      $button.on('click', (e) => {
        e.stopPropagation();
        if (osdbst.mmSmall.matches) {
          $popover.removeClass("popover-hidden");
        } else {
          $button.popover("show");
        }
      });
      return $item;
    };

    const hidePopovers = () => {
      $modal.find('.share-links-button').popover('hide');
      $modal.find('[id^="share-popover-"]').addClass('popover-hidden');
    }

    $modal.on('click', '.socialsharelinks-dm-popover-content .inlinelist a', (e) => {
      hidePopovers();
    });
    $(document).on('pointerdown', (e) => {
      if ($(e.target).closest('.socialsharelinks-dm-popover-content').length > 0) {
        return;
      }
      hidePopovers();
    });
    $(window).on('resize', hidePopovers);

    $carousel.on('changed.owl.carousel', e => {
      if (e.property.name === 'position' && e.item.index + 2 * limit >= e.item.count) {
        loadItems();
      }
    });

    $carousel.on('click', '[data-insight]', function (e) {
      e.preventDefault();
      openModal();
      let $item = $(this).closest('.owl-item');
      let index = $item.index();
      $modalCarousel.trigger('to.owl.carousel', [index, 0]);
      return false;
    });

    $modalCarousel.on('click', 'button.close', function (e) {
      e.preventDefault();
      $modal.removeClass('open');
      $('body').removeClass('modal-open');
      $modal.trigger('modal.closed');
      return false;
    });

    $leagueFilter.on('change', () => {
      offset = 0;
      request = '';
      playersInUse = [];
      teamsInUse = [];
      $carousel.owlCarousel('destroy');
      $modalCarousel.owlCarousel('destroy');
      loadItems();
    });

    $leagueFilter.select2({
      templateResult: leagueFilterTemplate,
      templateSelection: leagueFilterTemplate,
      minimumResultsForSearch: -1,
      dropdownCssClass: 'insights-league-filter-dropdown'
    });

    if ($modalCarousel.find('.insights-item').length > 0) {
      initModalCarousel($modalCarousel);
      $modalCarousel.find('.insights-item').each((i, e) => initModalItem(e));
      openModal();
      $modal.on('modal.closed', () => {
        $modal.off('modal.closed');
        $modalCarousel.owlCarousel('destroy');
        loadItems();
      });
    } else {
      loadItems();
    }
  });

})(jQuery);
