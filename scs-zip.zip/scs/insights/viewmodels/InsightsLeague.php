<?php namespace SCS\Insights\ViewModels;

class InsightsLeague {

    function __construct($id, $slug)
    {
        $this->id = $id;
        $this->slug = $slug;
    }

    public $id;
    public $slug;
}