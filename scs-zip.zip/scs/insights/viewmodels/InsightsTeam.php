<?php namespace SCS\Insights\ViewModels;

use SCS\Osdb\Classes\ES\Teams;

class InsightsTeam {

    function __construct($id, $fullName)
    {
        $this->id = $id;
        $this->fullName = $fullName;
        $this->slug = str_slug($fullName);
    }

    public $id;
    public $fullName = null;
    public $slug = null;
    public $data = null;
};