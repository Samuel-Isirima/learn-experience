<?php namespace SCS\Insights\ViewModels;

use SCS\Osdb\Classes\ES\Players;

class InsightsPlayer {

    function __construct($id, $fullName)
    {
        $this->id = $id;
        $this->fullName = $fullName;
    }

    public $id;
    public $fullName = null;
    public $data = null;
}