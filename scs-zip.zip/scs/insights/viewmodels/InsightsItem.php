<?php namespace SCS\Insights\ViewModels;

use SCS\Osdb\Controllers\Seo;

class InsightsItem {

    function __construct($leagueSlug, $id, $typeId, $gameId, $team, $player, $posted, $text, $relevancyIndex
        // $insightTrigger,
        // $insightCategory,
        // $insightType,
        // $insightLifecycleKey
    )
    {
        $this->id = $id;
        $this->team = $team;
        $this->player = $player;
        $this->leagueSlug = $leagueSlug;
        $this->posted = $posted;
        $this->text = $text;

        $modelData = new \stdClass();
        $modelData->insightId = implode('|', [$leagueSlug, $id, $typeId, $gameId, $player->id]);
        $modelData->title = strlen($text) > 60 ? (substr($text,0,50) . '...') : $text;
        $modelData->excerpt = $text;
        $this->shareLinks = Seo::getShareLinks($modelData, 'insight');

        $this->relevancyIndex = $relevancyIndex;

        // $this->insightTrigger = $insightTrigger;
        // $this->insightCategory = $insightCategory;
        // $this->insightType = $insightType;
        // $this->insightLifecycleKey = $insightLifecycleKey;

    }

    public $id;
    public $player;
    public $team;
    public $leagueSlug;
    public $posted;
    public $text;
    public $shareLinks;
    public $relevancyIndex;
    // public $insightTrigger;
    // public $insightCategory;
    // public $insightType;
    // public $insightLifecycleKey;
}
