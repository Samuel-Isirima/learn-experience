<?php namespace SCS\Insights\Components;

use Cms\Classes\ComponentBase;
use DateTime;
use SCS\Insights\Classes\Services\InsightsService;
use SCS\Insights\ViewModels\InsightsItem;
use SCS\Insights\ViewModels\InsightsPlayer;
use SCS\Insights\ViewModels\InsightsTeam;
use SCS\Osdb\Classes\ES\Leagues;
use SCS\Osdb\Models\League;
use SCS\Osdb\Models\Player;

class InsightsList extends ComponentBase
{
    public $insights;
    public $insight;
    public $leagues;
    public $league;
    public $team;
    public $player;
    public $type;

    public function componentDetails()
    {
        return [
            'name' => 'InsightsList Component',
            'description' => 'No description provided yet...'
        ];
    }

    public function defineProperties()
    {
        return [
            'league' => [
                'title' => '(dynamic) League is set by URL of the page',
                'type' => 'string'
            ],
            'index' => [
                'title' => 'Page Index',
                'type' => 'string',
                'validationPattern' => '^[0-9]+$',
                'default' => '1',
            ],
            'pageSize' => [
                'title' => 'Items per page',
                'type' => 'string',
                'validationPattern' => '^[0-9]+$',
                'default' => '4',
            ],
        ];
    }

    public function onRun()
    {
        $this->addJs('assets/js/SCS.Insights.js');
    }

    public function onRender()
    {
        $this->league = $this->property('league');
        $this->team = $this->property('team');
        $this->player = $this->property('player');

        if ($this->player) {
            $this->type = 'player';
        } else if ($this->team) {
            $this->type = 'team';
        } else if ($this->league) {
            $this->type = 'league';
        } else {
            $this->type = 'home';
        }

        if ($this->type === 'home') {
            $this->leagues = League::all();
        }

        $insight = $_REQUEST['insight'] ?? null;
        if ($insight) {
            $insight = explode('|', $insight);
            if (count($insight) === 3) {
                list($league, $id, $type, $game, $player) = $insight;
                $this->insight = $this->loadInsight($league, $id, $type, $game, $player);
            }
        }
    }

    public function onLoad()
    {
        $type = $_REQUEST['type'] ?? "home";
        $limit = $_REQUEST['limit'] ?? 4;
        $offset = $_REQUEST['offset'] ?? 0;
        $league = $_REQUEST['league'] ?? null;
        $team = $_REQUEST['team'] ?? null;
        $player = $_REQUEST['player'] ?? null;

        $insights = [];

        switch ($type) {
            case 'home':
                if (empty($league)) {
                    $leagues = League::all();
                    $leagueLimit = intval(ceil($limit / count($leagues)));
                    $leagueOffset = intval(ceil($offset / count($leagues)));
                    foreach ($leagues as $l) {
                        if ($l->slug != 'mls') {
                            loadInsights($l->slug, $leagueLimit, $leagueOffset, $team, $player);
                            $insights = array_merge($insights, $leagueInsights);
                        }
                    }
                    /* RWC NOTE: can remove the sorting, does not seem nessary and should increase performance
                    // usort($insights, function ($a, $b) {
                        // return $b->posted->format('U') - $a->posted->format('U');
                        // // return $b->relevancyIndex - $a->relevancyIndex;
                    });
                    */
                    $insights = array_slice($insights, 0, $limit);
                    break;
                }
            case 'league':
            case 'team':
            case 'player':
                $insights = $this->loadInsights($league, $limit, $offset, $team, $player);
                break;
        }
        $this->insights = $insights;

        return [
            'items' => array_map(function ($insight) use ($type) {
                return [
                    'main' => $this->renderPartial('@insight', ['insight' => $insight, 'type' => $type]),
                    'modal' => $this->renderPartial('@insight', ['insight' => $insight, 'type' => 'modal']),
                    'playerId' => isset($insight->player) && isset($insight->player->id) ? $insight->player->id : null,
                    'teamId' => isset($insight->team) && isset($insight->team->id) ? $insight->team->id : null,
                    'gameId' => isset($insight->gameId) ? $insight->gameId : null,
                    'typeId' => isset($insight->typeId) ? $insight->typeId : null
                ];
            }, $insights->items),
            'startTime' => $insights->startTime,
            'endTime' => $insights->endTime,
            'took' => $insights->took,
        ];
    }

    private function mapInsight($items)
    {
        $players = [];
        $result = array_map(function ($item) use (&$players) {
            /*foreach ($item->subjects as $subject) {
                if ($subject->type && $subject->type->key == 'team') {
                    $team = new InsightsTeam($subject->subjectUsId);
                    $teamIds[] = $subject->subjectUsId;
                }
                if ($subject->type && $subject->type->key == 'player') {
                    $player = new InsightsPlayer($subject->subjectUsId);
                    $playerIds[] = $subject->subjectUsId;
                }
            }*/
            $players[] = ['id' => $item->event->participant_id];
            return new InsightsItem(
                $item->league,
                $item->id,
                $item->typeId,
                $item->event->game_id,
                new InsightsTeam($item->event->team_id, $item->event->team_name),
                new InsightsPlayer($item->event->participant_id, $item->event->participant_full_name),
                // RWC NOTE: using created_at instead of relevancyDate because relevancyDate is not as important
                new DateTime($item->createdAt), // new DateTime($item->relevancyDate),
                $item->content,
                $item->relevancyIndex
                // $item->event->insight_trigger,
                // $item->event->insight_category,
                // $item->event->insight_type,
                // $item->lifecycle->key
            );
        }, $items);

        // Add player data (only if we have headshot) and team data
        $players = Leagues::getPlayers(null, null, array_column($players, 'id'));
        $dbPlayers = Player::whereIn('guid', array_column($players, 'id'))->select('guid', 'custom_headshot', 'slug')->get()->all();
        $players = Leagues::addCustomHeadshotUrl($players, $dbPlayers);
        foreach ($result as $item) {
            $i = array_search($item->player->id, array_column($players, 'id'));
            if ($i !== false && (isset($players[$i]['custom_headshot_url']) || isset($players[$i]['headshot']) && isset($players[$i]['headshot']['high_res']))) {
                $item->player->data = [
                    'id' => $item->player->id,
                    'headshot' => isset($players[$i]['custom_headshot_url']) ? $players[$i]['custom_headshot_url'] : $players[$i]['headshot']['high_res'],
                    'full_name' => $item->player->fullName,
                    'team' => ['slug' => $item->team->slug, 'full_name' => $item->team->fullName]
                ];
            }
            $item->team->data = [
                'slug' => $item->team->slug,
                'full_name' => $item->team->fullName
            ];
        }
        return $result;
    }

    private function loadInsight($league, $id, $itype, $game, $player)
    {
        $response = InsightsService::instance()->getInsight($league, $id, $itype, $game, $player);
        if (!$response) return null;
        $results = $this->mapInsight([$response]);
        return $results[0];
    }

    private function loadInsights($league, $limit, $offset, $team, $player)
    {
        $response = InsightsService::instance()->getInsights($league, $limit, $offset, $team, $player);
        if (!isset($response->results)) return [];
        $items = $this->mapInsight($response->results);
        $result = new \stdClass();
        $result->items = $items;
        $result->startTime = $response->startTime;
        $result->endTime = $response->endTime;
        $result->took = $response->took;
        return $result;
    }
}
