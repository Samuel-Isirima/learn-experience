<?php namespace SCS\Insights\Classes\Services;

use function Sodium\add;
use Request;

class InsightsService {
    use \October\Rain\Support\Traits\Singleton;

    public $insightsUrl = 'https://api.radar360.sportradar.com/insights/v1/';
    public $insightsKey = 'jm3InzxkYa4WkUZXVtOrDAnA1raRGb';

    public function __construct()
    {
        //$this->region = env('AWS_REGION');``
    }

    // get insight by id (but as API can't filter by id we will filter by league, type, game and player and select one by id)
    public function getInsight($league, $id, $typeId, $gameId, $playerId)
    {
        try {
            $response = $this->insightsApiCall($league, 20, 0, null, $playerId, $gameId, $typeId);
            foreach ($response->results as $result) {
                /*
                types = highs, leaderboards, milestones, scoring
                insight_trigger = reaching,passing,closing_in,one_away
                insight_category = player
                timeframe_type = season, career
                lifecycle.key = pre_game, in_game, post_game
                */

                if ($result->id == $id) return $result;

            }
        } catch (\Exception $ex) {
            \Log::error('~~ Error: InsightsService->getInsight - exception:'. " [".$ex->getTraceAsString()."]");
        }
        return null;
    }

    public function getInsights($league, $pageSize = 4, $index = 0, $teamId = null, $playerId = null, $typeId = null, $gameId = null) {
        $result = null;
        try {
            $result = $this->insightsApiCall($league, $pageSize, $index, $teamId, $playerId, $gameId, $typeId);
        } catch (\Exception $ex) {
            \Log::error('~~ Error: InsightsService->getInsights - exception:'. " [".$ex->getTraceAsString()."]");
        }
        return $result;
    }

    private function insightsApiCall($league, $pageSize = 4, $index = 0, $teamId = null, $playerId = null, $gameId = null, $typeId = null)
    {
        try {
            $startTime = microtime(true);
            // set up query string parameters
            $url = $this->insightsUrl.$league . "?statuses=published&categories=media&relevancyIndex=90-100&index=$index&pageSize=$pageSize";
            if ($teamId) $url .= "&teamUsIds=$teamId";
            if ($playerId) $url .= "&playerUsIds=$playerId";
            if ($typeId) $url .= "&typeIds=$typeId";
            if ($gameId) $url .= "&gameUsIds=$gameId";

            // RWC NOTE: only need these from payload
            $url .= "&custom=id,league,typeId,content,event,createdAt,updatedAt,relevancyDate,relevancyIndex";

            // RWC NOTE: optional, filter by types
            // $url .= "&types=highs,leaderboards,milestones";

            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

            $requestHeaders = [];
            $requestHeaders[] = "Authorization: {$this->insightsKey}";

            curl_setopt($curl, CURLOPT_HTTPHEADER, $requestHeaders);

            // this function is called by curl for each header received
            $headers = [];
            curl_setopt($curl, CURLOPT_HEADERFUNCTION,
                function($curl, $header) use (&$headers)
                {
                    $len = strlen($header);
                    $header = explode(':', $header, 2);
                    if (count($header) < 2) // ignore invalid headers
                        return $len;

                    $name = strtolower(trim($header[0]));
                    if (!array_key_exists($name, $headers))
                        $headers[$name] = [trim($header[1])];
                    else
                        $headers[$name][] = trim($header[1]);

                    return $len;
                }
            );

            $response = curl_exec($curl);
            $result = json_decode($response, false, 512, JSON_BIGINT_AS_STRING);
            $endTime = microtime(true);
            $result->startTime = round($startTime * 1000);
            $result->endTime = round($endTime * 1000);
            $result->took = round(($endTime - $startTime) * 1000);


//            $jsonString = json_encode($result, JSON_PRETTY_PRINT);
//            $err = curl_error($curl);
//            $errmsg = curl_error($curl);
            $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

            if ($httpcode != 200) {
                $tmp = 1;
            }

            curl_close($curl);

        } catch (\Exception $ex) {
            \Log::error('~~ Error: InsightsService->getInsight - exception:'. " [".$ex->getTraceAsString()."]");
            $result = new \stdClass;
            $result->error = "Error: InsightsService->getInsight - exception " . $ex->getMessage();
        }
        return $result;
    }
}
