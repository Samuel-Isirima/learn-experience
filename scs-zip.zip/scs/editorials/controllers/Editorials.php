<?php namespace SCS\Editorials\Controllers;

use BackendMenu;
use Backend\Classes\Controller;
use RainLab\Blog\Models\Post;
use SCS\Osdb\Models\League;
use System\Helpers\DateTime as DateTimeHelper;
use SCS\Osdb\Models\Player;
use SCS\Osdb\Models\Team;
use DB;

/**
 * Editorials Back-end Controller
 */
class Editorials extends Controller
{
    /**
     * @var array Behaviors that are implemented by this controller.
     */
    public $implement = [
        'Backend.Behaviors.FormController',
        'Backend.Behaviors.ListController'
    ];

    /**
     * @var string Configuration file for the `FormController` behavior.
     */
    public $formConfig = 'config_form.yaml';

    /**
     * @var string Configuration file for the `ListController` behavior.
     */
    public $listConfig = 'config_list.yaml';

    public function __construct()
    {
        parent::__construct();

        BackendMenu::setContext('SCS.Editorials', 'editorials', 'editorials');
    }

    public static function getLeague($post)
    {
        foreach (League::all() as $league) {
            if ($post->tags->contains('slug', $league->slug)) {
                return $league->slug;
            }
        }
        return "";
    }

    /**
     * Convert pushish date to human readable
     *
     * @param object $post
     * @param integer $limitDays - number of days before showing just the date
     * @return string
     */
    public static function getAge($post, $limitDays = null)
    {
        if ($limitDays) {
            $limitHours = $limitDays * 86400;
            $publishDate = strtotime($post->published_at);
            $diff = abs($publishDate - time());
            if ($diff > $limitHours) {
                return date("F j, Y", $publishDate);
            } else {
                return DateTimeHelper::timeSince($post->published_at);
            }
        } else {
            return DateTimeHelper::timeSince($post->published_at);
        }
  
    }

    public static function isOSDBCategory($post)
    {
        if ($post->categories->contains('slug', 'osdb')) {
            return true;
        } else {
            return false;
        }
    }

    public static function getAuthorSummary($post)
    {
        $post->source = "FROM";
        if ($post->isOSDBCategory) {
            $post->source = "OSDB";
        } else if ($post->article) {
            if ($post->article->source) {
                $post->source = $post->article->source;
            }
            $post->source = "";
        }

        if ($post->article) {
            if ($post->article->author) {
                if ($post->source) {
                    return "FROM " . $post->source .
                    "By " . $post->article->author .
                    "  |  Posted " . Editorials::getAge($post, 1)
                    //$post->published_at->format('M j, Y')
                    ;
                } else {
                    return
                    "By " . $post->article->author .
                    "  |  Posted " . Editorials::getAge($post, 1)
                    //$post->published_at->format('M j, Y')
                    ;
                }
            }
        }
        return "";
    }

    /**
     * @param Post $post
     */
    public static function addPostData($post)
    {
        $post->league = Editorials::getLeague($post);
        $post->age = Editorials::getAge($post, 1);
        $post->isOSDBCategory = Editorials::isOSDBCategory($post);
        $post->author = Editorials::getAuthorSummary($post);
        $post->share_links = \SCS\Osdb\Controllers\Seo::getShareLinks($post, 'editorial');
    }

    public static function getEditorialTagslug($tag):string{
        $url = url('/').'/';
        $tag = trim($tag->name);
        $searchTag = urlencode($tag);
        $maincat = [];
        foreach(League::all('name')->toArray()??[] as $leag )
            $maincat[] = $leag['name'];
        
        if(in_array($tag, $maincat)){
            $url .= strtolower($tag);
        }else{
            $teamPlayerSlug = DB::table('ginopane_blogtaxonomy_tags')->where('name',$tag)->first('slug');
            $players = Player::where('name',$tag)->get();
            if(count($players)>0){
                if(count($players)==1){
                    foreach($players as $player){
                        foreach($player->contracts as $con){
                            if($con['active']==1){
                                $team_slug = $con['team_slug'];
                                $team_slug_ar = explode('/', $team_slug);
                                if(count($team_slug_ar)>0){
                                    $url .= $team_slug_ar[0].'/players/'.$teamPlayerSlug->slug.'/'.$player->guid;
                                }else{
                                    $url .= 'search-results?q='.$searchTag;
                                }
                                break;
                            }
                        }
                    }
                }else{
                    $url .= 'search-results?q='.$searchTag;
                }
            }else{
                $teams = Team::where('slug',$teamPlayerSlug->slug)->get();
                if(count($teams)>0){
                    if(count($teams)==1){
                        foreach($teams as $team){
                            $url .= $team->league->slug.'/'.$team->slug;
                        }
                    }else{
                        $url .= 'search-results?q='.$searchTag;
                    }

                }else{
                    $url .= 'search-results?q='.$searchTag;
                }
            }
        }
        return $url;
    }
}
