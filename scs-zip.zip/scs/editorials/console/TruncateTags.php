<?php namespace SCS\Editorials\Console;

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;
use DB;
use Storage;
use Route;

/**
 *
 *  run from CLI `$> php artisan editorials:truncate-tags`
 */

class TruncateTags extends Command
{
    protected $name = 'editorials:truncate-tags';

    protected $description = 'truncate (reset) all tags in `ginopane_blogtaxonomy_tags`';

    public function handle()
    {
        $this->output->writeln('*** removing all Tags ***');

        if ($this->confirm('Do you wish to continue?'))
        {
            Route::get('/clear-cache', function() {
                $exitCode = Artisan::call('config:cache');
                return '    ==> Cache recreated!';
            });

            $tags =  DB::table('ginopane_blogtaxonomy_tags')->get();
            if (count($tags) > 0) {
                $now = date('Y-m-d_Hi');

                /*      !! yikes! !!   */
                DB::select('SET FOREIGN_KEY_CHECKS = 0;');

                Storage::disk('local')->put('Tags-'.$now.'.json', $tags);
                DB::table('ginopane_blogtaxonomy_tags')->truncate();

                /*      !! yikes! !!   */
                DB::select('SET FOREIGN_KEY_CHECKS = 1;');

                $this->output->writeln('    ==> DONE! Tag backup stored in `/storage/app`');
            } else {
                $this->output->writeln('    ==> table already empty');
            }

        }
    }
}
