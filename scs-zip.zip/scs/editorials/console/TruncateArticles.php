<?php namespace SCS\Editorials\Console;

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;
use DB;
use Storage;
use Route;

/**
 *
 *  run from CLI `$> php artisan editorials:truncate-articles`
 */

class TruncateArticles extends Command
{
    protected $name = 'editorials:truncate-articles';

    protected $description = 'truncate (reset) all articles in `scs_newsapi_articles`';

    public function handle()
    {
        $this->output->writeln('*** removing all Article ***');

        if ($this->confirm('Do you wish to continue?'))
        {
            Route::get('/clear-cache', function() {
                $exitCode = Artisan::call('config:cache');
                return '    ==> Cache recreated!';
            });

            $articleBackup = \SCS\NewsAPI\Models\Article::all();
            if (count($articleBackup) > 0) {
                $now = date('Y-m-d_Hi');
                Storage::disk('local')->put('Articles-'.$now.'.json', $articleBackup);
                DB::table('scs_newsapi_articles')->truncate();
                $this->output->writeln('    ==> DONE! Articles stored in `Articles-'.$now.'.json`');
            } else {
                $this->output->writeln('    ==> table already empty');
            }

        }
    }
}
