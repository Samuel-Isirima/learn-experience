<?php namespace SCS\Editorials\Console;

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;
use DB;
use Storage;
use Route;

/**
 *
 *  run from CLI `$> php artisan editorials:truncate-posts`
 */

class TruncatePosts extends Command
{
    protected $name = 'editorials:truncate-posts';

    protected $description = 'truncate (reset) all posts in `rainlab_blog_posts`';

    public function handle()
    {
        $this->output->writeln('*** removing all Posts ***');

        if ($this->confirm('Do you wish to continue?'))
        {
            Route::get('/clear-cache', function() {
                $exitCode = Artisan::call('config:cache');
                return '    ==> Cache recreated!';
            });

            $postsBackup = \RainLab\Blog\Models\Post::all();
            if (count($postsBackup) > 0) {
                $now = date('Y-m-d_Hi');

                /*      !! yikes! !!   */
                DB::select('SET FOREIGN_KEY_CHECKS = 0;');

                Storage::disk('local')->put('Taggables-'.$now.'.json', DB::table('ginopane_blogtaxonomy_taggables')->get());
                DB::table('ginopane_blogtaxonomy_taggables')->truncate();

                Storage::disk('local')->put('PostTags-'.$now.'.json', DB::table('ginopane_blogtaxonomy_post_tag')->get());
                DB::table('ginopane_blogtaxonomy_post_tag')->truncate();

                Storage::disk('local')->put('Posts-'.$now.'.json', $postsBackup);
                DB::table('rainlab_blog_posts')->truncate();

                Storage::disk('local')->put('PostCategories-'.$now.'.json', DB::table('rainlab_blog_posts_categories')->get());
                DB::table('rainlab_blog_posts_categories')->truncate();

                /*      !! yikes! !!   */
                DB::select('SET FOREIGN_KEY_CHECKS = 1;');

                $this->output->writeln('    ==> DONE! backups stored in `/storage/app`');
            } else {
                $this->output->writeln('    ==> table already empty');
            }

        }
    }
}
