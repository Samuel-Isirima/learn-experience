<?php namespace SCS\Editorials\Console;

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;
use DB;

use \RainLab\Blog\Models\Post;
use \GinoPane\BlogTaxonomy\Models\Series;
use \GinoPane\BlogTaxonomy\Models\Tag;

/**
 *
 *  run from CLI `$> php artisan editorials:seed-editorials`
 */

class SeedEditorials extends Command
{
    protected $name = 'editorials:seed-editorials';

    protected $description = 'WCU Console -- seed random staff, NOT OFFICIAL';

    public function handle()
    {
        $this->output->writeln('*** seeding editorials into DB ***');

        $this->seedPosts();

        $this->output->writeln('    ==> DONE!');
    }

    private function seedPosts() {

        // main page header
        Post::where('slug', '=', 'the-online-sports-database')->delete();
        Post::upsert([
            'slug' => 'the-online-sports-database',
            'title' => 'THE ONLINE SPORTS DATABASE',
            'excerpt' => 'SPORTS FAN HEADQUARTERS',
            'content' => 'THE ONLINE SPORTS DATABASE',
            'published_at' => '2021-01-01',
            'published' => 1,
        ], ['slug','title']);
        $s_hero = Series::where('slug', '=', 'hero-editorial')->first();
        Post::where('slug', '=', 'the-online-sports-database')->update(['ginopane_blogtaxonomy_series_id' => $s_hero->id]);
        // DB::insert("REPLACE INTO `system_files` (`id`, `disk_name`, `file_name`, `file_size`, `content_type`, `title`, `description`, `field`, `attachment_id`, `attachment_type`, `is_public`, `sort_order`, `created_at`, `updated_at`) VALUES (1, '6018ba5c11ce5916617420.png', 'drew_rosenhaus.png', 1333942, 'image/png', NULL, NULL, 'featured_images', '10002', 'RainLab/Blog/Models/Post', 1, 1, '2021-02-02 02:35:08', '2021-02-02 02:35:11')");

        // main page featured
        Post::where('slug', '=', 'drew-rosenhaus-super-agent')->delete();
        Post::upsert([
            'slug' => 'drew-rosenhaus-super-agent',
            'title' => 'DREW ROSENAHUS',
            'excerpt' => 'LIFE AS A SUPER AGENT',
            'content' => '
            Drew Rosenhaus, nicknamed the Shark, represents nearly 100 active NFL players as of Forbes’ 2019 agents list, and his agency Rosenhaus Sports Representation, which he cofounded with his brother Jason, represents some of football’s biggest names, including Antonio Brown and T.Y. Hilton.
            ',
            'published_at' => '2021-01-01',
            'published' => 1,
        ], ['slug','title']);
        $s_featured = Series::where('slug', '=', 'home-featured')->first();
        Post::where('slug', '=', 'drew-rosenhaus-super-agent')->update(['ginopane_blogtaxonomy_series_id' => $s_featured->id]);
        $dr_post = Post::where('slug', '=', 'drew-rosenhaus-super-agent')->first();
        DB::insert("REPLACE INTO `system_files` (`id`, `disk_name`, `file_name`, `file_size`, `content_type`, `title`, `description`, `field`, `attachment_id`, `attachment_type`, `is_public`, `sort_order`, `created_at`, `updated_at`) VALUES (1, '6018ba5c11ce5916617420.png', 'drew_rosenhaus.png', 1333942, 'image/png', NULL, NULL, 'featured_images', '10002', 'RainLab/Blog/Models/Post', 1, 1, '2021-02-02 02:35:08', '2021-02-02 02:35:11')");
        $t_nfl = Tag::where('slug', '=', 'nfl')->first();
        DB::insert('REPLACE INTO ginopane_blogtaxonomy_taggables (tag_id,ginopane_blogtaxonomy_taggable_id,ginopane_blogtaxonomy_taggable_type) values (?, ?, ?)',
            [$t_nfl->id,$dr_post->id,'RainLab\\Blog\\Models\\Post']
        );
    }
}
