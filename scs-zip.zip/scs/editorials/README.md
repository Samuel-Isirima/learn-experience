# Editorials plugin


    Post Series Navigation (seriesNavigation) - provides navigation within the series for a single post.
    Posts in the Series (postsInSeries) - lists all posts in the supplied series.
    Posts With the Tag (postsWithTag) - lists all posts with the supplied tag.
    Related Posts (relatedPosts) - provides a list of posts related by tags.
    Series List (seriesList) - displays a list of series.
    Tag List (tagList) - displays a list of tags.
    Related Series (relatedSeries) - provides a list of related series.

## notes on overrides

### posts

`plugins\rainlab\blog\components\post` --> view for post
```
[blogPost]
slug = "{{ :slug }}"
categoryPage = 404
```

### categories: (meant for grouping posts)

- handled by RainLab\Blog
- seeded
  - 'uncategorized',
  - 'osdb',
  - 'featured',
  - 'charity',
  - 'business'

```
{% for c in blogPost.post.categories %}
    {{c.slug}}
{% endfor %}
```

### tags:

- handled by GinoPane\BlogTaxonomy
- NONE `SEEDED` YET

!-- `partial/editorialTagList` >>> overrides `ginopane\blogtaxonomy\components\taglist\default` -->
```
[tagList editorialTagList]
displayEmpty = 1
orderBy = "name asc"
postSlug = "{{ :slug }}"
limit = 0
enableTagFilter = "never"
tagPage = 404
tagsPage = 404
```

`ginopane\blogtaxonomy\components\relatedPosts` --> all posts related to THIS post (by post slug) that have similar tags
```
[relatedPosts]
slug = "{{ :slug }}"
limit = 0
orderBy = "published_at asc"
postPage = "editorial/article"
```

`ginopane\blogtaxonomy\components\postsWithTag` --> all posts that have this tag
```
[postsWithTag]
tag = "test-tag-odd"
orderBy = "published_at asc"
page = "{{ :page }}"
resultsPerPage = 10
postPage = "editorial/article"
categoryPage = "blog/category"
```

### series:

- handled by GinoPane\BlogTaxonomy
- seeded:
  - 'hero-nhl',
  - 'hero-nfl',
  - 'hero-mlb',
  - 'hero-nba',
  - 'hero-editorial',
  - 'home-featured'

`ginopane\blogtaxonomy\components\relatedSeries` --> find all series that relate to this series
```
[relatedSeries]
series = "hero-nba"
seriesPage = "blog/series"
```

`ginopane\blogtaxonomy\components\postsInSeries` --> posts in specific series (filter by series slug)
```
[postsInSeries]
series = "hero-nba"
orderBy = "published_at asc"
page = "{{ :page }}"
resultsPerPage = 10
postPage = "blog/post"
categoryPage = "blog/category"
```

`ginopane\blogtaxonomy\components\seriesList` --> list all series
```
[seriesList]
displayEmpty = 1
limit = 0
orderBy = "title asc"
seriesPage = "blog/series"
```

## plugins

[Blog Taxonomy](https://octobercms.com/plugin/ginopane-blogtaxonomy)
[RainLab Blog](https://octobercms.com/plugin/rainlab-blog)

## instances of editorials

### home

```yaml
[editorialsCarousel editorials_small]
# template = "small_carousel"     # not required
tags = "*"
# limit = 10      # use built-in

[editorialsCarousel editorials_charity]
# template = "large_carousel"     # not required
tags = "*"
categories = "charity"
# limit = 4       # use built-in

[editorialsCarousel editorial_feature]
# template = "large_single"       # not required
series = "home-featured"
# limit = 1       # use built-in
```

### league

```yaml
[editorialsCarousel editorials_midpage]
# template = "large_carousel"     # not required
tags = "{{ :slug }}"
# limit = 4       # use built-in

[editorialsCarousel editorials_showcase]
# template = "showcase"       # not required
# limit = 1       # use built-in

[editorialsCarousel editorials_small]
# template = "small_carousel"     # not required
tags = "{{ :slug }}"
# limit = 10      # use built-in
```

### player

```yaml
[editorialsCarousel]
# limit = 4       # use built-in
```

### teams

```yaml
[editorialsCarousel]
# template = "large_carousel"     # not required
tags = "{{ :slug }}"
# limit = 4       # use built-in
```

### editorials

```yaml
[editorialsCarousel editorials_showcase]
# template = "showcase-editorial"     # not required
series = "hero-editorial"
# limit = 1       # use built-in

[editorialsCarousel editorials_card_list]
# template = "card_list"      # not required
# limit = 6       # use built-in
# default_image_full = "assets/images/core/bg-biggerthanbasketball.png"       # not required
# default_image_small = "assets/images/core/bg-feature-mobile@2x.png"         # not required
# order = "published_at desc"     # use built-in
```

### editorial article
```yaml
[editorialsCarousel editorials_small]
# template = "small_carousel"     # not required
# limit = 10      # use built-in
```

## props needed
