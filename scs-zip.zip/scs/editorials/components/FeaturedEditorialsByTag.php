<?php namespace SCS\Editorials\Components;

use Cms\Classes\ComponentBase;
use RainLab\Blog\Models\Post;
use SCS\Editorials\Controllers\Editorials;
use GinoPane\BlogTaxonomy\Models\Series;
use GinoPane\BlogTaxonomy\Models\Tag;
use GinoPane\BlogTaxonomy\Classes\PostListAbstract;

class FeaturedEditorialsByTag extends \GinoPane\BlogTaxonomy\Components\TagPosts
{
    public function componentDetails(): array
    {
        return [
            'name'        => 'Featured Editorials by Tag',
            'description' => 'Featured Editorials by Tag (large carousel).'
        ];
    }

    protected function prepareVars()
    {
        parent::prepareVars();

        $this->includeSeriesPosts = $this->property('includeSeriesPosts', false);
    }

    protected function prepareContextItem()
    {
        // load tag
        $this->tag = Tag::whereTranslatable('slug', $this->property('tag'))->first();

        return $this->tag;
    }

    public function onRun()
    {
        if ($this->prepareContextItem() === null) {
            $this->postsEditorialWithTag = $this->page['postsEditorialWithTag'] = [];
            return;
        }

        $this->prepareVars();

        $this->listPosts();
    }

    public $postsByTag;

    public function onRender()
    {
        $updatedPosts = [];

        if ($this->posts && count($this->posts) > 0) {
            $_posts = $this->posts;
            foreach ($_posts as $i => $p) {
                Editorials::addPostData($p);

                if ($p->published && $p->published_at) {
                    if ($p->published_at < date('Y-m-d H:i')) {
                        $updatedPosts[$i] = $p;
                    }
                }

            }

            $this->postsByTag = $this->page['postsByTag'] = $updatedPosts;
        } else {
            return [];
        }

    }
}
