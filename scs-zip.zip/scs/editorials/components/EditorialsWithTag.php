<?php namespace SCS\Editorials\Components;

use Cms\Classes\ComponentBase;
use RainLab\Blog\Models\Post;
use SCS\Editorials\Controllers\Editorials;
use GinoPane\BlogTaxonomy\Plugin;
use GinoPane\BlogTaxonomy\Models\Tag;
use GinoPane\BlogTaxonomy\Classes\PostListAbstract;

class EditorialsWithTag extends \GinoPane\BlogTaxonomy\Components\TagPosts
{
    public function componentDetails(): array
    {
        return [
            'name'        => 'Editorial list related by tag (Team or League',
            'description' => 'Other Editorial posts with this tag (sm carousel).'
        ];
    }

    protected function prepareContextItem()
    {
        // load tag
        $this->tag = Tag::whereTranslatable('slug', $this->property('tag'))->first();

        return $this->tag;
    }

    public function onRun()
    {
        if ($this->prepareContextItem() === null) {
            $this->postsEditorialWithTag = $this->page['postsEditorialWithTag'] = [];
            return;
        }

        $this->prepareVars();

        $this->listPosts();

    }

    public $postsEditorialWithTag;

    public function onRender()
    {
        $updatedPosts = [];

        if ($this->posts && count($this->posts) > 0) {
            $_posts = $this->posts;
            foreach ($_posts as $i => $p) {
                Editorials::addPostData($p);

                if ($p->published && $p->published_at) {
                    // limit to past 14 days
                    if ($p->published_at > date('Y-m-d H:i', strtotime(("-14 days")))) {
                        $updatedPosts[$i] = $p;
                    }
                }

            }

            $this->postsEditorialWithTag = $this->page['postsEditorialWithTag'] = $updatedPosts;
        } else {
            return [];
        }

    }
}
