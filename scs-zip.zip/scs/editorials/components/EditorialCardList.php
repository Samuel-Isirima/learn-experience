<?php namespace SCS\Editorials\Components;

use Cms\Classes\ComponentBase;
use Cms\Classes\Page;
use GinoPane\BlogTaxonomy\Models\Tag;
use RainLab\Blog\Models\Post;
use SCS\Editorials\Controllers\Editorials;
use SCS\Osdb\Models\League;

class EditorialCardList extends ComponentBase
{
    public $posts;
    public $leagues;
    public $tags;
    public $noPostsMessage;
    public $postPage;
    public $showLeagueFilter = true;

    public function componentDetails(): array
    {
        return [
            'name' => 'Card list of editorial articles',
            'description' => 'List editorial posts as cards (cards).'
        ];
    }

    public function defineProperties()
    {
        return [
            'postsPerPage' => [
                'title' => 'Posts per page',
                'type' => 'string',
                'validationPattern' => '^[0-9]+$',
                'default' => '10',
            ],
            'noPostsMessage' => [
                'title' => 'No post message',
                'type' => 'string',
                'default' => 'No posts found!',
                'showExternalParam' => false,
            ],
            'postPage' => [
                'title' => 'Post page',
                'type' => 'dropdown',
                'default' => 'blog/post',
            ],
            'tagged' => [
                'title' => 'Tags for Posts',
                'type' => 'string',
                'default' => '',
            ],
        ];
    }

    public function getPostPageOptions()
    {
        return Page::sortBy('baseFileName')->lists('baseFileName', 'baseFileName');
    }

    public function onRender()
    {

        $this->leagues = League::all()->toArray();
        $this->tags = Tag::whereNotIn('slug', ['nba', 'nhl', 'nfl', 'mlb', 'osdb'])->get()->toArray();
        $options = $this->getFilterOptions();
        $this->posts = $this->loadPosts($options);
    }

    public function onFilter()
    {
        $options = $this->getFilterOptions();
        $this->posts = $this->loadPosts($options);
        return [];
    }

    public function onLoadMore()
    {
        $options = $this->getFilterOptions();
        $options['page'] = $_REQUEST['page'];
        $posts = $this->loadPosts($options);
        $this->posts = $posts;
        return [];
    }

    private function getFilterOptions()
    {
        $options = [];

        if (!empty($this->property('tagged'))) {
            // if the filter in the url is a league hide the leagues filter dropdown on the page
            if (in_array($this->property('tagged'), ['nba', 'nhl', 'nfl', 'mlb', 'mls'])) {
                $this->showLeagueFilter = false;
            }
            $options['tags'] = [$this->property('tagged')];
        
        } else if (!empty($_REQUEST['filter_tags'])) {
            $options['tags'] = explode(',', $_REQUEST['filter_tags']);
        }

        if (!empty($_REQUEST['filter_league'])) {
            $options['league'] = $_REQUEST['filter_league'];
        }
        if (!empty($_REQUEST['filter_order'])) {
            $options['sort'] = $_REQUEST['filter_order'];
        }

        return $options;
    }

    private function loadPosts($options = [])
    {

        extract(
            array_merge(
                [
                'page' => 1,
                'perPage' => $this->property('postsPerPage'),
                'sort' => 'published_at desc',
                'league' => null,
                'tags' => null
                ], $options
            )
        );

        $query = Post::isPublished();

        if (!empty($league)) {
            $query = $query->whereHas(
                'tags', function ($query) use ($league) {
                    $query->where('slug', $league);
                }
            );
        }

        if (!empty($tags)) {
            if (is_string($tags)) {
                $tags = explode(',', $tags);
            }
            $query = $query->whereHas(
                'tags', function ($query) use ($tags) {
                    $query->whereIn('slug', $tags);
                }
            );
        }

        list($sortField, $sortDirection) = explode(' ', $sort);
        if (is_null($sortDirection)) {
            $sortDirection = "desc";
        }
        $query->orderBy($sortField, $sortDirection);

        $posts = $query->paginate($perPage, $page);

        $posts->each(
            function ($post) {
                Editorials::addPostData($post);
            }
        );

        return $posts;
    }
}
