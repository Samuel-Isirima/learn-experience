<?php

namespace SCS\Editorials\Components;

use Cms\Classes\ComponentBase;
use SCS\Editorials\Controllers\Editorials;
use RainLab\Blog\Models\Post;
use GinoPane\BlogTaxonomy\Models\Series;

class ShowcaseHeroEditorial extends
\GinoPane\BlogTaxonomy\Classes\PostListAbstract
{

    public function componentDetails(): array
    {
        return [
            'name' => 'Showcase for Hero-Editorial',
            'description' => 'Showcase for Hero-Editorial series.',
        ];
    }

    public $series;

    public function defineProperties(): array
    {
        return [
            'resultsPerPage' => [
                'title' => 'Number of posts',
                'description' => 'The limit for number of posts to fetch',
                'type' => 'string',
                'default' => '1',
            ],
            'series' => [
                'title' => 'Series slug',
                'description' => 'The series slug - usually `:series`',
                'type' => 'string',
                'default' => 'home-featured',
            ],
        ] + parent::defineProperties();
    }

    protected function getPostsQuery()
    {
        $query = Post::whereHas('series', function ($query) {
            $query->whereTranslatable('slug', $this->series->slug);
        });

        $query->isPublished();
        $query->orderBy('published_at', 'desc');
        return $query;
    }

    protected function prepareVars()
    {
        parent::prepareVars();
        $this->resultsPerPage = $this->property('resultsPerPage', 1);
        $this->includeTaggedPosts = false;
        //$this->property('includeTaggedPosts', false);
        $this->orderBy = 'published_at desc';
    }

    protected function prepareContextItem()
    {
        $_seriesAttrib = $this->property('series');
        $_lookupSeries = Series::whereTranslatable(
            'slug',
            $_seriesAttrib
        )->first();
        if ($_lookupSeries) {
            $this->series = $_lookupSeries;
            return $this->series;
        } else {
            $_useSeries = 'home-featured';
            $this->series = \GinoPane\BlogTaxonomy\Models\Series::whereTranslatable(
                'slug',
                $_useSeries
            )->first();
            return $this->series;
        }
    }

    public $homeFeaturedPost;

    public function onRender()
    {
        if ($this->posts && count($this->posts) > 0) {
            $_featuredPost = $this->posts[0];
            if ($_featuredPost->published) {
                if ($_featuredPost->published_at < date('Y-m-d H:i')) {
                    $_featuredPost->author = Editorials::getAuthorSummary($_featuredPost);
                    $_featuredPost->share_links = \SCS\Osdb\Controllers\Seo::getShareLinks($_featuredPost, 'editorial');
                    $this->homeFeaturedPost = $this->page['homeFeaturedPost'] = $_featuredPost;
                }
            } else {
                return [];
            }
        } else {
            return [];
        }
    }
}
