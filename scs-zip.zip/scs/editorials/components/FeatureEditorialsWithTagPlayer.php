<?php namespace SCS\Editorials\Components;

use Cms\Classes\ComponentBase;
use RainLab\Blog\Models\Post;
use SCS\Editorials\Controllers\Editorials;
use SCS\Osdb\Models\Player;
use GinoPane\BlogTaxonomy\Models\Tag;
use GinoPane\BlogTaxonomy\Classes\PostListAbstract;

class FeatureEditorialsWithTagPlayer extends \GinoPane\BlogTaxonomy\Components\TagPosts
{
    public function componentDetails(): array
    {
        return [
            'name'        => 'Editorial list related by tag (by Player slug)',
            'description' => 'Other Editorial posts with this tag (sm carousel).'
        ];
    }

    protected function prepareContextItem()
    {
        $_tagAttrib = $this->property('tag');

        $_player = Player::where('guid', $_tagAttrib)->first();
        if(isset($_player)) {
            $_player->extendWithESData();
            $_tagSlug = str_replace(
                '+',
                '-',
                urlencode(strtolower($_player->name))
            );
            // load series - if not found append 'hero-' as prefix
            $_lookupTag = Tag::whereTranslatable('slug', $_tagSlug)->first();
        }

        if (!empty($_lookupTag)) {
            $this->tag = $_lookupTag;
            return $this->tag;
        } else {
            // NOTE: this may  present issues in the future if 'hero' is not included in the series slugs -RWC
            $_useSeries = 'hero-' . $this->property('series');
            $this->tag = \GinoPane\BlogTaxonomy\Models\Tag::whereTranslatable('slug', $_useSeries)->first();
            return $this->tag;
        }
    }

    protected function getPostsQuery()
    {
        $query = Post::whereHas('tags', function ($query) {
            $query->whereTranslatable('slug', $this->tag->slug);
        });

        // if ($this->includeSeriesPosts) {
        //     $query->orWhereHas('series', function ($query) {
        //         $query->whereHas('tags', function ($query) {
        //             $query->whereTranslatable('slug', $this->tag->slug);
        //         });
        //     });
        // }

        $query->isPublished();

        return $query;
    }

    public function onRun()
    {
        if ($this->prepareContextItem() === null) {
            $this->postsEditorialWithTag = $this->page['postsEditorialWithTag'] = [];
            return;
        }

        $this->prepareVars();

        $this->listPosts();
    }

    public $postsEditorialWithTag;

    public function onRender()
    {
        $updatedPosts = [];

        if ($this->posts && count($this->posts) > 0) {
            $_posts = $this->posts;
            foreach ($_posts as $i => $p) {
                Editorials::addPostData($p);

                if ($p->published && $p->published_at) {
                    if ($p->published_at < date('Y-m-d H:i')) {
                        $updatedPosts[$i] = $p;
                    }
                }

            }

            $this->postsEditorialWithTag = $this->page['postsEditorialWithTag'] = $updatedPosts;
        } else {
            return [];
        }

    }
}
