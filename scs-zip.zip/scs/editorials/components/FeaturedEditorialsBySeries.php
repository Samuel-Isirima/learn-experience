<?php namespace SCS\Editorials\Components;

use Cms\Classes\ComponentBase;
use SCS\Editorials\Controllers\Editorials;
use RainLab\Blog\Models\Post;
use GinoPane\BlogTaxonomy\Models\Series;
use GinoPane\BlogTaxonomy\Models\Tag;

class FeaturedEditorialsBySeries extends
    \GinoPane\BlogTaxonomy\Classes\PostListAbstract
{

    public function componentDetails(): array
    {
        return [
            'name' => 'Featured Editorials by Series',
            'description' => 'Featured Editorials by Series (large carousel).',
        ];
    }

    public $series;

    public function defineProperties(): array
    {
        return [
            'series' => [
                'title' => 'Series slug',
                'description' =>
                    'The series slug - use `:series` to filter by URL',
                'type' => 'string',
                'default' => '{{ :series }}',
            ],
            'includeTaggedPosts' => [
                'title' => 'Include Tagged Posts',
                'description' => 'Are posts with tag related to this series?',
                'default' => false,
                'type' => 'checkbox',
                'showExternalParam' => false,
            ],
            'useLightTheme' => [
                'title' => 'Light Theme',
                'description' => 'Use light theme of this component?',
                'default' => false,
                'type' => 'checkbox',
            ],
            'showCategory' => [
                'title' => 'Show category',
                'description' =>
                    'Show category above title? (will use `excerpt` above title if false)',
                'default' => true,
                'type' => 'checkbox',
            ],
        ] + parent::defineProperties();
    }

    protected function getPostsQuery()
    {
        $query = Post::whereHas('series', function ($query) {
            $query->whereTranslatable('slug', $this->series->slug);
        });

        $tagIds = $this->series->tags->lists('id');

        $includeTaggedPosts = $this->property('includeTaggedPosts', true);

        if ($includeTaggedPosts) {
            if (!empty($tagIds)) {
                $query->orWhereHas('tags', function ($tag) use ($tagIds) {
                    $tag->whereIn('id', $tagIds);
                });
            }
        }

        $query->isPublished();

        return $query;
    }

    protected function prepareVars()
    {
        parent::prepareVars();
        $this->includeTaggedPosts = $this->property(
            'includeTaggedPosts',
            false
        );
    }

    protected function prepareContextItem()
    {
        $_seriesAttrib = $this->property('series');
        // load series - if not found append 'hero-' as prefix
        $_lookupSeries = Series::whereTranslatable(
            'slug',
            $_seriesAttrib
        )->first();
        if ($_lookupSeries) {
            $this->series = $_lookupSeries;
            return $this->series;
        } else {
            // NOTE: this may  present issues in the future if 'hero' is not included in the series slugs -RWC
            $_useSeries = '' . $this->property('series') . '-featured';
            $this->series = \GinoPane\BlogTaxonomy\Models\Series::whereTranslatable('slug', $_useSeries)->first();
            if (!$this->series){
                // fallback to home-featured to avoid 404 if context item is empty
                $fallbackSeries = 'home-featured';
                $this->series = Series::whereTranslatable('slug', $fallbackSeries)->first();
            }
            return $this->series;
        }
    }

    public $postsInSeries;

    public function onRender()
    {
        $updatedPosts = [];
        if ($this->posts && count($this->posts) > 0) {
            $_posts = $this->posts->count() > 0 ? $this->posts : $this->series->posts;

            foreach ($_posts as $i => $p) {
                if ($p->published && $p->published_at) {
                    if ($p->published_at < date('Y-m-d H:i')) {
                        $p->share_links  = \SCS\Osdb\Controllers\Seo::getShareLinks($p, 'editorial');
                        $updatedPosts[$i] = $p;
                    }
                }

            }

            $this->postsInSeries = $this->page['postsInSeries'] = $updatedPosts;
        } else {
            return [];
        }

    }
}
