<?php

namespace SCS\Editorials\Components;

use Cms\Classes\ComponentBase;
use SCS\Editorials\Controllers\Editorials;
use RainLab\Blog\Models\Post;
use GinoPane\BlogTaxonomy\Models\Series;

class ShowcaseHeroEditorialBySeries extends \GinoPane\BlogTaxonomy\Classes\PostListAbstract
{

    public function componentDetails(): array
    {
        return [
            'name'        => 'Showcase for features editorial in series',
            'description' => 'Showcase for features editorial in series.'
        ];
    }

    public $series;

    public function defineProperties(): array
    {
        return [
            'resultsPerPage' => [
                'title'       => 'Number of posts',
                'description' => 'The limit for number of posts to fetch',
                'type'        => 'string',
                'default'     => '1',
            ],
            'series' => [
                'title'       => 'Series slug',
                'description' => 'The series slug - usually `:series`',
                'type'        => 'string',
                'default'     => '{{ :series }}',
            ],
            'includeTaggedPosts' => [
                'title'         => 'Include Tagged Posts',
                'description'   => 'Are posts with tag related to this series included?',
                'default'       => true,
                'type'          => 'checkbox',
                'showExternalParam' => false
            ]
        ] + parent::defineProperties();
    }

    protected function getPostsQuery()
    {
        $query = Post::whereHas('series', function ($query) {
            $query->whereTranslatable('slug', $this->series->slug);
        });

        $query->isPublished();
        $query->orderBy('published_at', 'desc');
        return $query;
    }

    protected function prepareVars()
    {
        parent::prepareVars();
        $this->resultsPerPage = $this->property('resultsPerPage', 1);
        $this->includeTaggedPosts = $this->property('includeTaggedPosts', false);
        $this->orderBy = 'published_at desc';
    }

    protected function prepareContextItem()
    {
        $_seriesAttrib = $this->property('series');
        // load series - if not found append 'hero-' as prefix
        $_lookupSeries = Series::whereTranslatable('slug', $_seriesAttrib)->first();
        if ($_lookupSeries) {
            $this->series = $_lookupSeries;
            return $this->series;
        } else {
            // NOTE: this may  present issues in the future if 'hero' is not included in the series slugs -RWC
            $_useSeries = 'hero-' . $this->property('series');
            $this->series = Series::whereTranslatable('slug', $_useSeries)->first();
            if (!$this->series) {
                // fallback to hero-editorial to avoid 404 if context item is empty
                $fallbackSeries = 'hero-editorial';
                $this->series = Series::whereTranslatable('slug', $fallbackSeries)->first();
            }
            return $this->series;
        }
    }

    public $showcasePost;

    public function onRender()
    {

        if ($this->posts && count($this->posts) > 0) {
            Editorials::addPostData($this->posts[0]);
            $_featuredPost = $this->posts[0];
            if ($_featuredPost->published) {
                if ($_featuredPost->published_at < date('Y-m-d H:i')) {
                    $_featuredPost->author = Editorials::getAuthorSummary($_featuredPost);
                    $this->showcasePost = $this->page['showcasePost'] = $_featuredPost;
                }
            } else {
                return [];
            }
        } else {
            return [];
        }
    }
}
