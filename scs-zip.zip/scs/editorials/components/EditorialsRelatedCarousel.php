<?php namespace SCS\Editorials\Components;

use Cms\Classes\ComponentBase;
use RainLab\Blog\Models\Post;
use SCS\Editorials\Controllers\Editorials;

class EditorialsRelatedCarousel extends \GinoPane\BlogTaxonomy\Components\RelatedPosts
{
    public function componentDetails(): array
    {
        return [
            'name' => 'Editorials Related by Tag',
            'description' => 'Editorials related to this one by tag (sm carousel).',
        ];
    }

    public $editorialPosts;

    public function onRender()
    {
        $updatedPosts = [];
        if ($this->posts && count($this->posts) > 0) {
            $_posts = $this->posts;
            if ($_posts) {
                foreach ($_posts as $i => $p) {
                    Editorials::addPostData($p);

                    if ($p->published && $p->published_at) {
                        if ($p->published_at < date('Y-m-d H:i')) {
                            $updatedPosts[$i] = $p;
                        }
                    }

                }
            }

            $this->editorialPosts = $this->page['editorialPosts'] = $updatedPosts;
        } else {
            return [];
        }

    }
}
