<?php namespace SCS\Editorials\Components;

use Cms\Classes\ComponentBase;
use RainLab\Blog\Models\Post;
use SCS\Editorials\Controllers\Editorials;
use GinoPane\BlogTaxonomy\Models\Series;

class FeaturedEditorialsByCategory extends \RainLab\Blog\Components\Posts
{

    public function componentDetails(): array
    {
        return [
            'name'        => 'Featured Editorials by Category',
            'description' => 'Featured Editorials by Category (large carousel).'
        ];
    }

    public function defineProperties(): array
    {
        return [
            'categoryFilter' => [
                'title'       => 'Category Filter',
                'description' => 'Category (not Series) to filter by',
                'type'        => 'string',
                'default'     => '',
            ],
            'excludeSeries' => [
                'title'       => 'Exclude Series',
                'description' => 'Series to be excluded (by slug, space separated)',
                'type'        => 'string',
                'default'     => '',
            ],
        ] + parent::defineProperties();
    }

    public $postsByCategory;

    public function onRender()
    {
        $updatedPosts = [];

        if ($this->posts && count($this->posts) > 0) {
            $_posts = $this->posts;

            $_excludeSeries = $this->property('excludeSeries', false);
            $_excludeSeriesIds = [];
            if ($_excludeSeries && ($_excludeSeries !== null)) {
                $_excludeArr = explode(" ", $_excludeSeries);
                foreach ($_excludeArr as $i => $excludeSlug) {
                    $_excludeSeriesIds[$i] = Series::where('slug', '=', $excludeSlug)->first()->id;
                }
            }

            foreach ($_posts as $i => $p) {
                if (in_array($p->ginopane_blogtaxonomy_series_id, $_excludeSeriesIds)) {
                    continue;
                }
                Editorials::addPostData($p);

                if ($p->published && $p->published_at) {
                    if ($p->published_at < date('Y-m-d H:i')) {
                        $updatedPosts[$i] = $p;
                    }
                }

            }

            $this->postsByCategory = $this->page['postsByCategory'] = $updatedPosts;
        } else {
            return [];
        }
    }
}
