<?php
namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class AddIndexesToRainlabBlogPosts extends Migration
{
    public function up()
    {
        Schema::table('rainlab_blog_posts', function ($table) {
            $table->index('title');
            $table->index(['published', 'published_at', 'id', 'title'], 'idx_title_sort');
            $table->index(['published', 'published_at', 'id', 'created_at'], 'idx_created_at_sort');
            $table->index(['published', 'published_at', 'id', 'updated_at'], 'idx_updated_at_sort');
            $table->index(['published', 'published_at', 'id',], 'idx_published_at_sort');
        });
    }

    public function down()
    {
        Schema::table('rainlab_blog_posts', function ($table) {
            $table->dropIndex(['title']);
            $table->dropIndex('idx_title_sort');
            $table->dropIndex('idx_created_at_sort');
            $table->dropIndex('idx_updated_at_sort');
            $table->dropIndex('idx_published_at_sort');
        });
    }
}