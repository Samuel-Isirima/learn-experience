<?php namespace SCS\Osdb\Updates;

use Seeder;
use System\Classes\PluginManager;
use Ginopane\BlogTaxonomy\Models\Series;
use RainLab\Blog\Models\Category;

class UpdateCategoryNames extends Seeder
{
    public function run()
    {
        if (PluginManager::instance()->hasPlugin('ginopane.blogtaxonomy')) {
            Category::where('slug', 'business')->update(['name' => 'Business', 'description' => 'Business editorial content',]);
            Category::where('slug', 'charity')->update(['name' => 'Charity', 'description' => 'Charity and Community content',]);
            Category::where('slug', 'osdb')->update(['name' => 'OSDB', 'description' => 'OSDB site and company editorial content',]);
            Category::where('slug', 'featured')->update(['name' => 'Feature', 'description' => 'Featured editorials shown in large carousels',]);
        }
    }
}
