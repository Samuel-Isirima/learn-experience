<?php namespace SCS\Editorials\Updates;

use Schema;
use DB;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;
use RainLab\Blog\Models\Post;
use GinoPane\BlogTaxonomy\Models\Tag;
use SCS\Osdb\Models\League;
use SCS\Osdb\Models\Team;
use SCS\Osdb\Models\Player;
use System\Classes\PluginManager;

class FillTeamAndPlayerTags extends Migration
{
    public function up()
    {
        if (PluginManager::instance()->hasPlugin('ginopane.blogtaxonomy')) {
            Tag::upsert(['name' => 'OSDB', 'slug' => 'osdb'], ['name', 'slug']);
            Tag::upsert(['name' => 'NBA' , 'slug' => 'nba' ], ['name', 'slug']);
            Tag::upsert(['name' => 'NFL' , 'slug' => 'nfl' ], ['name', 'slug']);
            Tag::upsert(['name' => 'NHL' , 'slug' => 'nhl' ], ['name', 'slug']);
            Tag::upsert(['name' => 'MLB' , 'slug' => 'mlb' ], ['name', 'slug']);

            $_players = Player::whereNotNull('name')
            // ->take(1000) // for testing
            ->get();
            foreach ($_players as $i => $p) {
                $_slug = str_replace('+', '-', urlencode(strtolower($p->name)));
                Tag::upsert(
                    ['name' => $p->name, 'slug' => $_slug],
                    ['name', 'slug']
                );
            }

            $_team = Team::whereNotNull('name')
            // ->take(1000) // for testing
            ->get();
            foreach ($_team as $i => $t) {
                $_slug = str_replace('+', '-', urlencode(strtolower($t->name)));
                Tag::upsert(
                    ['name' => $t->name, 'slug' => $_slug],
                    ['name', 'slug']
                );
            }
        }
    }

    public function down()
    {

    }
}
