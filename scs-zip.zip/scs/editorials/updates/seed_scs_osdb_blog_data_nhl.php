<?php namespace SCS\Osdb\Updates;

use Seeder;
use System\Classes\PluginManager;
use Ginopane\BlogTaxonomy\Models\Series;
use RainLab\Blog\Models\Category;

class SeedBlogDataNHL extends Seeder
{
    public function run()
    {
        if (PluginManager::instance()->hasPlugin('ginopane.blogtaxonomy')) {
            Series::upsert(
                [
                    'title' => 'NHL League page: Hero article',
                    'slug' => 'hero-nhl',
                    'description' =>
                        'NHL League page, top hero banner post',
                ],
                ['id', 'title', 'slug']
            );
            Series::upsert(
                [
                    'title' => 'Appear in NHL Featured posts',
                    'slug' => 'nhl-featured',
                    'description' =>
                        'This article will appear in Featured posts for NHL',
                ],
                ['id', 'title', 'slug']
            );
        }
    }
}
