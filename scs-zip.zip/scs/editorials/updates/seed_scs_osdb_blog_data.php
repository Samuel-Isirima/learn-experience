<?php namespace SCS\Osdb\Updates;

use Seeder;
use System\Classes\PluginManager;
use Ginopane\BlogTaxonomy\Models\Series;
use RainLab\Blog\Models\Category;

class SeedBlogData extends Seeder
{
    public function run()
    {
        if (PluginManager::instance()->hasPlugin('ginopane.blogtaxonomy')) {
            Series::upsert(
                [
                    'title' => 'Hero - Editorial',
                    'slug' => 'hero-editorial',
                    'description' =>
                        'Uses most recent post for the Hero article',
                ],
                ['id', 'title', 'slug']
            );
            Series::upsert(
                [
                    'title' => 'Homepage - Featured',
                    'slug' => 'home-featured',
                    'description' =>
                        'Uses most recent post for the Home page featured artical',
                ],
                ['id', 'title', 'slug']
            );
            Series::upsert(
                [
                    'title' => 'Hero - NHL',
                    'slug' => 'hero-nhl',
                    'description' =>
                        'Uses most recent post for the Hero article',
                ],
                ['id', 'title', 'slug']
            );
            Series::upsert(
                [
                    'title' => 'Hero - NFL',
                    'slug' => 'hero-nfl',
                    'description' =>
                        'Uses most recent post for the Hero article',
                ],
                ['id', 'title', 'slug']
            );
            Series::upsert(
                [
                    'title' => 'Hero - MLB',
                    'slug' => 'hero-mlb',
                    'description' =>
                        'Uses most recent post for the Hero article',
                ],
                ['id', 'title', 'slug']
            );
            Series::upsert(
                [
                    'title' => 'Hero - NBA',
                    'slug' => 'hero-nba',
                    'description' =>
                        'Uses most recent post for the Hero article',
                ],
                ['id', 'title', 'slug']
            );

            Category::upsert(
                [
                    'name' => 'Business',
                    'slug' => 'business',
                    'description' => 'Use to identify any Business content',
                    'nest_left' => 3,
                    'nest_right' => 4,
                    'nest_depth' => 0,
                    'id' => 2,
                ],
                ['id', 'slug']
            );
            Category::upsert(
                [
                    'name' => 'Charity',
                    'slug' => 'charity',
                    'description' => 'Use to identify any Charity content',
                    'nest_left' => 5,
                    'nest_right' => 6,
                    'nest_depth' => 0,
                    'id' => 3,
                ],
                ['id', 'slug']
            );
            Category::upsert(
                [
                    'name' => 'OSDB',
                    'slug' => 'osdb',
                    'description' => 'Use to identify any OSDB sourced content',
                    'nest_left' => 7,
                    'nest_right' => 8,
                    'nest_depth' => 0,
                    'id' => 4,
                ],
                ['id', 'slug']
            );
            Category::upsert(
                [
                    'name' => 'Featured',
                    'slug' => 'featured',
                    'description' =>
                        'Use for filtering, featured are always moved to the top of the list',
                    'nest_left' => 9,
                    'nest_right' => 10,
                    'nest_depth' => 0,
                    'id' => 5,
                ],
                ['id', 'slug']
            );
        }
    }
}
