<?php namespace SCS\Osdb\Updates;

use Seeder;
use System\Classes\PluginManager;
use Ginopane\BlogTaxonomy\Models\Series;
use RainLab\Blog\Models\Category;

class UpdateSeriesNames extends Seeder
{
    public function run()
    {
        if (PluginManager::instance()->hasPlugin('ginopane.blogtaxonomy')) {
            Series::where('slug', 'hero-editorial')->update(['title' => 'Home and Editorials pages: Hero article','description' => 'on Home and Editorial page, top hero banner post',]);
            Series::where('slug', 'home-featured')->update(['title' => 'Appear in Featured posts','description' => 'This article will appear in Featured posts carousels',]);
            Series::where('slug', 'hero-nhl')->update(['title' => '(not active) NHL League page: Hero article','description' => 'NHL League page, top hero banner post',]);
            Series::where('slug', 'hero-nfl')->update(['title' => 'NFL League page: Hero article','description' => 'NFL League page, top hero banner post',]);
            Series::where('slug', 'hero-mlb')->update(['title' => 'MLB League page: Hero article','description' => 'MLB League page, top hero banner post',]);
            Series::where('slug', 'hero-nba')->update(['title' => 'NBA League page: Hero article','description' => 'NBA League page, top hero banner post',]);

            Series::upsert(
                [
                    'title' => 'Appear in NBA Featured posts',
                    'slug' => 'nba-featured',
                    'description' =>
                        'This article will appear in Featured posts for NBA',
                ],
                ['id', 'title', 'slug']
            );
            Series::upsert(
                [
                    'title' => 'Appear in NFL Featured posts',
                    'slug' => 'nfl-featured',
                    'description' =>
                        'This article will appear in Featured posts for NFL',
                ],
                ['id', 'title', 'slug']
            );
            Series::upsert(
                [
                    'title' => 'Appear in MLB Featured posts',
                    'slug' => 'mlb-featured',
                    'description' =>
                        'This article will appear in Featured posts for MLB',
                ],
                ['id', 'title', 'slug']
            );
            Series::upsert(
                [
                    'title' => '(not active) Appear in NHL Featured posts',
                    'slug' => 'nhl-featured',
                    'description' =>
                        'This article will appear in Featured posts for NHL',
                ],
                ['id', 'title', 'slug']
            );

            Category::where('slug', 'business')->update(['name' => 'Business editorials', 'description' => 'Business editorial content',]);
            Category::where('slug', 'charity')->update(['name' => 'Charity and Community', 'description' => 'Charity and Community content',]);
            Category::where('slug', 'osdb')->update(['name' => 'OSDB editorials', 'description' => 'OSDB site and company editorial content',]);
            Category::where('slug', 'featured')->update(['name' => 'Featured editorials', 'description' => 'Featured editorials shown in large carousels',]);
        }
    }
}
