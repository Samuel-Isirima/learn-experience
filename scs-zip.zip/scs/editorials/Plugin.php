<?php namespace SCS\Editorials;

use Backend;
use Event;
use System\Classes\PluginBase;
use RainLab\Blog\Controllers\Posts as PostsController;

class Plugin extends PluginBase
{

    /*
        TODO: copy paste from Word [0.5] - does it work, can we fix?
        TODO: think about allowing for different hero and thumbnail images [2] - this will NOT use the feature image (need to create class to extend Post)
    */

    public function pluginDetails()
    {
        return [
            'name'        => 'Editorials',
            'description' => 'Editorials - articles and posts',
            'author'      => 'SCS',
            'icon'        => 'icon-newspaper-o'
        ];
    }

    public function register()
    {
        $this->registerConsoleCommand( 'editorials:truncate-articles','SCS\Editorials\Console\TruncateArticles' );
        $this->registerConsoleCommand( 'editorials:truncate-posts','SCS\Editorials\Console\TruncatePosts' );
        $this->registerConsoleCommand( 'editorials:truncate-tags','SCS\Editorials\Console\TruncateTags' );
        $this->registerConsoleCommand( 'editorials:seed-editorials','SCS\Editorials\Console\SeedEditorials' );
    }

    public function boot()
    {
        // \SCS\Osdb\Models\League::extend(function($model) { $model->hero_series = 'hero-' . $model->slug; });

        if (class_exists('\RainLab\Blog\Models\Post')) {

            /** Remove the original main-menu item */
            Event::listen('backend.menu.extendItems', function ($manager) {
                $manager->removeMainMenuItem('RainLab.Blog', 'blog');
            });

            /** Add a custom main-menu item */
            Event::listen('backend.menu.extendItems', function ($manager) {
                $manager->addMainMenuItem('RainLab.Blog', 'blog', [
                        'label'       => "Editorials", // 'rainlab.blog::lang.blog.menu_label',
                        'url'         => Backend::url('rainlab/blog/posts'),
                        'icon'        => 'icon-newspaper-o',
                        'permissions' => ['rainlab.blog.*'],
                        'order'       => 300,

                        'sideMenu' => [
                            'new_post' => [
                                'label'       => 'rainlab.blog::lang.posts.new_post',
                                'icon'        => 'icon-pencil',
                                'url'         => Backend::url('rainlab/blog/posts/create'),
                                'permissions' => ['rainlab.blog.access_posts']
                            ],
                            'posts' => [
                                'label'       => 'rainlab.blog::lang.blog.posts',
                                'icon'        => 'icon-copy',
                                'url'         => Backend::url('rainlab/blog/posts'),
                                'permissions' => ['rainlab.blog.access_posts']
                            ],
                            'categories' => [
                                'label'       => 'rainlab.blog::lang.blog.categories',
                                'icon'        => 'icon-list-ul',
                                'url'         => Backend::url('rainlab/blog/categories'),
                                'permissions' => ['rainlab.blog.access_categories']
                            ]
                        ]
                ]);
            });

            PostsController::extendFormFields(function ($form, $model) {
                if ($form->arrayName !== "Post") {
                    return;
                } else {
                    $today = date("d/m/Y, H:i:s T");
                    $est = new \DateTime('now', new \DateTimeZone('America/New_York'));
                    $pst = new \DateTime('now', new \DateTimeZone('America/Los_Angeles'));
                    $estoff = ($est->getOffset() / 60 / 60 );
                    $pstoff = ($pst->getOffset() / 60 / 60 );
                    // echo 'Server Time: ' . $today . ' <br/>';
                    // echo 'Eastern: ' . $est->format('d/m/Y, H:i:s T') . $estoff . ' <br/>';
                    // echo 'Pacific: ' . $pst->format('d/m/Y, H:i:s T') . $pstoff . ' <br/>';
                    /*
                    $time_diffs = 'Server Time: ' . $today . ' <br/>'
                                . 'Eastern: ' . $est->format('d/m/Y, H:i:s T') . ' (UTC ' . $estoff . ' hrs) <br/>'
                                . 'Pacific: ' . $pst->format('d/m/Y, H:i:s T') . ' (UTC ' . $pstoff . ' hrs) <br/>';
                    */

                    $form->addFields([
                        'article_note'=>[
                            'type'=>'section',
                            'span'=>'full',
                            'label'=>'',
                            'commentHtml' => 'true',
                            'comment' => '<div class="form-group widget-field span-left" style="font-size: smaller;"><p>Notes:</p>
                                    <ul>
                                        <li>Category: used to classify an article, ONLY used for special sections i.e. "Charities"</li>
                                        <li>Tags: use as many tags make sense for the content, will show article in section related by tag i.e. all MLB articles, all Packers articles, etc.</li>
                                        <li>Series: used to declare where a large format article will show. Can be a showcase/hero article or a feature block article</li>
                                    </ul>
                                   </div>
                                    <div class="form-group widget-field span-right" style="font-size: smaller;"><p>Series:</p>
                                    <ul>
                                        <li>for showcase/hero size on Homepage USE -> <strong>Home and Editorials pages: Hero article</strong></li>
                                        <li>for showcase/hero size on NBA page USE -> <strong>NBA League page: Hero article</strong></li>
                                        <li>for showcase/hero size on NFL page USE -> <strong>NFL League page: Hero article</strong></li>
                                        <li>for showcase/hero size on MLB page USE -> <strong>MLB League page: Hero article</strong></li>
                                        <li>for feature/square size article on Homepage USE -> <strong>Appear in Featured posts</strong></li>
                                        <li>for feature/square size article on NBA Page USE -> <strong>Appear in NBA Featured posts</strong></li>
                                        <li>for feature/square size article on NFL Page USE -> <strong>Appear in NFL Featured posts</strong></li>
                                        <li>for feature/square size article on MLB Page USE -> <strong>Appear in MLB Featured posts</strong></li>
                                    </ul></div>'
                        ],
                    ]);

                    $form->addSecondaryTabFields([
                        'content'=> [
                            'tab' => 'rainlab.blog::lang.post.tab_edit',
                            'type' => 'richeditor', // << was 'RainLab\Blog\FormWidgets\BlogMarkdown',
                            'toolbarButtons' => 'undo,redo,clearFormatting,selectAll,|,insertLink,insertImage,insertVideo,insertAudio,insertFile,insertTable,html,-,paragraphFormat,bold,italic,underline,|,align,formatOL,formatUL,|,quote,insertHR,fullscreen',
                            // excluded:strikeThrough,subscript,superscript,fontFamily,fontSize,color,inlineStyle,paragraphStyle,outdent,indent,emoticons
                            'stretch' => 'true',
                            'mode' => 'split',
                        ],

                        'article_note_edit'=>[
                            'tab'=> 'rainlab.blog::lang.post.tab_edit',
                            'type'=>'section',
                            'span'=>'full',
                            'label'=>'NOTE: save post for article editing fields features',
                        ],
                        'article_note_manage'=>[
                            'tab'=> 'rainlab.blog::lang.post.tab_manage',
                            'type'=>'section',
                            'span'=>'full',
                            'label'=>'NOTE: save post for article editing fields features',
                        ],
                    ]);

                    // $form->removeField('series');
                    // $form->addFields([
                    //     'series' => [
                    //         'label' => 'ginopane.blogtaxonomy::form.series.label' . '***',
                    //         'tab' => 'Taxonomy',
                    //         'type' => 'relation',
                    //         'nameFrom' => 'title',
                    //         'comment' => 'ginopane.blogtaxonomy::form.series.comment' . '***',
                    //         // October CMS has a bug with displaying of placeholders without an explicit empty option
                    //         // https://github.com/octobercms/october/pull/4060
                    //         'placeholder' => 'ginopane.blogtaxonomy::placeholders.series' . '***',
                    //         'emptyOption' => 'ginopane.blogtaxonomy::placeholders.series' . '***'
                    //     ],
                    // ]);

                    $model->bindEvent('model.afterSave', function () use ($model) {
                        if (!$model->article) {
                            $sessionKey = uniqid('session_key', true);
                            $article = new \SCS\NewsApi\Models\Article;
                            $model->article = $article;
                        }
                        $model->article->post_id = $model->id;
                        $model->article->save();
                    });
                }
            });
        }
    }

    public function registerComponents()
    {
        return [
            // Showcase for Hero-Editorial >>> home (heor spot), home_showcase
            'SCS\Editorials\Components\ShowcaseHeroEditorial' => 'showcaseHeroEditorial',
            // Showcase for features editorial in series >>> league (hero spot), editorials (hero spot)
            'SCS\Editorials\Components\ShowcaseHeroEditorialBySeries' => 'showcaseHeroEditorialBySeries',

            // Featured Editorials by Series (large carousel). >>> home, league
            'SCS\Editorials\Components\FeaturedEditorialsBySeries' => 'featuredEditorialsBySeries',
            // Featured Editorials by Category (large carousel). >>> home
            'SCS\Editorials\Components\FeaturedEditorialsByCategory' => 'featuredEditorialsByCategory',
            // Featured Editorials by Tag (large carousel). >>> team
            'SCS\Editorials\Components\FeaturedEditorialsByTag' => 'featuredEditorialsByTag',
            // Feature Editorial posts with this slug (large carousel). >>> player
            'SCS\Editorials\Components\FeatureEditorialsWithTagPlayer' => 'featureEditorialsWithTagPlayer',

            // All Editorials, can filters by category (sm carousel). >>> home
            'SCS\Editorials\Components\EditorialsByCategory' => 'editorialsByCategory',
            // Other Editorial posts with this tag (sm carousel). >>> league, team
            'SCS\Editorials\Components\EditorialsWithTag' => 'editorialsWithTag',
            // Other Editorial posts with this tag (sm carousel). >>> player
            'SCS\Editorials\Components\EditorialsWithTagPlayer' => 'editorialsWithTagPlayer',

            // Single Post - Editorials related to this one by tag (sm carousel). >>> editorial article, team, player
            'SCS\Editorials\Components\EditorialsRelatedCarousel' => 'editorialsRelatedCarousel',
            // Posts listing - List editorial posts as cards (cards). >>> editorials
            'SCS\Editorials\Components\EditorialCardList' => 'editorialCardList',
        ];
    }

    public function registerPermissions()
    {
        return [
            'scs.editorial.access' => [
                'label' => 'Access OSDB Editorials / Blog.',
                'tab' => 'Editorials',
                'roles' => ['developer','publisher', 'editor']
            ],
            /* 'scs.editorial.pushlish' => [
                'label' => 'Control the publish dates for Editorials.',
                'tab' => 'News API',
                'roles' => ['developer', 'publisher']
            ], */
        ];
    }

    public function registerNavigation()
    {
        return [];
    }
}
