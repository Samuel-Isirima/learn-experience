<?php namespace SCS\Search\Components;

use Config;
use OFFLINE\SiteSearch\Components\SearchResults;
use RainLab\Blog\Models\Post;
use SCS\Editorials\Controllers\Editorials;
use SCS\Osdb\Models\Player;

class OsdbSearchResults extends SearchResults
{
    public function componentDetails()
    {
        return [
            'name' => 'OsdbSearchResults Component',
            'description' => 'OsdbSearchResults'
        ];
    }

    public function onLoadMore()
    {
        $this->onRun();
        return [];
    }

    protected function search()
    {
        $results = parent::search();
        $results->each(function ($result) {
            if (($result->provider === 'Editorials' || $result->provider === 'Blog') && $result->model instanceof Post) {
                Editorials::addPostData($result->model);
            }
            if ($result->provider === 'Player') {
                $dbPlayer = Player::where('guid', $result->model['id'])->first();
                if ($dbPlayer && $dbPlayer->custom_headshot) {
                    $result->model['custom_headshot_url'] = url(Config::get('cms.storage.media.path')) . $dbPlayer->custom_headshot;
                }
            }
        });
        $providerOrder = [
            'Player' => -3e+6,
            'Team' => -2e+6,
            'Editorials' => -1e+6,
            'Blog' => -1e+6
        ];
        $uniqueResults = [];
        $results = $results->filter(function ($value) use (&$uniqueResults) {
            $key = $value->url;
            if (array_key_exists($key, $uniqueResults)) {
                return false;
            }
            $uniqueResults[$key] = true;
            return true;
        });
        $results = $results->sort(function($a, $b) use ($providerOrder) {
            if ($a->provider == $b->provider) {
                switch ($a->provider) {
                    case 'Player':
                    case 'Team':
                        return 0;
                    case 'Editorials':
                    case 'Blog':
                        return $b->model->published_at <=> $a->model->published_at;
                }
            }
            return $providerOrder[$a->provider] <=> $providerOrder[$b->provider];
        });
        return $results;
    }
}
