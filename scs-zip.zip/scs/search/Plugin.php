<?php namespace SCS\Search;

use Cms\Classes\Page;
use SCS\Osdb\Classes\ES\Players;
use SCS\Osdb\Classes\ES\Teams;
use SCS\Osdb\Controllers\Player;
use System\Classes\PluginBase;
use Cookie;
use Request;

/**
 * Search Plugin Information File
 */
class Plugin extends PluginBase
{
    public static $MAX_PLAYERS = 4;
    public static $MAX_TEAMS = 4;

    /**
     * Returns information about this plugin.
     *
     * @return array
     */
    public function pluginDetails()
    {
        return [
            'name' => 'Search',
            'description' => 'Search',
            'author' => 'SCS',
            'icon' => 'icon-search'
        ];
    }

    /**
     * Register method, called when the plugin is first registered.
     *
     * @return void
     */
    public function register()
    {

    }

    /**
     * Boot method, called right before the request route.
     *
     * @return array
     */
    public function boot()
    {
        $this->initSearchPlayers();
        $this->initSearchTeams();
        $this->initSettings();
    }

    /**
     * Registers any front-end components implemented in this plugin.
     *
     * @return array
     */
    public function registerComponents()
    {
        return [
            'SCS\Search\Components\OsdbSearchResults' => 'osdbSearchResults',
        ];
    }

    /**
     * Registers any back-end permissions used by this plugin.
     *
     * @return array
     */
    public function registerPermissions()
    {
        return [];

        return [
            'scs.search.some_permission' => [
                'tab' => 'Search',
                'label' => 'Some permission'
            ],
        ];
    }

    /**
     * Registers back-end navigation items for this plugin.
     *
     * @return array
     */
    public function registerNavigation()
    {
        return [];

        return [
            'search' => [
                'label' => 'Search',
                'url' => Backend::url('scs/search/mycontroller'),
                'icon' => 'icon-leaf',
                'permissions' => ['scs.search.*'],
                'order' => 500,
            ],
        ];
    }

    private function initSettings()
    {
        \Event::listen('backend.form.extendFields', function ($form) {
            if (!$form->model instanceof \OFFLINE\SiteSearch\Models\Settings)
                return;

            $form->addFields([
                'miso_enabled' => [
                    'label' => 'Miso search enabled',
                    'type' => 'switch',
                    'comment' => 'Enable Miso Search for players and teams (else ElasticSearch will be used)'
                ]
            ]);
        });
    }

    private function initSearchPlayers()
    {
        \Event::listen('offline.sitesearch.query', function ($query) {

            $response = Players::search($query, self::$MAX_PLAYERS);
            $players = $response->items;
            $results = [];
            foreach ($players as $player) {
                $results[] = [
                    'title' => $player['full_name'],
                    'text' => $player['full_name'],
                    'url' => Page::url('player', [
                        'leagueSlug' => strtolower($player['league']['alias']),
                        'playerName' => Player::encodeName($player['full_name']),
                        'slug' => $player['slug']
                    ]),
                    'relevance' => 20, // higher relevance results in a higher position in the results listing
                    'model' => $player,
                ];
                if (array_has($player, 'team') && $player['team'] != null) {
                    $team = $player['team'];
                    $team['is_player_team'] = true;
                    foreach (['league', 'division'] as $name) {
                        if (!array_has($team, $name)) $team[$name] = $player[$name] ?? null;
                    }
                    $results[] = [
                        'title' => $team['full_name'],
                        'text' => $team['full_name'],
                        'url' => Page::url('team', [
                            'leagueSlug' => strtolower($team['league']['alias']),
                            'slug' => strtolower($team['slug'])
                        ]),
                        'relevance' => 10, // higher relevance results in a higher position in the results listing
                        'model' => $team,
                    ];
                }
            }
            return [
                'provider' => 'Player',
                'results' => $results,
            ];
        });
    }

    private function initSearchTeams()
    {
        \Event::listen('offline.sitesearch.query', function ($query) {

            $response = Teams::search($query, self::$MAX_TEAMS);
            $teams = $response->items;
            $results = array_map(function ($team) {
                return [
                    'title' => $team['full_name'],
                    'text' => $team['full_name'],
                    'url' => Page::url('team', [
                        'leagueSlug' => strtolower($team['league']['alias']),
                        'slug' => strtolower($team['slug'])
                    ]),
                    'relevance' => 10, // higher relevance results in a higher position in the results listing
                    'model' => $team,
                ];
            }, $teams);

            // Making sure we always have even number of teams
            if (count($results) % 2 > 0) {
                array_push($results, [
                    'title' => '',
                    'text' => '',
                    'url' => '',
                    'relevance' => 10,
                ]);
            }

            return [
                'provider' => 'Team',
                'results' => $results,
            ];
        });
    }
}
