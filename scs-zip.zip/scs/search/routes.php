<?php

use Cms\Classes\Page;
use SCS\Osdb\Classes\ES\Players;
use SCS\Osdb\Classes\ES\Teams;
use SCS\Osdb\Controllers\Player;

Route::get('api/search', function () {

    $query = $_REQUEST['q'] ?? null;
    $results = [];
    $total = 0;

    if (!empty($query)) {

        $response = Players::search($query, 1);
        $players = $response->items;
        $total += min($response->total, \SCS\Search\Plugin::$MAX_PLAYERS) * 2;

        $response = Teams::search($query, 1);
        $teams = $response->items;
        $total += min($response->total, \SCS\Search\Plugin::$MAX_TEAMS);

        $foundTeams = [];

        if (!empty($players)) {
            foreach ($players as $player) {
                $player['birthdate_format'] = Player::formatBirthdate(array_get($player, 'birthdate'));
                $player['height_format'] = Player::formatHeight(array_get($player, 'height'));
                $player['weight_format'] = Player::formatWeight(array_get($player, 'weight'));
                $player['url'] = Page::url('player', [
                    'leagueSlug' => strtolower($player['league']['alias']),
                    'playerName' => Player::encodeName($player['full_name']),
                    'slug' => $player['slug']
                ]);
                $results[] = ['player' => $player];

                if (array_has($player, 'team') && $player['team'] != null) {
                    if ($player['team']['market'] === $player['team']['name']) {
                        $player['team']['market'] = '';
                    }
                    $team = $player['team'];
                    foreach (['league', 'division'] as $name) {
                        if (!array_has($team, $name))
                            $team[$name] = $player[$name] ?? null;
                    }
                    $team['url'] = Page::url('team', [
                        'leagueSlug' => strtolower($team['league']['alias']),
                        'slug' => $team['slug']
                    ]);
                    $results[] = ['team' => $team];
                    $foundTeams[$team['slug']] = true;
                }
            }
        }
        if (!empty($teams)) {
            foreach ($teams as $team) {
                if (array_key_exists($team['slug'], $foundTeams)) {
                    $total--;
                    continue;
                }
                $foundTeams[$team['slug']] = true;
                if ($team['market'] === $team['name']) {
                    $team['market'] = '';
                }
                $team['url'] = Page::url('team', [
                    'leagueSlug' => strtolower($team['league']['alias']),
                    'slug' => $team['slug']
                ]);
                $results[] = ['team' => $team];
            }
        }
    }

    return [
        'query' => $query,
        'results' => $results,
        'total' => count($results),
    ];
});

Route::get('api/cloudflare/purge_page', function () {
    $page = $_REQUEST['page'] ?? null;
    $page = trim($page, '/');

    $pages = ["https://osdbsports.com/$page", "https://www.osdbsports.com/$page"];

    return processCloudFlareCache($pages, $page);
});

Route::get('api/cloudflare/purge_player', function () {
$slug = $league = null;

    if ($_REQUEST['slug']){
        $slug = trim($_REQUEST['slug'], '/');
    }

    if ($_REQUEST['league']){
        $league = trim($_REQUEST['league'], '/');
    }
    $player_base_path = "osdbsports.com/$league/players/$slug";
    $pages = [
        "https://$player_base_path",
        "https://www.$player_base_path",
    ];

    $links = [
        'statistics',
        'contracts',
        'endorsements',
        'businesses',
        'philanthropys',
        'biography',
        'awards',
    ];

    foreach ($links as $link) {
        $pages[] = "https://$player_base_path/$link";
        $pages[] = "https://www.$player_base_path/$link";
    }

    return processCloudFlareCache($pages, "league=$league&slug=$slug");
});

function processCloudFlareCache($pages, $query = '')
{
    $zone = env('CLOUDFLARE_ZONE');
    $token = env('CLOUDFLARE_TOKEN');

    $url = "https://api.cloudflare.com/client/v4/zones/$zone/purge_cache";

    // Extract the request body
    $requestBody = [
        "files" => $pages
    ];

    // Forward the request to the Cloudflare API
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json",
        "Authorization: Bearer $token"
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestBody));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    // Extract the response
    $responseData = json_decode($response, true);

    $message = "Completed";
    $status = true;

    // Check if the response was successful
    if ($responseData && isset($responseData['success']) && $responseData['success']) {
        // Extract data from the successful response
        $message = "Cache cleared successfully.";
        $status = true;
    } else {
        // Extract error message from the response
        $errorMessage = isset($responseData['errors'][0]['message']) ? $responseData['errors'][0]['message'] : "Unknown error";
        $message = "Error: $errorMessage";
        $status = false;
    }

    return [
        'statue' => $status,
        'message' => $message,
        'query' => $query,
        'pages' => $pages,
        'raw_response' => $responseData
    ];
}
