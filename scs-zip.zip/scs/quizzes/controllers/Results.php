<?php namespace SCS\Quizzes\Controllers;

use BackendMenu;
use Backend\Classes\Controller;
use SCS\Quizzes\Models\Quiz;

/**
 * Results Back-end Controller
 */
class Results extends Controller
{
    /**
     * @var array Behaviors that are implemented by this controller.
     */
    public $implement = [
        'Backend.Behaviors.FormController',
        'Backend.Behaviors.ListController'
    ];

    /**
     * @var string Configuration file for the `FormController` behavior.
     */
    public $formConfig = 'config_form.yaml';

    /**
     * @var string Configuration file for the `ListController` behavior.
     */
    public $listConfig = 'config_list.yaml';

    public function __construct()
    {
        parent::__construct();

        BackendMenu::setContext('SCS.Quizzes', 'quizzes', 'results');
    }

    public function listExtendRecords($records)
    {
        foreach ($records as $record) {
            $record->quiz = Quiz::find($record->quiz_id);
        }
        return $records;
    }
}
