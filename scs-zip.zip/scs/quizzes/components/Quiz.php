<?php namespace SCS\Quizzes\Components;

use Cms\Classes\ComponentBase;
use Config;
use SCS\Osdb\Classes\ES\Players;
use SCS\Osdb\Models\Player;
use SCS\Osdb\Models\Team;
use SCS\Quizzes\Models\Quiz as QuizModel;
use SCS\Quizzes\Models\Result;

class Quiz extends ComponentBase
{
    public $quiz;
    public $answers;

    public function componentDetails()
    {
        return [
            'name' => 'Quiz Component',
            'description' => 'No description provided yet...'
        ];
    }

    public function defineProperties()
    {
        return [
            'quizId' => [
                'title' => 'Quiz id',
                'description' => 'Id of quiz to display',
                'type' => 'number'
            ],
            'quizSlug' => [
                'title' => 'Quiz slug',
                'description' => 'Slug of quiz to display',
                'type' => 'string'
            ],
            'leagueSlug' => [
                'title' => 'League slug',
                'description' => 'Slug of the league to choose the quiz from. Ignored if the "quizId" "quizSlug" is defined',
                'type' => 'string'
            ],
            'quizStyle' => [
                'title' => '"light" or "dark"',
                'description' => 'Light or dark style',
                'type' => 'string',
            ]
        ];
    }

    public function onRun()
    {
        $this->addJs('assets/js/SCS.Quizzes.js');
    }

    public function onRender()
    {
        $id = $this->property('quizId');
        $slug = $this->property('quizSlug');
        $leagueSlug = $this->property('leagueSlug');
        if (!isset($quiz) && isset($id)) {
            $quiz = QuizModel::find($id);
        }
        if (!isset($quiz) && isset($slug)) {
            $quiz = QuizModel::where('slug', $slug)->first();
        }
        if (!isset($quiz) && isset($leagueSlug)) {
            $quiz = QuizModel::where('league_slug', $leagueSlug)->get()->random();
        }
        if (!isset($quiz)) {
            $quiz = QuizModel::all()->random();
        }
        $this->quiz = $quiz;
        $this->answers = array_map(function ($i) use ($quiz) {
            $playerGuid = $quiz["answer${i}_player_guid"];
            $teamGuid = $quiz["answer${i}_team_guid"];
            $player = empty($playerGuid) ? null : Players::getById($playerGuid);
            if ($player) {
                $dbPlayer = Player::where('guid', $playerGuid)->first();
                if ($dbPlayer && $dbPlayer->custom_headshot) $player['custom_headshot_url'] = url(Config::get('cms.storage.media.path')).$dbPlayer->custom_headshot;
            }
            return [
                'text' => $quiz["answer$i"],
                'correct' => $quiz["answer${i}_correct"],
                'player' => $player,
                'team' => empty($teamGuid) ? null : Team::find($teamGuid),
            ];
        }, [1, 2, 3, 4]);
    }

    public function onQuizSubmit()
    {
        $quizId = $_REQUEST['quizId'];
        $quiz = $this->quiz = QuizModel::find($quizId);
        $result = Result::where('quiz_id', $quizId)->first() ?? Result::create([
                'quiz_id' => $quizId,
                'answer1' => 0,
                'answer2' => 0,
                'answer3' => 0,
                'answer4' => 0,
                'correct_answers' => 0,
                'total_answers' => 0
            ]);
        for ($i = 1; $i <= 4; $i++) {
            if (isset($_REQUEST["check-$i"])) {
                $result->{"answer$i"}++;
                $result->total_answers++;
                if ($quiz->{"answer${i}_correct"}) {
                    $result->correct_answers++;
                }
            }
        }
        $result->save();
        $percentages = $this->checkTotalPercentage(array_map(function ($i) use ($quiz, $result) {
            return round(100 * $result->{"answer$i"} / $result->{'total_answers'});
        }, [1, 2, 3, 4]));
        $this->answers = array_map(function ($i) use ($quiz, $result, $percentages) {
            return [
                'percentage' => $percentages[$i - 1],
                'correct' => $quiz->{"answer${i}_correct"},
                'selected' => isset($_REQUEST["check-$i"]),
                'type' => $_REQUEST["type-$i"] ?? '',
                'text' => $_REQUEST["text-$i"] ?? '',
                'image' => $_REQUEST["image-$i"] ?? '',
            ];
        }, [1, 2, 3, 4]);
        return [];
    }

    public function checkTotalPercentage($percentages): array
    {
        $totalPercentage = 0;
        $maxPercentageKey = null;
        foreach ($percentages as $key => $percentage) {
            $totalPercentage += $percentage;
            if (!isset($maxPercentageKey) || $percentage > $percentages[$maxPercentageKey]) {
                $maxPercentageKey = $key;
            }
        }
        if ($totalPercentage !== 100) {
            $percentages[$maxPercentageKey] += 100 - $totalPercentage;
        }
        return $percentages;
    }
}
