<?php

$answers = $record->{$column->columnName};
$answerText = $record->quiz->{$column->columnName};
$isCorrect = $record->quiz->{$column->columnName . '_correct'} ?? false;

?>
<span style="display: inline-block; min-width: 4ch; text-align: right"><?= $answers ?></span>
&nbsp;&nbsp;&nbsp;&nbsp;
<span <?php if ($isCorrect): ?>style="font-weight: bold"<?php endif; ?>><?= $answerText ?></span>