<?php

use October\Rain\Support\Facades\Html;

?>
<?= Html::strip($record->quiz->{$column->columnName}) ?>