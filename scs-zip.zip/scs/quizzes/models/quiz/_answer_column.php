<?php

$isCorrect = $record[$column->columnName . '_correct'] ?? false;

?>
<span <?php if ($isCorrect): ?>style="font-weight: bold"<?php endif; ?>><?= $value ?></span>