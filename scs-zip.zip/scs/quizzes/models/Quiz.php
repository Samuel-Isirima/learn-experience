<?php namespace SCS\Quizzes\Models;

use Model;
use SCS\Osdb\Models\League;
use SCS\Osdb\Models\Player;
use SCS\Osdb\Models\Team;

/**
 * Quiz Model
 */
class Quiz extends Model
{
    use \October\Rain\Database\Traits\Validation;

    /**
     * @var string The database table used by the model.
     */
    public $table = 'scs_quizzes_quizzes';

    /**
     * @var array Guarded fields
     */
    protected $guarded = ['*'];

    /**
     * @var array Fillable fields
     */
    protected $fillable = [];

    /**
     * @var array Validation rules for attributes
     */
    public $rules = [];

    /**
     * @var array Attributes to be cast to native types
     */
    protected $casts = [];

    /**
     * @var array Attributes to be cast to JSON
     */
    protected $jsonable = [];

    /**
     * @var array Attributes to be appended to the API representation of the model (ex. toArray())
     */
    protected $appends = [];

    /**
     * @var array Attributes to be removed from the API representation of the model (ex. toArray())
     */
    protected $hidden = [];

    /**
     * @var array Attributes to be cast to Argon (Carbon) instances
     */
    protected $dates = [
        'created_at',
        'updated_at',
        'publish_date'
    ];

    /**
     * @var array Relations
     */
    public $hasOne = [];
    public $hasMany = [];
    public $hasOneThrough = [];
    public $hasManyThrough = [];
    public $belongsTo = [
        'result' => ['SCS\Quizzes\Models\Result'],
        'league' => ['SCS\Osdb\Models\League', 'key' => 'league_slug', 'otherKey' => 'slug'],

        'team1' => ['SCS\Osdb\Models\Team', 'key' => 'answer1_team_guid'],
        'team2' => ['SCS\Osdb\Models\Team', 'key' => 'answer1_team_guid'],
        'team3' => ['SCS\Osdb\Models\Team', 'key' => 'answer1_team_guid'],
        'team4' => ['SCS\Osdb\Models\Team', 'key' => 'answer1_team_guid'],
        'player1' => ['SCS\Osdb\Models\Player', 'key' => 'answer1_player_guid'],
        'player2' => ['SCS\Osdb\Models\Player', 'key' => 'answer1_player_guid'],
        'player3' => ['SCS\Osdb\Models\Player', 'key' => 'answer1_player_guid'],
        'player4' => ['SCS\Osdb\Models\Player', 'key' => 'answer1_player_guid'],
    ];
    public $belongsToMany = [];
    public $morphTo = [];
    public $morphOne = [];
    public $morphMany = [];
    public $attachOne = [];
    public $attachMany = [];

    public function getLeagueSlugOptions($value, $formData)
    {
        return League::all()->mapWithKeys(function ($it) {
            return [$it->slug => $it->name];
        });
    }
}
