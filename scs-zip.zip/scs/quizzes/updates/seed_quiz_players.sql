UPDATE `scs_quizzes_quizzes`
SET `answer1_player_guid` = 'b6dde96e-3748-4cbe-86d2-798d5dffb3c0', `answer2_player_guid` = '7ff02e19-e829-4e56-9a34-233a71fce76c', `answer3_player_guid` = '03d77214-5780-4715-8df2-13de3af5ea2d', `answer4_player_guid` = '37fbc3a5-0d10-4e22-803b-baa2ea0cdb12'
WHERE `id`=37;
UPDATE `scs_quizzes_quizzes`
SET `answer1_player_guid` = 'c12fb587-fc86-471c-8a84-19caf31325ce', `answer2_player_guid` = '5e86a9c3-b4d0-4fe1-a551-acd83e5d60eb', `answer3_player_guid` = '', `answer4_player_guid` = '8c090758-6baa-468d-82fd-d47e17d5091b'
WHERE `id`=47;
UPDATE `scs_quizzes_quizzes`
SET `answer1_player_guid` = '87c481c7-7414-43cc-82df-19ca0c2ae22e', `answer2_player_guid` = '4bd60b33-9fbf-4156-ba2b-8264ac37b418', `answer3_player_guid` = '8960d61e-433b-41ea-a7ad-4e76be87b582', `answer4_player_guid` = 'f96db0af-5e25-42d1-a07a-49b4e065b364'
WHERE `id`=88;
UPDATE `scs_quizzes_quizzes`
SET `answer1_player_guid` = '16e13f52-32b1-416f-83ae-1cbf2f92cffc', `answer2_player_guid` = '0b3217b9-ba37-4222-95cb-a7a222441e8b', `answer3_player_guid` = '5c48ade7-4b9a-4757-9643-87a6e3839e2b', `answer4_player_guid` = '00f88be8-45f9-4237-b2b8-3271ec790d07'
WHERE `id`=89;