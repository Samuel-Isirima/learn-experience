UPDATE `scs_quizzes_quizzes`
SET `answer1_team_guid` = '', `answer2_team_guid` = '93941372-eb4c-4c40-aced-fe3267174393', `answer3_team_guid` = '55714da8-fcaf-4574-8443-59bfb511a524', `answer4_team_guid` = 'a09ec676-f887-43dc-bbb3-cf4bbaee9a18'
WHERE `id`=11;
UPDATE `scs_quizzes_quizzes`
SET `answer1_team_guid` = 'ce92bd47-93d5-4fe9-ada4-0fc681e6caa0', `answer2_team_guid` = '97354895-8c77-4fd4-a860-32e62ea7382a', `answer3_team_guid` = 'e627eec7-bbae-4fa4-8e73-8e1d6bc5c060', `answer4_team_guid` = 'f0e724b0-4cbf-495a-be47-013907608da9'
WHERE `id`=62;
UPDATE `scs_quizzes_quizzes`
SET `answer1_team_guid` = 'f0e724b0-4cbf-495a-be47-013907608da9', `answer2_team_guid` = 'de760528-1dc0-416a-a978-b510d20692ff', `answer3_team_guid` = 'f7ddd7fa-0bae-4f90-bc8e-669e4d6cf2de', `answer4_team_guid` = '3d08af9e-c767-4f88-a7dc-b920c6d2b4a8'
WHERE `id`=68;
UPDATE `scs_quizzes_quizzes`
SET `answer1_team_guid` = '33405046-04ee-4058-a950-d606f8c30852', `answer2_team_guid` = 'a20471b4-a8d9-40c7-95ad-90cc30e46932', `answer3_team_guid` = 'e6aa13a4-0055-48a9-bc41-be28dc106929', `answer4_team_guid` = '7d4fcc64-9cb5-4d1b-8e75-8a906d1e1576'
WHERE `id`=70;
UPDATE `scs_quizzes_quizzes`
SET `answer1_team_guid` = 'a20471b4-a8d9-40c7-95ad-90cc30e46932', `answer2_team_guid` = 'e627eec7-bbae-4fa4-8e73-8e1d6bc5c060', `answer3_team_guid` = '5fee86ae-74ab-4bdd-8416-42a9dd9964f3', `answer4_team_guid` = '768c92aa-75ff-4a43-bcc0-f2798c2e1724'
WHERE `id`=76;
UPDATE `scs_quizzes_quizzes`
SET `answer1_team_guid` = 'a20471b4-a8d9-40c7-95ad-90cc30e46932', `answer2_team_guid` = 'de760528-1dc0-416a-a978-b510d20692ff', `answer3_team_guid` = '04aa1c9d-66da-489d-b16a-1dee3f2eec4d', `answer4_team_guid` = '7b112545-38e6-483c-a55c-96cf6ee49cb8'
WHERE `id`=80;
UPDATE `scs_quizzes_quizzes`
SET `answer1_team_guid` = '1f6dcffb-9823-43cd-9ff4-e7a8466749b5', `answer2_team_guid` = '82d2d380-3834-4938-835f-aec541e5ece7', `answer3_team_guid` = '7d4fcc64-9cb5-4d1b-8e75-8a906d1e1576', `answer4_team_guid` = '6680d28d-d4d2-49f6-aace-5292d3ec02c2'
WHERE `id`=81;
UPDATE `scs_quizzes_quizzes`
SET `answer1_team_guid` = '7d4fcc64-9cb5-4d1b-8e75-8a906d1e1576', `answer2_team_guid` = 'e627eec7-bbae-4fa4-8e73-8e1d6bc5c060', `answer3_team_guid` = '7b112545-38e6-483c-a55c-96cf6ee49cb8', `answer4_team_guid` = 'a20471b4-a8d9-40c7-95ad-90cc30e46932'
WHERE `id`=86;
UPDATE `scs_quizzes_quizzes`
SET `answer1_team_guid` = 'f0e724b0-4cbf-495a-be47-013907608da9', `answer2_team_guid` = 'e627eec7-bbae-4fa4-8e73-8e1d6bc5c060', `answer3_team_guid` = 'cb2f9f1f-ac67-424e-9e72-1475cb0ed398', `answer4_team_guid` = '97354895-8c77-4fd4-a860-32e62ea7382a'
WHERE `id`=90;