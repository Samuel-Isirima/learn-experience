<?php namespace SCS\Quizzes\Updates;

use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;
use Schema;

class CreateQuizzesTable extends Migration
{
    public function up()
    {
        Schema::create('scs_quizzes_quizzes', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->timestamps();
            $table->timestamp('publish_date')->nullable();
            $table->boolean('is_published');
            $table->string('slug', 1024);
            $table->string('league_slug', 128);
            $table->string('question', 2048)->nullable();

            $table->string('answer1', 512)->nullable();
            $table->string('answer2', 512)->nullable();
            $table->string('answer3', 512)->nullable();
            $table->string('answer4', 512)->nullable();
            $table->boolean('answer1_correct');
            $table->boolean('answer2_correct');
            $table->boolean('answer3_correct');
            $table->boolean('answer4_correct');

            $table->string('answer1_player_guid', 256)->nullable();
            $table->string('answer2_player_guid', 256)->nullable();
            $table->string('answer3_player_guid', 256)->nullable();
            $table->string('answer4_player_guid', 256)->nullable();

            $table->string('answer1_team_guid', 256)->nullable();
            $table->string('answer2_team_guid', 256)->nullable();
            $table->string('answer3_team_guid', 256)->nullable();
            $table->string('answer4_team_guid', 256)->nullable();
        });
    }

    public function down()
    {
        Schema::dropIfExists('scs_quizzes_quizzes');
    }
}
