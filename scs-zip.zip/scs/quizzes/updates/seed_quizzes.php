<?php namespace SCS\Quizzes\Updates;

use October\Rain\Database\Updates\Migration;
use DB;

class SeedQuizzes extends Migration
{
    public function up()
    {
        Db::table('scs_quizzes_quizzes')->truncate();
        $sql = file_get_contents(base_path() . '/plugins/scs/quizzes/updates/seed_quizzes.sql');
        DB::unprepared($sql);
        $sql = file_get_contents(base_path() . '/plugins/scs/quizzes/updates/seed_quiz_players.sql');
        DB::unprepared($sql);
        $sql = file_get_contents(base_path() . '/plugins/scs/quizzes/updates/seed_quiz_teams.sql');
        DB::unprepared($sql);
    }

    public function down()
    {
    }
}
