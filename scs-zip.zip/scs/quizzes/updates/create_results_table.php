<?php namespace SCS\Quizzes\Updates;

use Schema;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;

class CreateResultsTable extends Migration
{
    public function up()
    {
        Schema::create('scs_quizzes_results', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->timestamps();
            $table->integer('quiz_id');
            $table->integer('answer1')->default(0);
            $table->integer('answer2')->default(0);
            $table->integer('answer3')->default(0);
            $table->integer('answer4')->default(0);
            $table->integer('correct_answers')->default(0);
            $table->integer('total_answers')->default(0);
        });
    }

    public function down()
    {
        Schema::dropIfExists('scs_quizzes_results');
    }
}
