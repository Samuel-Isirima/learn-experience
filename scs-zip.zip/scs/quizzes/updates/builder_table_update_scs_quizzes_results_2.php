<?php namespace SCS\Quizzes\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableUpdateScsQuizzesResults2 extends Migration
{
    public function up()
    {
        Schema::table('scs_quizzes_results', function($table)
        {
            $table->integer('correct_answers')->nullable()->change();
            $table->integer('total_answers')->nullable()->change();
        });
    }
    
    public function down()
    {
        Schema::table('scs_quizzes_results', function($table)
        {
            $table->integer('correct_answers')->nullable(false)->change();
            $table->integer('total_answers')->nullable(false)->change();
        });
    }
}
