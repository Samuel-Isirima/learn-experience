<?php namespace SCS\Quizzes\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableUpdateScsQuizzesResults extends Migration
{
    public function up()
    {
        Schema::table('scs_quizzes_results', function($table)
        {
            $table->integer('answer1')->nullable()->change();
            $table->integer('answer2')->nullable()->change();
            $table->integer('answer3')->nullable()->change();
            $table->integer('answer4')->nullable()->change();
        });
    }
    
    public function down()
    {
        Schema::table('scs_quizzes_results', function($table)
        {
            $table->integer('answer1')->nullable(false)->change();
            $table->integer('answer2')->nullable(false)->change();
            $table->integer('answer3')->nullable(false)->change();
            $table->integer('answer4')->nullable(false)->change();
        });
    }
}
