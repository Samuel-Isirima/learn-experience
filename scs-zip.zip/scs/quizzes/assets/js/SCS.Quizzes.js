(function ($) {

  $(document).on('change', '.quiz-form input[type=checkbox]', function () {
    var $form = $(this).closest('form');
    var answers = parseInt($form.data('answers')) || 1;
    $form.data('answers', answers - 1);
    if ($form.data('answers') === 0) {
      $form.addClass('disabled');
      $form.submit();
    }
  });

}(jQuery));