<?php namespace SCS\Quizzes;

use Backend;
use System\Classes\PluginBase;

/**
 * Quizzes Plugin Information File
 */
class Plugin extends PluginBase
{
    /**
     * Returns information about this plugin.
     *
     * @return array
     */
    public function pluginDetails()
    {
        return [
            'name' => 'Quizzes',
            'description' => 'No description provided yet...',
            'author' => 'SCS',
            'icon' => 'icon-leaf'
        ];
    }

    /**
     * Register method, called when the plugin is first registered.
     *
     * @return void
     */
    public function register()
    {

    }

    /**
     * Boot method, called right before the request route.
     *
     * @return array
     */
    public function boot()
    {

    }

    /**
     * Registers any front-end components implemented in this plugin.
     *
     * @return array
     */
    public function registerComponents()
    {
        return [
            'SCS\Quizzes\Components\Quiz' => 'quiz',
        ];
    }

    /**
     * Registers any back-end permissions used by this plugin.
     *
     * @return array
     */
    public function registerPermissions()
    {
        return [];
    }

    /**
     * Registers back-end navigation items for this plugin.
     *
     * @return array
     */
    public function registerNavigation()
    {
        return [
            'quizzes' => [
                'label' => 'Quizzes',
                'url' => Backend::url('scs/quizzes/quizzes'),
                'icon' => 'icon-question',
                'permissions' => ['scs.quizzes.*'],
                'order' => 300,
                'sideMenu' => [
                    'quizzes' => [
                        'label' => 'Quizzes',
                        'icon' => 'icon-question',
                        'url' => Backend::url('scs/quizzes/quizzes'),
                    ],
                    'results' => [
                        'label' => 'Quiz Results',
                        'icon' => 'icon-line-chart',
                        'url' => Backend::url('scs/quizzes/results'),
                    ],
                ]
            ],
        ];
    }
}
