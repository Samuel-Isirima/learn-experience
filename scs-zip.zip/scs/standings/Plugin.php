<?php namespace SCS\Standings;

use Backend;
use System\Classes\PluginBase;

class Plugin extends PluginBase
{
    public function pluginDetails()
    {
        return [
            'name' => 'Standings',
            'description' => 'Team, Player, and League standings',
            'author' => 'SCS',
            'icon' => 'icon-cube',
        ];
    }

    public function register() {}

    public function boot() {}

    public function registerComponents()
    {
        return [
            'SCS\Standings\Components\Standings' => 'teamStandings',
            'SCS\Standings\Components\LeagueLeaders' => 'teamLeagueLeaders',
        ];
    }

    public function registerPermissions()
    {
        return [];
    }

    public function registerNavigation()
    {
        return [];
    }
}
