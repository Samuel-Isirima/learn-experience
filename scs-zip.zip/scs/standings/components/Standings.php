<?php namespace SCS\Standings\Components;

use Cms\Classes\ComponentBase;

class Standings extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'Team Standings Component',
            'description' => 'Team Standings, filter by division'
        ];
    }

    public function defineProperties()
    {
        return [
            'league' => [ 'title' => 'League', 'type' => 'string', 'default' => 'NBA' ],
        ];
    }

    public function init()
    {

    }

    public $teamStandings;

    public function onRun() {
        $this->teamStandings = $this->page['teamStandings'] = $this->getTeamStandings($this->property('league'));
    }

    public function getTeamStandings($league, $filter = null) {
        // TODO get teams for this league according to filter
        // $teams = Teams::byLeague($league)->byFilter(???)->orderBy(???)
        // return $teams;

        // TODO: remove stub
        return [
            'data_headers' => [
                'logo' => '',
                'name' => 'TEAM',
                'wins' => 'W',
                'losses' => 'L'
            ],
            'teams' => [
                'toronto-raptors' => [
                    'logo' => 'https://osdb-assets.s3.us-west-2.amazonaws.com/images/league/nba/toronto-raptors/logo-light.svg',
                    'name' => 'Toronto Raptors',
                    'wins' => 11,
                    'losses' => 11
                ],
                'boston-celtics' => [ 'logo' => 'https://osdb-assets.s3.us-west-2.amazonaws.com/images/league/nba/boston-celtics/logo-light.svg', 'name' => 'Boston Celtics', 'wins' => 11, 'losses' => 11],
                'philadelphia-76ers' => [ 'logo' => 'https://osdb-assets.s3.us-west-2.amazonaws.com/images/league/nba/philadelphia-76ers/logo-light.svg', 'name' => 'Phil 76ers', 'wins' => 11, 'losses' => 11],
                'brooklyn-nets' => [ 'logo' => 'https://osdb-assets.s3.us-west-2.amazonaws.com/images/league/nba/brooklyn-nets/logo-light.svg', 'name' => 'Brook Nets', 'wins' => 11, 'losses' => 11],
                'new-york-knicks' => [ 'logo' => 'https://osdb-assets.s3.us-west-2.amazonaws.com/images/league/nba/new-york-knicks/logo-light.svg', 'name' => 'NYC Knicks', 'wins' => 11, 'losses' => 11],
            ]
        ];
    }
}
