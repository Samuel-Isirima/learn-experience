<?php namespace SCS\Standings\Components;

use Cms\Classes\ComponentBase;
use SCS\Osdb\Classes\ES\Leagues;
use SCS\Osdb\Models\Season;
use SCS\Osdb\Models\League;

class LeagueLeaders extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'League Leaders Component',
            'description' => 'Team League Leaders, filter by stat'
        ];
    }

    public function defineProperties()
    {
        return [
            'league' => [ 'title' => 'League', 'type' => 'string', 'default' => '' ],
        ];
    }

    public $_league;

    public function init()
    {
        $this->_league = $this->page['league'] = $this->property('league');
    }

    public $playerLeagueLeaders;

    public function onRun() {

        $this->_league = $this->page['league'] = $this->property('league');

        /* UNUSED CODE
        // TODO hardcode leagues WILL NOT WORK -RWC
        // TODO: also filters should not be hardcoded, should be placed into taxonomy
        switch ($this->_league) {
            case 'nfl':
                $filter_stat = 'seasons.teams.statistics_nfl.receiving.touchdowns';
                break;
            case 'nba':
                $filter_stat = 'seasons.teams.statistics_nba.average.points';
                break;
            case 'mlb':
                $filter_stat = 'seasons.teams.statistics_mlb.hitting.overall.onbase.hr';
                break;
            default:
                \Log::error('~~ LeagueLeaders->onRun - invalid league lookup: ' . $this->_league);
                return \Redirect::to('404')->with('message', 'Cannot find that league');
                // NOTE: using redirect instead of error for better UX
                //    >>> throw new \ApplicationException('Cannot find that league '.$this->_league);

        }
        $this->playerLeagueLeaders = $this->page['playerLeagueLeaders'] = $this->getPlayerLeagueLeadersByLeague($this->_league, $filter_stat);
        */

        // set up current season for widgets

        $this->page['widgetPreSeason'] = false;
        $season = Season::getCurrentSeasonByLeagueSlug($this->_league);

        if (!empty($season)) {
            if ($this->_league == 'nfl') {
                if (!empty($season->type) &&  $season->type == 'PRE') {
                    $this->page['widgetPreSeason'] = true;
                }
                $this->page['widgetSeason'] = $season->year;
            } else {
                $this->page['widgetSeason'] = $season->season_id;
            }
        } else {
            $league = League::where('slug', $this->_league)->first();
            $leagueGuid = $league['guid'];
            $this->page['widgetSeason'] = Season::getCurrentSeason($leagueGuid);
        }
    }

    /* UNUSED CODE
    function onFilter()
    {
        $this->_league = $this->page['league'] = $this->property('league');
        $filter_stat = 'seasons.teams.statistics_'. strtolower($this->_league) .'.'. post('filter_stat');

        $this->playerLeagueLeaders = $this->page['playerLeagueLeaders'] = $this->getPlayerLeagueLeadersByLeague($this->_league, $filter_stat);

        //need to refresh the load more base don the index reset + filter form elements
        return ['#divLeagueLeaders' => $this->renderPartial('@grid_leaders')];
    }*/


    public function getPlayerLeagueLeadersByLeague($league, $filter = null) {
        // TODO get players for this league according to filter
        // $players = Player::byLeague($league)->byFilter(???)->orderBy(???)
        // return $players;

        // TODO: remove hardcoded year!
        $adsData = Leagues::getLeaders($league, 2020, $filter, 5);
        //$position = array_get($adsData, 'position');

        $rtnGames = array(
            'data_headers' => [
                'headshot' => '',
                'name' => 'PLAYER NAME',
                'stat' => 'pts',
            ]
        );

        $filter_stat = str_replace('seasons.teams.', '', $filter);
        $players_array = array();
        foreach ($adsData as $player)
        {
            $statisticscore = array_get($player, 'seasons')[0];            //working with the most recent year only.
            $statisticsfirstteam = array_get($statisticscore, 'teams')[0];  //working with the first team only right now.

            $player_record = array(
                                "headshot" => array_get($player, "headshot.high_res"),
                                "name" => array_get($player, "full_name"),
                                "stat" => array_get($statisticsfirstteam, $filter_stat) );

            array_push($players_array, $player_record);
        }

        $rtnGames["players"] = $players_array;

        return $rtnGames;
    }
}
