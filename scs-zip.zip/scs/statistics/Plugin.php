<?php namespace SCS\Statistics;

use Backend;
use System\Classes\PluginBase;

class Plugin extends PluginBase
{

    public function pluginDetails()
    {
        return [
            'name'        => 'Statistics',
            'description' => 'Sports Statistics Component',
            'author'      => 'SCS',
            'icon'        => 'icon-cube'
        ];
    }

    public function register() {}

    public function boot() {}

    public function registerComponents()
    {
        return [
            'SCS\Statistics\Components\StatisticsPlayerSummary' => 'statisticsPlayerSummary',
            'SCS\Statistics\Components\PlayerStats' => 'playerStats',
            'SCS\Statistics\Components\DraftResults' => 'draftResults',
        ];
    }

    public function registerPermissions()
    {
        return [];
    }

    public function registerNavigation()
    {
        return [];
    }
}
