<?php namespace scs\statistics\Models;

use Backend\Models\ExportModel;
use SCS\Statistics\Models\PlayerPositionStatistics;

class PlayerPositionStatisticsExport extends ExportModel
{
    public function exportData($columns, $sessionKey = null)
    {
        $items = PlayerPositionStatistics::select('*')
            ->get();

        $items->each(function($item) use ($columns) {
            $item->addVisible($columns);
        });
        $collection = collect($items->toArray());
        
        $data = $collection->map(function ($item) {
            if(is_array($item)){
                foreach($item as $key => $value) {
                    if(is_array($value)) {
                        $item[$key] = json_encode($value);
                    }
                }
            }
            return $item;
        });

        return $data->toArray();
    }
}