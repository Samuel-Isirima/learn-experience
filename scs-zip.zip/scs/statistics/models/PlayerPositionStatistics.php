<?php namespace SCS\Statistics\Models;

use Model;
use SCS\Osdb\Classes\ES\Players;

/**
 * Poll Model
 */
class PlayerPositionStatistics extends Model
{
    use \October\Rain\Database\Traits\Validation;

    /**
     * @var string The database table used by the model.
     */
    public const TABLE = 'scs_statistics_player_position_statistics';
    public $table = 'scs_statistics_player_position_statistics';

    /**
     * @var array Guarded fields
     */
    protected $guarded = ['*'];

    /**
     * @var array Fillable fields
     */
    protected $fillable = [];

    /**
     * @var array Validation rules for attributes
     */
    public $rules = [];

    /**
     * @var array Attributes to be cast to native types
     */
    protected $casts = [];

    /**
     * @var array Attributes to be cast to JSON
     */
    protected $jsonable = [];

    /**
     * @var array Attributes to be appended to the API representation of the model (ex. toArray())
     */
    protected $appends = [];

    /**
     * @var array Attributes to be removed from the API representation of the model (ex. toArray())
     */
    protected $hidden = [];

    /**
     * @var array Attributes to be cast to Argon (Carbon) instances
     */
    protected $dates = [
        'created_at',
        'updated_at'
    ];

    /**
     * @var array Relations
     */
    public $hasOne = [
    ];
    public $hasMany = [
    ];
    public $hasOneThrough = [];
    public $hasManyThrough = [];
    public $belongsTo = [
        'league' => ['scs\osdb\models\League', 'key' => 'league_guid']
    ];
    public $belongsToMany = [];
    public $morphTo = [];
    public $morphOne = [


    ];
    public $morphMany = [];
    public $attachOne = [

    ];
    public $attachMany = [];

    public function getPositionOptions($value, $formData)
    {
        // TODO - get from ES, add name, get specific for league
        return [
            'QB'    => 'Quarterback',
            'RB'    => 'Running Back',
            'FB'    => 'Fullback'
        ];
    }

    public function getPositionOptionsFilter()
    {
        // TODO - get from ES, add name, get specific for league
        $league = "nfl";
        $positions = Players::getPositionsList($league);
        $result = [];
        foreach ($positions as $position){
            $result[$position] = $position;
        }
        return $result;
    }

    public function getPathGroupsFilter()
    {
        $result = [];
        $result[] = 'penalties';
        $result[] = 'somethingelse';
    }
}
