<?php namespace scs\statistics\Models;

use Backend\Models\ImportModel;
use Illuminate\Support\Facades\DB;
use SCS\Statistics\Models\PlayerStatisticsDictionary as PlayerStatisticsDictionary;

class PlayerStatisticsGroupsImport extends ImportModel
{
    /**
     * @var array The rules to be applied to the data.
     */
    public $rules = ['path' => 'required', 'league_guid' => 'required'];

    public function importData($results, $sessionKey = null)
    {
        set_time_limit(3000);   //setting a longer time limit due to the amount of data this is going to parse.

        foreach ($results as $row => $data) {
            try {

                $group = $data['group'];
                $leagueGuid = $data['league_guid'];

                $item = Db::table(PlayerStatisticsGroups::TABLE)->where('group', $group)->where('league_guid', $leagueGuid)->first();

                if ($item)
                {
                    // Update only empty values of existing lines
                    if( empty($item -> abbr) )
                    {
                        Db::table(PlayerStatisticsDictionary::TABLE)
                            ->where('group', $group)
                            ->where('league_guid', $leagueGuid)
                            ->update(['abbr' => $data['abbr']
                        ]);
                        $this->logUpdated();
                    }
                    if( $item -> order == null )
                    {
                        Db::table(PlayerStatisticsDictionary::TABLE)
                            ->where('group', $group)
                            ->where('league_guid', $leagueGuid)
                            ->update(['order' => $data['order']
                        ]);
                        $this->logUpdated();
                    }
                }
                else
                {
                    Db::table(PlayerStatisticsDictionary::TABLE)->insert([
                        'group' => $data['group'],
                        'abbr' => $data['abbr'],
                        'order' => $data['order'],
                        'league_guid' => $data['league_guid']
                    ]);
                    $this->logCreated();
                }
                
            } catch (\Exception $ex) {
                $this->logError($row, $ex->getMessage());
            }
        }
        
    }
}