<?php namespace scs\statistics\Models;

use Backend\Models\ImportModel;
use Illuminate\Support\Facades\DB;
use SCS\Statistics\Models\PlayerStatisticsDictionary as PlayerStatisticsDictionary;

/**
 * PlayerStatisticsDictionaryImport Model
 */
class PlayerStatisticsDictionaryImport extends ImportModel
{
    /**
     * @var array The rules to be applied to the data.
     */
    public $rules = ['path' => 'required', 'league_guid' => 'required'];

    public function importData($results, $sessionKey = null)
    {
        set_time_limit(3000);   //setting a longer time limit due to the amount of data this is going to parse.

        foreach ($results as $row => $data) {
            try {

                $path = $data['path'];
                $leagueGuid = $data['league_guid'];

                $item = Db::table(PlayerStatisticsDictionary::TABLE)->where('path', $path)->where('league_guid', $leagueGuid)->first();

                if ($item)
                {
                    // Update only empty values of existing lines
                    if( empty($item -> abbr) )
                    {
                        Db::table(PlayerStatisticsDictionary::TABLE)
                            ->where('path', $path)
                            ->where('league_guid', $leagueGuid)
                            ->update(['abbr' => $data['abbr']
                        ]);
                        $this->logUpdated();
                    }
                    if( empty($item -> name) )
                    {
                        Db::table(PlayerStatisticsDictionary::TABLE)
                            ->where('path', $path)
                            ->where('league_guid', $leagueGuid)
                            ->update(['name' => $data['name']
                        ]);
                        $this->logUpdated();
                    }
                }
                else
                {
                    Db::table(PlayerStatisticsDictionary::TABLE)->insert([
                        'path' => $data['path'],
                        'abbr' => $data['abbr'],
                        'name' => $data['name'],
                        'league_guid' => $data['league_guid']
                    ]);
                    $this->logCreated();
                }
                
            } catch (\Exception $ex) {
                $this->logError($row, $ex->getMessage());
            }
        }
        
    }
}