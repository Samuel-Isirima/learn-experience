<?php namespace SCS\Statistics\Models;

use Model;
use SCS\Osdb\Classes\ES\Players;

/**
 * Poll Model
 */
class PlayerStatisticsGroups extends Model
{
    use \October\Rain\Database\Traits\Validation;

    /**
     * @var string The database table used by the model.
     */
    public const TABLE = 'scs_statistics_player_statistics_groups';
    public $table = 'scs_statistics_player_statistics_groups';

    /**
     * @var array Guarded fields
     */
    protected $guarded = ['*'];

    /**
     * @var array Fillable fields
     */
    protected $fillable = [];

    /**
     * @var array Validation rules for attributes
     */
    public $rules = [];

    /**
     * @var array Attributes to be cast to native types
     */
    protected $casts = [];

    /**
     * @var array Attributes to be cast to JSON
     */
    protected $jsonable = [];

    /**
     * @var array Attributes to be appended to the API representation of the model (ex. toArray())
     */
    protected $appends = [];

    /**
     * @var array Attributes to be removed from the API representation of the model (ex. toArray())
     */
    protected $hidden = [];

    /**
     * @var array Attributes to be cast to Argon (Carbon) instances
     */
    protected $dates = [
        'created_at',
        'updated_at'
    ];

    /**
     * @var array Relations
     */
    public $hasOne = [
    ];
    public $hasMany = [
    ];
    public $hasOneThrough = [];
    public $hasManyThrough = [];
    public $belongsTo = [
        'league' => ['scs\osdb\models\League', 'key' => 'league_guid']
    ];
    public $belongsToMany = [];
    public $morphTo = [];
    public $morphOne = [


    ];
    public $morphMany = [];
    public $attachOne = [

    ];
    public $attachMany = [];

    public function extendWithESData()
    {

    }

    public function getPlayerPositionOptions($value, $formData)
    {
        $options = ['' => 'None'];
        if (isset($formData->league)) {
            $positions = Players::getPositionsList($formData->league->slug);
            foreach ($positions as $position) {
                $options[$position] = $position;
            }
        }
        return $options;
    }
}
