<?php namespace scs\statistics\Models;

use Backend\Models\ImportModel;
use Illuminate\Support\Facades\DB;
use SCS\Statistics\Models\PlayerPositionStatistics;

class PlayerPositionStatisticsImport extends ImportModel
{
    /**
     * @var array The rules to be applied to the data.
     */
    public $rules = ['path' => 'required', 'position' => 'required', 'league_guid' => 'required'];

    public function importData($results, $sessionKey = null)
    {
        set_time_limit(3000);   //setting a longer time limit due to the amount of data this is going to parse.

        // TODO? first set all records is_featured = false?
        foreach ($results as $row => $data) {
            try {

                $path = $data['path'];
                $position = $data['position'];
                $leagueGuid = $data['league_guid'];

                $item = Db::table(PlayerPositionStatistics::TABLE)
                    ->where('path', $path)
                    ->where('position', $position)
                    ->where('league_guid', $leagueGuid)->first();

                if ($item)
                {
                    // Update is_featured value
                    Db::table(PlayerPositionStatistics::TABLE)
                        ->where('path', $path)
                        ->where('position', $position)
                        ->where('league_guid', $leagueGuid)
                        ->update(['is_featured' => $data['is_featured']
                    ]);
                    $this->logUpdated();
                }
                else
                {
                    Db::table(PlayerPositionStatistics::TABLE)->insert([
                        'path' => $data['path'],
                        'position' => $data['position'],
                        'is_featured' => $data['is_featured'],
                        'league_guid' => $data['league_guid']
                    ]);
                    $this->logCreated();
                }
                
            } catch (\Exception $ex) {
                $this->logError($row, $ex->getMessage());
            }
        }
        
    }
}