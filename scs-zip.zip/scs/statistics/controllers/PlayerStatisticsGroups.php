<?php namespace SCS\Statistics\Controllers;

use Backend\Classes\Controller;
use BackendMenu;
use Illuminate\Support\Facades\DB;
use SCS\Osdb\Classes\ES\Players;
use SCS\Osdb\Models\League;
use SCS\Statistics\Models;
use SCS\Statistics\Models\PlayerStatisticsGroups as Model;
use Flash;

class PlayerStatisticsGroups extends Controller
{
    public $implement = [        'Backend\Behaviors\ListController',        'Backend\Behaviors\FormController', 'Backend.Behaviors.ImportExportController'    ];

    public $listConfig = 'config_list.yaml';
    public $formConfig = 'config_form.yaml';
    public $importExportConfig = 'config_import_export.yaml';

    public function __construct()
    {
        parent::__construct();
        BackendMenu::setContext('SCS.Osdb', 'main-menu-osdb', 'side-menu-playerstatisticsgroups');
    }

    // Loads all available different statistics groups from ES
    public function onLoadStatistics()
    {
        // TODO: add league parameter
        // TODO: process multi-level for NBA/MLB
        $leagueSlug = 'nfl';
        $league = Db::table(League::TABLE)->where('slug', $leagueSlug)->first();

        $positions = Players::getPositionsList($leagueSlug);
        foreach($positions as $position) {
            $items = Players::getStatisticsList($leagueSlug, $position);
            $groups = [];
            foreach ($items as $item){
                foreach ($item['seasons'] as $season) {
                    if (!isset($season['teams'])) break;
                    foreach ($season['teams'] as $team) {
                        if (!isset($team['statistics_'.$leagueSlug])) break;
                        foreach ($team['statistics_'.$leagueSlug] as $groupKey=>$groupValue){
                            if (!is_array($groupValue)) {
                                $group = 'games';
                            } else {
                                $group = $groupKey;
                            }
                            if (!in_array($group, $groups)) $groups[] = $group;
                        }
                    }
                }
            }
            // ??? sort($statistics);

            // put to DB
            $dbStats = Db::table(Model::TABLE)
                ->where('league_guid', $league->guid)
                ->where('player_position', $position)
                ->get(["group"]);
            $groupList = [];
            foreach ($dbStats as $item){
                $groupList[] = $item->group;
            }
            $count = 0;
            foreach ($groups as $group) {
                if (!in_array($group, $groupList)){
                    Db::table(Model::TABLE)->insert([
                        'group' => $group,
                        'player_position' => $position,
                        'league_guid' => $league->guid
                    ]);
                    $count++;
                }
            }
        }

        Flash::success("Items were loaded");
    }
}
