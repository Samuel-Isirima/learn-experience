<?php namespace SCS\Statistics\Controllers;

use Backend\Classes\Controller;
use BackendMenu;
use Illuminate\Support\Facades\DB;
use SCS\Osdb\Classes\ES\Players;
use SCS\Osdb\Classes\ES\Teams;
use SCS\Osdb\Models\League;
use Flash;
use SCS\Statistics\Models\PlayerPositionStatistics as Model;

class PlayerPositionStatistics extends Controller
{
    public $implement = [        'Backend\Behaviors\ListController',        'Backend\Behaviors\FormController', 'Backend.Behaviors.ImportExportController'    ];

    public $listConfig = 'config_list.yaml';
    public $formConfig = 'config_form.yaml';
    public $importExportConfig = 'config_import_export.yaml';

    public function __construct()
    {
        parent::__construct();
        BackendMenu::setContext('SCS.Osdb', 'main-menu-osdb', 'side-menu-positionstatistics');
    }

    // Loads all available different statistics paths from ES for different positions
    public function onLoadStatistics()
    {
        // TODO: add league parameter
        // TODO: process multi-level for NBA/MLB
        $count = 0;

        $leagueSlug = 'nfl';
        $league = Db::table(League::TABLE)->where('slug', $leagueSlug)->first();

        $positions = Players::getPositionsList($leagueSlug);

        foreach($positions as $position) {

            $items = Players::getStatisticsList($leagueSlug, $position);

            $statistics = [];
            foreach ($items as $item) {
                foreach ($item['seasons'] as $season) {
                    if (!isset($season['teams'])) break;
                    foreach ($season['teams'] as $team) {
                        if (!isset($team['statistics_' . $leagueSlug])) break;
                        foreach ($team['statistics_' . $leagueSlug] as $groupKey => $groupValue) {
                            if (!is_array($groupValue)) {
                                $group = 'games';
                                $stats = [];
                                $stats[$groupKey] = $groupValue;
                            } else {
                                $group = $groupKey;
                                $stats = $groupValue;
                            }
                            foreach ($stats as $path => $value) {
                                $fullPath = $group . '.' . $path;
                                if (!in_array($fullPath, $statistics)) {
                                    $statistics[] = $fullPath;
                                }
                            }
                        }
                    }
                }
            }
            sort($statistics);

            // put to DB
            $dbStats = Db::table(Model::TABLE)
                ->where('league_guid', $league->guid)
                ->where('position', $position)
                ->get(["path"]);
            $pathList = [];
            foreach ($dbStats as $item) {
                $pathList[] = $item->path;
            }
            foreach ($statistics as $statistic) {
                if (!in_array($statistic, $pathList)) {
                    Db::table(Model::TABLE)->insert([
                        'path' => $statistic,
                        'position' => $position,
                        'league_guid' => $league->guid
                    ]);
                    $count++;
                }
            }
        }
        Flash::success("$count items was loaded");
    }
}
