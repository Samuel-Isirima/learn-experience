<?php namespace SCS\Statistics\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class UpdatePlayerStatisticsDictionary extends Migration
{
    public function up()
    {

        Schema::table('scs_statistics_player_statistics_dictionary', function ($table) {
            // There is no column 'position'
//            $table->dropColumn('position');
            $table->string('abbr')->nullable()->change();
        });
    }

    public function down()
    {
        Schema::table('scs_statistics_player_statistics_dictionary', function ($table) {
//            $table->string('position', 64)->nullable;
        });
    }
}
