<?php namespace SCS\Statistics\Updates;

use Schema;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;

class CreatePlayerStatisticsDictionaryTable extends Migration
{
    public function up()
    {
        Schema::create(
            'scs_statistics_player_statistics_dictionary',
            function (Blueprint $table) {
                $table->engine = 'InnoDB';
                $table->increments('id');
                $table->timestamp('created_at')->nullable();
                $table->timestamp('updated_at')->nullable();
                $table->timestamp('deleted_at')->nullable();
                $table->string('name', 512)->nullable();
                $table->string('abbr', 64);
                $table->string('path', 512);
                $table->string('league_guid');
            }
        );
    }

    public function down()
    {
        Schema::dropIfExists('scs_statistics_player_statistics_dictionary');
    }
}
