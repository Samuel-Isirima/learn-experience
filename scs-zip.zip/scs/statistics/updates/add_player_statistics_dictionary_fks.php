<?php namespace SCS\Statistics\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class AddPlayerStatisticsDictionaryFKs extends Migration
{
    public function up()
    {

        Schema::table('scs_statistics_player_statistics_dictionary', function ($table) {
            $table->foreign('league_guid')->references('guid')->on('scs_osdb_league');
        });
    }

    public function down()
    {
        Schema::table('scs_statistics_player_statistics_dictionary', function ($table) {
            $table->dropForeign('scs_statistics_player_statistics_dictionary_league_guid_foreign');
        });
    }
}
