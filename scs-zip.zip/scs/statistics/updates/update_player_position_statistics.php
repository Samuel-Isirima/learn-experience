<?php namespace SCS\Statistics\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class UpdatePlayerPositionStatistics extends Migration
{
    public function up()
    {

        Schema::table('scs_statistics_player_position_statistics', function ($table) {
            $table->dropColumn('statistics_id');
            $table->string('path', 512)->nullable;
        });
    }

    public function down()
    {
        Schema::table('scs_statistics_player_position_statistics', function ($table) {
            $table->integer('statistics_id')->nullable;
            $table->dropColumn('path');
        });
    }
}
