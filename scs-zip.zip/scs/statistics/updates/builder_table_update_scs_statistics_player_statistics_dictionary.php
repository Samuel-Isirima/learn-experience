<?php namespace SCS\Statistics\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableUpdateScsStatisticsPlayerStatisticsDictionary extends Migration
{
    public function up()
    {
        Schema::table('scs_statistics_player_statistics_dictionary', function($table)
        {
            $table->string('description', 1024)->nullable();
        });
    }
    
    public function down()
    {
        Schema::table('scs_statistics_player_statistics_dictionary', function($table)
        {
            $table->dropColumn('description');
        });
    }
}
