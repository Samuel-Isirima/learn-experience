<?php namespace SCS\Statistics\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class UpdatePlayerStatisticsGroupsAbbr extends Migration
{
    public function up()
    {
        Schema::table('scs_statistics_player_statistics_groups', function ($table) {
            $table->string('abbr')->nullable()->change();
        });
    }

    public function down()
    {
        Schema::table('scs_statistics_player_statistics_groups', function ($table) {
        });
    }
}
