<?php namespace SCS\Statistics\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class AddPlayerStatisticsGroupsPlayerPosition extends Migration
{
    public function up()
    {
        Schema::table('scs_statistics_player_statistics_groups', function ($table) {
            $table->string('player_position', 64)->nullable();
        });
    }

    public function down()
    {
        Schema::table('scs_statistics_player_statistics_groups', function ($table) {
            $table->dropColumn('player_position');
        });
    }
}
