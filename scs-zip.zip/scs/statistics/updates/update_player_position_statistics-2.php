<?php namespace SCS\Statistics\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class UpdatePlayerPositionStatistic2 extends Migration
{
    public function up()
    {

        Schema::table('scs_statistics_player_position_statistics', function ($table) {
            $table->integer('order')->nullable();
        });
    }

    public function down()
    {
        Schema::table('scs_statistics_player_position_statistics', function ($table) {
            $table->dropColumn('order');
        });
    }
}
