<?php namespace SCS\Polls;

use Backend;
use System\Classes\PluginBase;

class Plugin extends PluginBase
{
    public function pluginDetails()
    {
        return [
            'name'        => 'Polls',
            'description' => 'Team and Player polls',
            'author'      => 'SCS',
            'icon'        => 'icon-bar-chart'
        ];
    }

    public function register()
    {
    }

    public function boot()
    {
    }

    public function registerComponents()
    {
        return [
            'SCS\Polls\Components\PlayerPoll' => 'playerPoll',
            'SCS\Polls\Components\TeamPoll' => 'teamPoll',
            'SCS\Polls\Components\Poll' => 'poll',
        ];
    }

    public function registerPermissions()
    {
        return [];
    }

    public function registerNavigation()
    {
        return [
            'polls' => [
                'label'       => 'Polls',
                'url'         => Backend::url('scs/polls/polls'),
                'icon'        => 'icon-bar-chart',
                'permissions' => ['scs.polls.*'],
                'order'       => 300,
                'sideMenu' => [
                    'polls' => [
                        'label' => 'Polls',
                        'icon'        => 'icon-bar-chart',
                        'url'         => Backend::url('scs/polls/polls'),
                    ],
                    'results' => [
                        'label' => 'Poll Results',
                        'icon'        => 'icon-line-chart',
                        'url'         => Backend::url('scs/polls/results'),
                    ],
                ]
            ],
        ];
    }
}
