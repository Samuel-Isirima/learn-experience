<?php namespace SCS\Polls\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableUpdateScsPollsPolls2 extends Migration
{
    public function up()
    {
        Schema::table('scs_polls_polls', function($table)
        {
            $table->dropColumn('is_archived');
        });
    }
    
    public function down()
    {
        Schema::table('scs_polls_polls', function($table)
        {
            $table->boolean('is_archived');
        });
    }
}
