<?php namespace SCS\Polls\Updates;

use Schema;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;

class CreatePollsTable extends Migration
{
    public function up()
    {
        Schema::create(
            'scs_polls_polls',
            function (Blueprint $table) {
                $table->engine = 'InnoDB';
                $table->increments('id');
                $table->timestamp('created_at')->nullable();
                $table->timestamp('updated_at')->nullable();
                $table->timestamp('deleted_at')->nullable();
                $table->timestamp('publish_date')->nullable();
                $table->boolean('is_published');
                $table->boolean('is_archived');
                $table->string('name', 128);
                $table->string('description', 512)->nullable();
                $table->string('poll_type', 64);
                $table->integer('poll_options')->default(2);
                $table->string('question', 1024)->nullable();

                // teams
                $table->string('team1_guid')->default('0')->nullable();
                $table->string('team2_guid')->default('0')->nullable();
                $table->string('team3_guid')->default('0')->nullable();
                $table->string('team4_guid')->default('0')->nullable();
                $table->integer('team1_votes')->default(0);
                $table->integer('team2_votes')->default(0);
                $table->integer('team3_votes')->default(0);
                $table->integer('team4_votes')->default(0);

                // players
                $table->string('player1_guid')->default(0)->nullable();
                $table->string('player2_guid')->default(0)->nullable();
                $table->string('player3_guid')->default(0)->nullable();
                $table->string('player4_guid')->default(0)->nullable();
                $table->integer('player1_votes')->default(0);
                $table->integer('player2_votes')->default(0);
                $table->integer('player3_votes')->default(0);
                $table->integer('player4_votes')->default(0);
            }
        );
    }

    public function down()
    {
        Schema::dropIfExists('scs_polls_polls');
    }
}
