<?php namespace SCS\Polls\Updates;

use Schema;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;
use SCS\Polls\Models\Poll;

class SeedTestPoll extends Migration
{
    public function up()
    {
        Poll::create([
            'id' => '1',
            'name' => 'player-poll',
            'description' => '<h3>This is a test Player poll</h3><p>name == player-poll</p>',
            'poll_type' => 'player',
            'poll_options' => '4',
            'question' => '<h2>Player Poll Question</h2>',
            'player1_guid' => 'db72e294-1c54-454a-96b9-0b4fd2f38112',
            'player2_guid' => 'c1bb78ed-4ce7-4e8c-b30c-06f8148d550a',
            'player3_guid' => '94510e36-d0ea-48c5-9c7e-b09b31c5c218',
            'player4_guid' => 'bc79d44f-bd11-4fdc-acd6-14045788da41',
            'is_published' => 1,
            'is_archived' => 0

        ]);
        Poll::create([
            'id' => '2',
            'name' => 'team-poll',
            'description' => '<h3>This is a test Team poll</h3><p>name == team-poll</p>',
            'poll_type' => 'team',
            'poll_options' => '2',
            'question' => '<h2>Team Poll Question</h2>',
            'team1_guid' => 'ce92bd47-93d5-4fe9-ada4-0fc681e6caa0',
            'team2_guid' => '768c92aa-75ff-4a43-bcc0-f2798c2e1724',
            // 'team3_guid' => '583eca2f-fb46-11e1-82cb-f4ce4684ea4c',
            // 'team4_guid' => '2eff2a03-54d4-46ba-890e-2bc3925548f3',
            'is_published' => 1,
            'is_archived' => 0
        ]);
    }

    public function down()
    {
        Poll::destroy([1,2]);
    }
}
