<?php namespace SCS\Polls\Updates;

use Schema;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;

class CreateFKsTeams extends Migration
{
    public function up()
    {
        Schema::table(
            'scs_polls_polls',
            function (Blueprint $table) {
                $table->foreign('team1_guid')->references('guid')->on('scs_osdb_team');
                $table->foreign('team2_guid')->references('guid')->on('scs_osdb_team');
                $table->foreign('team3_guid')->references('guid')->on('scs_osdb_team');
                $table->foreign('team4_guid')->references('guid')->on('scs_osdb_team');
            }
        );
    }

    public function down()
    {
        Schema::table(
            'scs_polls_polls',
            function (Blueprint $table) {
                $table->dropForeign('scs_polls_polls_team1_guid_foreign');
                $table->dropForeign('scs_polls_polls_team2_guid_foreign');
                $table->dropForeign('scs_polls_polls_team3_guid_foreign');
                $table->dropForeign('scs_polls_polls_team4_guid_foreign');
            }
        );
    }
}
