<?php namespace SCS\Polls\Updates;

use Schema;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;

class CreateResultsTable extends Migration
{
    public function up()
    {
        Schema::create('scs_polls_results', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->timestamps();
            $table->integer('poll_id');
            $table->integer('total_votes');
        });
    }

    public function down()
    {
        Schema::dropIfExists('scs_polls_results');
    }
}
