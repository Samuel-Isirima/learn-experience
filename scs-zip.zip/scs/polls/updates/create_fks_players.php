<?php namespace SCS\Polls\Updates;

use Schema;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;

class CreateFKsPlayers extends Migration
{
    public function up()
    {
        Schema::table(
            'scs_polls_polls',
            function (Blueprint $table) {
                $table->foreign('player1_guid')->references('guid')->on('scs_osdb_player');
                $table->foreign('player2_guid')->references('guid')->on('scs_osdb_player');
                $table->foreign('player3_guid')->references('guid')->on('scs_osdb_player');
                $table->foreign('player4_guid')->references('guid')->on('scs_osdb_player');
            }
        );
    }

    public function down()
    {
        Schema::table(
            'scs_polls_polls',
            function (Blueprint $table) {
                $table->dropForeign('scs_polls_polls_player1_guid_foreign');
                $table->dropForeign('scs_polls_polls_player2_guid_foreign');
                $table->dropForeign('scs_polls_polls_player3_guid_foreign');
                $table->dropForeign('scs_polls_polls_player4_guid_foreign');
            }
        );
    }
}
