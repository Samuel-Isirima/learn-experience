<?php namespace SCS\Polls\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableUpdateScsPollsPolls extends Migration
{
    public function up()
    {
        Schema::table('scs_polls_polls', function($table)
        {
            $table->string('poll_page', 64)->nullable();
        });
    }
    
    public function down()
    {
        Schema::table('scs_polls_polls', function($table)
        {
            $table->dropColumn('poll_page');
        });
    }
}
