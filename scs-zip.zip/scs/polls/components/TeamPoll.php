<?php namespace SCS\Polls\Components;

use Cms\Classes\ComponentBase;
use SCS\Polls\Models\Poll;
use SCS\Polls\Classes\Polls;
use SCS\OSDB\Models\Team;

class TeamPoll extends PollsAbstract
{
    public function componentDetails()
    {
        return [
            'name'        => 'Team Poll',
            'description' => 'Poll between Teams'
        ];
    }

    public function onPollSubmit(): array
    {
        return self::onPollSubmitStatic();
    }

    public static function onPollSubmitStatic($poll = null) : array
    {
        if ($poll === null) {
            \Log::error('~~ Poll: missing poll.');
            return [];
        }

        $check1 = isset($_POST['check-1']) ? $_POST['check-1'] : null;
        $check2 = isset($_POST['check-2']) ? $_POST['check-2'] : null;
        $check3 = isset($_POST['check-3']) ? $_POST['check-3'] : null;
        $check4 = isset($_POST['check-4']) ? $_POST['check-4'] : null;
        $guid1 = isset($_POST['guid-1']) ? $_POST['guid-1'] : null;
        $guid2 = isset($_POST['guid-2']) ? $_POST['guid-2'] : null;
        $guid3 = isset($_POST['guid-3']) ? $_POST['guid-3'] : null;
        $guid4 = isset($_POST['guid-4']) ? $_POST['guid-4'] : null;

        $team = null;
        if ($check1 == "on") {
            // vote for #1
            $team = Team::where('guid', $guid1)->first();
            if (!empty($team)) {
                $poll->increment('team1_votes');
            } else {
                \Log::error('~~ Poll: invalid guid lookup: ' . $guid1);
            }
        } elseif ($check2 == "on") {
            // vote for #2
            $team = Team::where('guid', $guid2)->first();
            if (!empty($team)) {
                $poll->increment('team2_votes');
            } else {
                \Log::error('~~ Poll: invalid guid lookup: ' . $guid2);
            }
        } elseif ($check3 == "on") {
            // vote for #3
            $team = Team::where('guid', $guid3)->first();
            if (!empty($team)) {
                $poll->increment('team3_votes');
            } else {
                \Log::error('~~ Poll: invalid guid lookup: ' . $guid3);
            }
        } elseif ($check4 == "on") {
            // vote for #4
            $team = Team::where('guid', $guid4)->first();
            if (!empty($team)) {
                $poll->increment('team4_votes');
            } else {
                \Log::error('~~ Poll: invalid guid lookup: ' . $guid4);
            }
        } else {
            // error
            \Log::error('~~ Poll: invalid vote.');
        }

        return [$team];
    }

    public static function getMembers($poll) : array
    {
        if ($poll === null) {
            \Log::error('~~ TeamPoll->getMembers - no poll exists');
            // exit
            return [];
        }
        if ($poll->poll_type !== "team") {
            \Log::error('~~ TeamPoll->getMembers - incorrect poll type');
            // exit
            return [];
        } else {
            $members = [];
            $memberGuids = [];
            $logos = [];
            if ($poll->poll_options === 2) {
                \array_push($memberGuids, $poll->team1_guid);
                \array_push($memberGuids, $poll->team2_guid);

                foreach ($memberGuids as $i => $guid) {
                    $team = Team::where('guid', $guid)->first();
                    $team->extendWithESData();
                    $jsonObj = json_decode($team->_teaminfo);
                    $logos[$i] = 'https://osdb-assets.s3.us-west-2.amazonaws.com/images/league/' . strtolower($jsonObj->logopath) . '/logo-light.svg';
                    $members[$i] = $team;
                }
            } elseif ($poll->poll_options === 4) {
                \array_push($memberGuids, $poll->team1_guid);
                \array_push($memberGuids, $poll->team2_guid);
                \array_push($memberGuids, $poll->team3_guid);
                \array_push($memberGuids, $poll->team4_guid);

                foreach ($memberGuids as $i => $guid) {
                    $team = Team::where('guid', $guid)->first();
                    $team->extendWithESData();
                    $jsonObj = json_decode($team->_teaminfo);
                    $logos[$i] = 'https://osdb-assets.s3.us-west-2.amazonaws.com/images/league/' . strtolower($jsonObj->logopath) . '/logo-light.svg';
                    $members[$i] = $team;
                }
            }
        }
        return ['members'=>$members, 'logos'=> $logos];
    }

    public static function normalizeResultVotes($poll) : array
    {
        if ($poll === null) {
            \Log::error('~~ TeamPoll->normalizeResultVotes - no poll exists');
            // exit
            return [];
        }

        $sum = $poll->team1_votes + $poll->team2_votes + $poll->team3_votes + $poll->team4_votes;
        if ($sum == 0) {
            $sum = 4;
        }
        return self::checkTotalPercentage([
            '0' => \round(($poll->team1_votes / $sum)*100, 0),
            '1' => \round(($poll->team2_votes / $sum)*100, 0),
            '2' => \round(($poll->team3_votes / $sum)*100, 0),
            '3' => \round(($poll->team4_votes / $sum)*100, 0),
        ]);
    }
}
