<?php namespace SCS\Polls\Components;

use Cms\Classes\ComponentBase;
use SCS\Polls\Components\PlayerPoll;
use SCS\Polls\Components\TeamPoll;
use SCS\Polls\Components\PollsAbstract;
use SCS\Polls\Models\Poll as PollModel;


class Poll extends PollsAbstract
{
    public function componentDetails()
    {
        return [
            'name'        => 'Poll Controller',
            'description' => 'Main poll controller - handles all polls'
        ];
    }

    public function onPollSubmit(): array
    {
        $data = self::onPollSubmitStatic();
        foreach ($data as $k => $v) {
            $this->page[$k] = $v;
        }
        return $data;
    }

    public static function onPollSubmitStatic() : array
    {
        $pollName = isset($_POST['pollName']) ? $_POST['pollName'] : null;
        $poll = [];
        if (null === $pollName) {
            \Log::error('~~ Poll: missing poll name for lookup.');
        } else {
            $poll = PollsAbstract::getPoll($pollName);
        }

        if ($poll->poll_type === "player") {
            $votedFor = PlayerPoll::onPollSubmitStatic($poll);
        } elseif ($poll->poll_type === "team") {
            $votedFor = TeamPoll::onPollSubmitStatic($poll);
        } else {
            \Log::error('~~ Poll->onPollSubmit - cannot determine poll type');
            // exit
            return [];
        }
        $resultObject = [];
        $resultObject['pollName'] = $poll->name;
        $resultObject['poll'] = $poll;

        if ($poll->poll_type === "player") {
            $getMembers = PlayerPoll::getMembers($poll);
        } elseif ($poll->poll_type === "team") {
            $getMembers = TeamPoll::getMembers($poll);
        } else {
            \Log::error('~~ Poll->onPollSubmit - cannot determine poll type');
            // exit
            return [];
        }
        $resultObject['pollMembers'] = $getMembers['members'];
        $resultObject['pollLogos'] = $getMembers['logos'];
        $resultObject['results'] = Poll::normalizeResultVotes($poll);

        return $resultObject;
    }

    public static function getMembers($poll) : array
    {
        $pollObj = [];
        if ($poll === null) {
            \Log::error('~~ Poll->getMembers - no poll exists');
            // exit
            return [];
        }
        if ($poll->poll_type === "player") {
            $pollObj = PlayerPoll::getMembers($poll);
        } elseif ($poll->poll_type === "team") {
            $pollObj = TeamPoll::getMembers($poll);
        } else {
            \Log::error('~~ Poll->getMembers - cannot determine poll type');
            // exit
            return [];
        }

        return $pollObj;
    }

    public static function normalizeResultVotes($poll) : array
    {
        if ($poll === null) {
            \Log::error('~~ Poll->normalizeResultVotes - no poll exists');
            // exit
            return [];
        }
        if ($poll->poll_type === "player") {
            return PlayerPoll::normalizeResultVotes($poll);
        } elseif ($poll->poll_type === "team") {
            return TeamPoll::normalizeResultVotes($poll);
        } else {
            \Log::error('~~ Poll->normalizeResultVotes - cannot determine poll type');
            // exit
            return [];
        }
    }
}
