<?php namespace SCS\Polls\Components;

use Cms\Classes\ComponentBase;
use SCS\Polls\Models\Poll;
use SCS\Polls\Classes\Polls;
use SCS\OSDB\Models\Player;

class PlayerPoll extends PollsAbstract
{
    public function componentDetails()
    {
        return [
            'name'        => 'Player Poll',
            'description' => 'Poll between players'
        ];
    }

    public function onPollSubmit(): array
    {
        return self::onPollSubmitStatic();
    }

    public static function onPollSubmitStatic($poll = null) : array
    {
        if ($poll === null) {
            \Log::error('~~ Poll: missing poll.');
            return [];
        }

        $check1 = isset($_POST['check-1']) ? $_POST['check-1'] : null;
        $check2 = isset($_POST['check-2']) ? $_POST['check-2'] : null;
        $check3 = isset($_POST['check-3']) ? $_POST['check-3'] : null;
        $check4 = isset($_POST['check-4']) ? $_POST['check-4'] : null;
        $guid1 = isset($_POST['guid-1']) ? $_POST['guid-1'] : null;
        $guid2 = isset($_POST['guid-2']) ? $_POST['guid-2'] : null;
        $guid3 = isset($_POST['guid-3']) ? $_POST['guid-3'] : null;
        $guid4 = isset($_POST['guid-4']) ? $_POST['guid-4'] : null;

        $player = null;
        if ($check1 == "on") {
            // vote for #1
            $player = Player::where('guid', $guid1)->first();
            if (!empty($player)) {
                $poll->increment('player1_votes');
            } else {
                \Log::error('~~ Poll: invalid guid lookup: ' . $guid1);
            }
        } elseif ($check2 == "on") {
            // vote for #2
            $player = Player::where('guid', $guid2)->first();
            if (!empty($player)) {
                $poll->increment('player2_votes');
            } else {
                \Log::error('~~ Poll: invalid guid lookup: ' . $guid2);
            }
        } elseif ($check3 == "on") {
            // vote for #3
            $player = Player::where('guid', $guid3)->first();
            if (!empty($player)) {
                $poll->increment('player3_votes');
            } else {
                \Log::error('~~ Poll: invalid guid lookup: ' . $guid3);
            }
        } elseif ($check4 == "on") {
            // vote for #4
            $player = Player::where('guid', $guid4)->first();
            if (!empty($player)) {
                $poll->increment('player4_votes');
            } else {
                \Log::error('~~ Poll: invalid guid lookup: ' . $guid4);
            }
        } else {
            // error
            \Log::error('~~ Poll: invalid vote.');
        }

        return [$player];
    }

    public static function getMembers($poll) : array
    {
        if ($poll === null) {
            \Log::error('~~ PlayerPoll->getMembers - no poll exists');
            // exit
            return [];
        }
        if ($poll->poll_type !== "player") {
            \Log::error('~~ PlayerPoll->getMembers - incorrect poll type');
            // exit
            return [];
        } else {
            $members = [];
            $memberGuids = [];
            if ($poll->poll_options === 2) {
                \array_push($memberGuids, $poll->player1_guid);
                \array_push($memberGuids, $poll->player2_guid);

                foreach ($memberGuids as $i => $guid) {
                    $player = Player::where('guid', $guid)->first();
                    $player->extendWithESData();
                    $members[$i] = $player;
                }
            } elseif ($poll->poll_options === 4) {
                \array_push($memberGuids, $poll->player1_guid);
                \array_push($memberGuids, $poll->player2_guid);
                \array_push($memberGuids, $poll->player3_guid);
                \array_push($memberGuids, $poll->player4_guid);

                foreach ($memberGuids as $i => $guid) {
                    $player = Player::where('guid', $guid)->first();
                    $player->extendWithESData();
                    $members[$i] = $player;
                }
            }
        }
        return ['members'=>$members, 'logos'=> null];
    }

    public static function normalizeResultVotes($poll) : array
    {
        if ($poll === null) {
            \Log::error('~~ PlayerPoll->normalizeResultVotes - no poll exists');
            // exit
            return [];
        }

        $sum = $poll->player1_votes + $poll->player2_votes + $poll->player3_votes + $poll->player4_votes;
        if ($sum == 0) {
            $sum = 4;
        }
        return self::checkTotalPercentage([
            '0' => \round(($poll->player1_votes / $sum)*100, 0),
            '1' => \round(($poll->player2_votes / $sum)*100, 0),
            '2' => \round(($poll->player3_votes / $sum)*100, 0),
            '3' => \round(($poll->player4_votes / $sum)*100, 0),
        ]);
    }
}
