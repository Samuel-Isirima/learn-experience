<?php namespace SCS\Polls\Components;

use Cms\Classes\ComponentBase;
use SCS\Polls\Models\Poll;

abstract class PollsAbstract extends ComponentBase
{
    public function componentDetails()
    {
        return [
        ];
    }

    public function defineProperties()
    {
        return [
            'pollName' => [
                'title' => 'Poll name (slug)',
                'description' => 'Name of poll to display',
                'type' => 'string'
            ],
            'pollOptions' => [
                'title' => 'Number of Poll options (slug)',
                'description' => 'Name of poll to display',
                'type' => 'dropdown',
                'placeholder' => '2 or 4',
                'options' => ['2'=>"2", '4'=>"4"]
            ],
            'pollStyle' => [
                'title' => '"light" or "dark',
                'description' => 'light or dark style',
                'type' => 'string',
            ]
        ];
    }

    const POLL_PLAYER = "playerPoll";
    const POLL_TEAM = "teamPoll";
    const CTX_HOME = "homepage";
    const CTX_MLB = "mlb";
    const CTX_NBA = "nba";
    const CTX_NFL = "nfl";
    const CTX_MLS = "mls";
    const CTX_NHL = "nhl";
    const URL_HOMEPAGE = "/";
    const URL_MLB = "mlb";
    const URL_NBA = "nba";
    const URL_NFL = "nfl";
    const URL_MLS = "mls";
    const URL_NHL = "nhl";
    // TODO: how to avoid magic strings here?

    public $pollStyle;
    public $pollType;
    public $pollName;
    public $poll;
    public $pollMembers;
    public $pollLogos;
    public $results;

    public function onRun()
    {
        $this->pollStyle = $this->page['pollStyle'] = $this->property('pollStyle');

        $router = $this->controller->getRouter();
        $ctx = $router->getUrl();
        $_poll = $this->fetchPollForContext($ctx);
        if ($_poll) {
            $this->poll = $this->page['poll'] = $_poll;
            $this->pollName = $this->page['pollName'] = $_poll->name;
            $this->pollType = $this->page['pollType'] = $_poll->poll_type;

            if ($this->poll->poll_type === "player") {
                $getMembers = PlayerPoll::getMembers($this->poll);
            } elseif ($this->poll->poll_type === "team") {
                $getMembers = TeamPoll::getMembers($this->poll);
            } else {
                \Log::error('~~ PollsAbstract->onRun - cannot determine poll type');
                // exit
                return [];
            }
            $this->pollMembers = $this->page['pollMembers'] = $getMembers['members'];
            $this->pollLogos = $this->page['pollLogos'] = $getMembers['logos'];
            $this->results = $this->page['results'] = $this->normalizeResultVotes($this->poll);
        }
        return [];
    }

    private function fetchPollForContext($url) {
        // get poll based on page context
        $poll = [];
        switch ($url) {
            case $this::URL_MLB :
                $poll = Poll::where('poll_page', $this::CTX_MLB)->where('is_published',1)->orderBy('publish_date','desc')->first();
                break;
            case $this::URL_NBA :
                $poll = Poll::where('poll_page', $this::CTX_NBA)->where('is_published',1)->orderBy('publish_date','desc')->first();
                break;
            case $this::URL_NFL :
                $poll = Poll::where('poll_page', $this::CTX_NFL)->where('is_published',1)->orderBy('publish_date','desc')->first();
                break;
            case $this::URL_MLS :
                $poll = Poll::where('poll_page', $this::CTX_MLS)->where('is_published',1)->orderBy('publish_date','desc')->first();
                break;
            case $this::URL_NHL :
                $poll = Poll::where('poll_page', $this::CTX_NHL)->where('is_published',1)->orderBy('publish_date','desc')->first();
                break;
            case $this::URL_HOMEPAGE :
            default:
                $poll = Poll::where('poll_page', $this::CTX_HOME)->where('is_published',1)->orderBy('publish_date','desc')->first();
                break;
        }
        return $poll;
    }

    public function onRender()
    {
        $this->addJs('assets/js/SCS.Polls.js');
    }

    public static function getPoll($pollName)
    {
        $poll = Poll::where('name', '=', $pollName)->orderBy('publish_date', 'desc')->first();

        if ($poll === null) {
            // exit
            return [];
        }

        return $poll;
    }

    public static function checkTotalPercentage($percentages): array {
        $totalPercentage = 0;
        $maxPercentageKey = null;
        foreach ($percentages as $key => $percentage) {
            $totalPercentage += $percentage;
            if (!isset($maxPercentageKey) || $percentage > $percentages[$maxPercentageKey]) {
                $maxPercentageKey = $key;
            }
        }
        if ($totalPercentage !== 100) {
            $percentages[$maxPercentageKey] += 100 - $totalPercentage;
        }
        return $percentages;
    }

    abstract public function onPollSubmit() : array;

    abstract public static function onPollSubmitStatic() : array;

    abstract public static function getMembers(Poll $poll) : array;

    abstract public static function normalizeResultVotes(Poll $poll) : array;

}
