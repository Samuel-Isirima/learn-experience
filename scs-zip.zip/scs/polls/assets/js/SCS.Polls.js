window.SCS = window.SCS || {}

SCS.Polls = {
  onSelect: function (elmId) {
    let $_elm = $('#' + elmId);
    let $_form = $('#form_' + $_elm.data('form-type'));
    let _pathVal = $('#' + elmId).val();
    // console.debug('~~ DEBUG SCS.Polls.onSelect')
    // console.debug('    val = ' + _pathVal)
    $_form.submit();

    $('.poll .poll--results-block .poll-spinner').addClass('d-block').removeClass('d-none');
    $('.poll .poll--results-block .result-view').addClass('d-none');
    $('.poll .poll--voting-block').addClass('disabled');

    return false;
  },

  onRequestComplete: function () {
    // console.debug('~~ complete');
    $('.poll .poll--results-block').addClass('d-block').removeClass('d-none');
    $('.poll .poll--results-block .poll-spinner').addClass('d-none').removeClass('d-block');
    $('.poll .poll--results-block .result-view').removeClass('d-none');
    $('.poll .poll--voting-block').addClass('d-none');
  },

  init: () => {
    // console.debug('~~ init');
    $('.poll .checkbox-wrapper input').on('change',(e)=>{
      SCS.Polls.onSelect(e.currentTarget.id);
    });
  },

  constructor() {
    return {
      init: init,
      onSelect: onSelect,
      onRequestComplete: onRequestComplete,
    }
  },
}

document.addEventListener('DOMContentLoaded', () => {
  // console.debug('~~ ready')

  SCS.Polls.init()
})
