# feature: polls

from Confluence - OLD?
>>> Polls / Quizzes Management
>>> 	Grid management with full timeline control
>>> 	Quizzes will appear in a data grid with key data, enabling full timelines control on when quizzes will be begin and end.
>>> 	Including bulk CSV import

## questions
- [ ] will there be a submit button or are they instant?
- [ ]

# poll structure

## DB entity

- id
- descriptions
- dates
- publish_date
- is_published
- is_archived
- name
- type
	- player - 2
	- player - 4
	- team - 2
	- team - 4
- question
- description
- entity1_guid req
- entity2_guid req
- entity3_guid nullable
- entity4_guid nullable
- entity1_votes def0
- entity2_votes def0
- entity3_votes nullable
- entity4_votes nullable

hasMany:
	players
	teams

## controller

onSubmit
increment entity votes
fetch poll by id
normalize results



        span: auto
        # cssClass: col-md-3
