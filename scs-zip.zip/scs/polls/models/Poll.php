<?php namespace SCS\Polls\Models;

use Model;
use SCS\Osdb\Models\League;

/**
 * Poll Model
 */
class Poll extends Model
{
    use \October\Rain\Database\Traits\Validation;

    /**
     * @var string The database table used by the model.
     */
    public $table = 'scs_polls_polls';

    /**
     * @var array Guarded fields
     */
    protected $guarded = ['*'];

    /**
     * @var array Fillable fields
     */
    protected $fillable = [];

    /**
     * @var array Validation rules for attributes
     */
    public $rules = [
        'name' => 'unique:scs_polls_polls'
    ];

    /**
     * @var array Attributes to be cast to native types
     */
    protected $casts = [];

    /**
     * @var array Attributes to be cast to JSON
     */
    protected $jsonable = [];

    /**
     * @var array Attributes to be appended to the API representation of the model (ex. toArray())
     */
    protected $appends = [];

    /**
     * @var array Attributes to be removed from the API representation of the model (ex. toArray())
     */
    protected $hidden = [];

    /**
     * @var array Attributes to be cast to Argon (Carbon) instances
     */
    protected $dates = [
        'created_at',
        'updated_at'
    ];

    /**
     * @var array Relations
     */
    public $hasOne = [
    ];
    public $hasMany = [
    ];
    public $hasOneThrough = [];
    public $hasManyThrough = [];
    public $belongsTo = [
        'team1' => ['SCS\Osdb\Models\Team', 'key' => 'team1_guid'],
        'team2' => ['SCS\Osdb\Models\Team', 'key' => 'team2_guid'],
        'team3' => ['SCS\Osdb\Models\Team', 'key' => 'team3_guid'],
        'team4' => ['SCS\Osdb\Models\Team', 'key' => 'team4_guid'],
        'player1' => ['SCS\Osdb\Models\Player', 'key' => 'player1_guid'],
        'player2' => ['SCS\Osdb\Models\Player', 'key' => 'player2_guid'],
        'player3' => ['SCS\Osdb\Models\Player', 'key' => 'player3_guid'],
        'player4' => ['SCS\Osdb\Models\Player', 'key' => 'player4_guid'],

        'result' => ['SCS\Polls\Models\Result'],
    ];
    public $belongsToMany = [];
    public $morphTo = [];
    public $morphOne = [


    ];
    public $morphMany = [];
    public $attachOne = [

    ];
    public $attachMany = [];

    public function getPageOptions()
    {
        $leagues = League::all();
        $result = [];
        $result['homepage'] = 'Home page';
        foreach ($leagues as $league){
            $result[$league->slug] = $league->name . ' League Page';
        }
        return $result;
    }
}
