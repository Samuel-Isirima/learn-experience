<?php

namespace SCS\ImageResizer;

use System\Classes\PluginBase;
class Plugin extends PluginBase
{

    public function pluginDetails()
    {
        return [
            'name'        => 'DynamicImageResizer',
            'description' => 'Download and resizes images as local cached versions',
            'author'      => 'SCS',
            'icon'        => 'icon-cube'
        ];
    }

    public function registerMarkupTags()
    {
        return [
            'filters' => [
                'dynamicresize' => function ($image, $width = null, $height = null, $mode = null, $format = null) {
                    if (!empty($image)) {
                        return \SCS\Osdb\Controllers\Resizer::resize($image, $width, $height, $mode, $format);
                    }
                }
            ]
        ];
    }


    public function boot()
    {
    }

    public function register()
    {
    }

}
