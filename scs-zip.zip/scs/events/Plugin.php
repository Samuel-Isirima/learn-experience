<?php namespace SCS\Events;

use Backend;
use System\Classes\PluginBase;

class Plugin extends PluginBase
{

    public function pluginDetails()
    {
        return [
            'name'        => 'Events',
            'description' => 'Events Carousel',
            'author'      => 'SCS',
            'icon'        => 'icon-cube'
        ];
    }

    public function register() {}

    public function boot() {}

    public function registerComponents()
    {
        return [
            'SCS\Events\Components\EventsCarousel' => 'eventsCarousel',
        ];
    }

    public function registerPermissions()
    {
        return [];
    }

    public function registerNavigation()
    {
        return [];
    }
}
