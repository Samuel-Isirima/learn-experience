<?php namespace SCS\Events\Components;

use Cms\Classes\ComponentBase;

class EventsCarousel extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'EventsCarousel Component',
            'description' => 'Events Carousel'
        ];
    }

    public function defineProperties()
    {
        return [
            'setImagePrimary' => [ 'title' => 'setImagePrimary', 'type' => 'string' ],
            'setImageSecondary' => [ 'title' => 'setImageSecondary', 'type' => 'string' ],
            'setTopheading' => [ 'title' => 'setTopheading', 'type' => 'string' ],
            'setSubHeadingPrimary' => [ 'title' => 'setSubHeadingPrimary', 'type' => 'string' ],
            'setSubHeadingSecondary' => [ 'title' => 'setSubHeadingSecondary', 'type' => 'string' ],
            'setDescription' => [ 'title' => 'setDescription', 'type' => 'string' ]
        ];
    }

    public $imagePrimary;
    public $imageSecondary;
    public $topheading;
    public $subHeadingPrimary;
    public $subHeadingSecondary;
    public $description;

    public function init()
    {

        $this->imagePrimary = $this->page['imagePrimary'] = $this->property('setImagePrimary');
        $this->imageSecondary = $this->page['imageSecondary'] = $this->property('setImageSecondary');
        $this->topheading = $this->page['topheading'] = $this->property('setTopheading');
        $this->subHeadingPrimary = $this->page['subHeadingPrimary'] = $this->property('setSubHeadingPrimary');
        $this->subHeadingSecondary = $this->page['subHeadingSecondary'] = $this->property('setSubHeadingSecondary');
        $this->description = $this->page['description'] = $this->property('setDescription');

    }

    public function onRun()
    {

    }
}
