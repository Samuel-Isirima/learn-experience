<?php return [
    'plugin' => [
        'name' => 'OSDB',
        'description' => 'Plugin for Sport, League, Player, Team and general site updates',
    ],
    'scs_osdb_alias_comment' => 'Auto generated Slug used by CMS',
    'osdb_team_asset_tab_name' => 'Logo & Venue',
];
