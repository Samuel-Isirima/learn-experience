<?php namespace SCS\Osdb\FormWidgets;

use Request;
use Backend\Classes\FormWidgetBase;
use Flash;
use SCS\Osdb\Models\Team;

class ContractTeam extends FormWidgetBase
{

    /**
     * {@inheritDoc}
     */
    public function init()
    {
        $tmp = 1;
    }

    /**
     * {@inheritDoc}
     */
    public function render()
    {
        $this->prepareVars();
        return $this->makePartial('form');
    }

    public function onClick() {

        $result_team_logo = null;
        $result_team_slug = null;

        $mediaLib = \System\Classes\MediaLibrary::instance();
        $leagueAlias = strtolower($this->model->_league);


        $team = $_REQUEST['team'];
        $error = null;
        if ($team) {
            $slug = str_slug($team);
            $dbTeam = Team::where('slug', '=', $slug)->first();
            if (isset($dbTeam)) {
                $logoUrl = '/logos/' . $leagueAlias . '/' . $slug . '/logo-dark.svg';
                if ($mediaLib->exists($logoUrl)) {
                    $result_team_logo = $logoUrl;
                } else {
                    $error = 'NO team logo in MediaLibrary for team slug ' . $slug;
                }
                $result_team_slug = $leagueAlias . '/' . $slug;
            } else {
                $error = 'NO team in DB with slug ' . $slug;
                // old team logo
                $logoUrl = '/old-logos/' . $leagueAlias . '/logo-' . $slug . '-dark.svg';
                if ($mediaLib->exists($logoUrl)) {
                    $result_team_logo = $logoUrl;
                }
            }
        } else {
            $error = "Team Name is empty!";
        }

        if ($error)
            Flash::error('Can\'t setup Team Logo and Team Slug. ' . $error);
        return array($result_team_logo, $result_team_slug);
    }

    public function loadAssets()
    {
        $this->addCss('css/contractteam.css', 'scs.osdb');
        $this->addJs('js/contractteam.js', 'scs.osdb');
    }

    /**
     * Prepares the list data
     */
    public function prepareVars()
    {
    }
}
