function onSuccess($el, context, data, textStatus, jqXHR) {
    team_logo = data[0];
    team_slug = data[1];

    $form = $el.closest('.field-repeater-form');
    if (team_slug) {
        $form.find('div[data-field-name="team_slug"] input')[0].value = team_slug;
    }
    if (team_logo) {
        $form.find('div[data-field-name="team_logo"] div.info h4.filename span').text(team_logo);
        $form.find('div[data-field-name="team_logo"] input')[0].value = team_logo;
        $form.find('div[data-field-name="team_logo"] div.field-mediafinder').addClass('is-populated');
    }
    $form.find('div.contract-team button').removeAttr("disabled");
    $form.find('.contract-team-loader').removeClass('loading');
}

function onStart(el) {
    $el = $(el);
    $form = $el.closest('.field-repeater-form');

    $el.attr("disabled", "disabled");
    $form.find('.contract-team-loader').addClass('loading');

    $el.request('onClick', {
        data: {
            index: $('.contract-team-button').index(el),
            team: $form.find('div[data-field-name="team"] input')[0].value
        }
    });
}