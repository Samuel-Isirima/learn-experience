<?php namespace SCS\Osdb\Models;

use Model;
use Flash;
use SCS\Osdb\Classes\ES\Players;
use SCS\Osdb\Classes\ES\Seasons;
use SCS\Osdb\Classes\ES\Leagues;
use Illuminate\Support\Facades\DB;
use SCS\Osdb\Classes\Services\MisoSearchService;
use SCS\Osdb\Models\Season as SeasonModel;

/**
 * Model
 */
class Season extends Model
{
    use \October\Rain\Database\Traits\Validation;

    public $implement = [
        'October.Rain.Database.Behaviors.Purgeable'
    ];

    public $purgeable = ['_year', '_type', '_status', '_start_date', '_end_date', '_leagueinfo', '_league', '_season_id', '_competition_id'];

    /**
     * @var string The database table used by the model.
     */
    public const TABLE = 'scs_osdb_seasons';
    public $table = self::TABLE;
    public $primaryKey = 'guid';
    public $incrementing = false;

    /**
     * @var array Validation rules
     */
    public $rules = [
    ];


    /** Relations **/
    public $belongsTo = [
        'league' => ['scs\osdb\models\League', 'key' => 'league_guid'],
    ];
    public $belongsToMany = [
    ];
    public $hasMany = [
    ];
    public $attachMany = [
    ];

    public function extendWithESData()
    {
        $adsData = Seasons::getById($this->guid);

        $this->_league = array_get($adsData, 'league.alias');
        $this->_year = array_get($adsData, 'year');
        $this->_type = array_get($adsData, 'type');
        $this->_status = array_get($adsData, 'status');
        $this->_start_date = array_get($adsData, 'start_date');
        $this->_end_date = array_get($adsData, 'end_date');
        $this->_season_id = array_get($adsData, 'season_id');
        $this->_competition_id = array_get($adsData, 'competition_id');

        $league = strtolower($this->_league);
        $this->_widget_season_id = $league == 'nfl' ? $this->_year : $this->_season_id;
        $this->_widget_competition_id = $league == 'nfl' ? '' : $this->_competition_id;

        $this->_leagueinfo = '{ "league": "'. strtolower(array_get($adsData, 'league.alias')) .'", "name":"' . array_get($adsData, 'league.name'). '"}';
    }

     public function afterFetch()
     {
         //$this->extendWithESData();
     }

    public function scopeIsCurrent($query, $value = 1)
    {
        return $query->where('is_current', $value);
    }

    public static function setCurrentSeason($leagueId, $seasonId)
    {
        Db::table(self::TABLE)
            ->where('league_guid', $leagueId)
            ->update(['is_current' => false]);
        if (!empty($seasonId)) {
            Db::table(self::TABLE)
                ->where('guid', $seasonId)
                ->update(['is_current' => true]);
        }
    }

    public static function getCurrentSeason($leagueGuid)
    {
        $season = SeasonModel
            ::where('league_guid', $leagueGuid)
            ->where('is_current', true)
            ->orderBy('updated_at', 'desc')
            ->orderBy('year', 'desc')
            ->first();
        return $season;
    }

    public static function getCurrentSeasonByLeagueSlug($leagueSlug)
    {
        $season = SeasonModel::whereHas('league', function ($query) use ($leagueSlug) {
            return $query->where('slug', $leagueSlug);})
            ->where('is_current', true)
            ->orderBy('updated_at', 'desc')
            ->orderBy('year', 'desc')
            ->first();
        return $season;
    }

    public function getLeagueFilter()
    {
        $leagues = Leagues::getLeagues();
        $result = [];
        foreach ($leagues as $league){
            $result[$league['id']] = $league['alias'];
        }
        return $result;
    }

    public function afterSave()
    {
        $dbSeason = Db::table(Season::TABLE)->where('guid', $this->guid)->first();
        if ($dbSeason != null) {
            // send update to Miso
            $dbLeague = Db::table(League::TABLE)
                ->where(League::TABLE.'.guid', '=', $dbSeason->league_guid)
                ->join(Sport::TABLE, League::TABLE.'.sport_guid', '=', Sport::TABLE.'.guid')
                ->select(League::TABLE.'.*', Sport::TABLE.'.name as sport_name', Sport::TABLE.'.slug as sport_slug')
                ->first();
            if ($dbLeague != null) {
                $misoItem = self::constructProductForMiso($dbLeague, $dbSeason);
                $errors = MisoSearchService::instance()->upload("products", [$misoItem]);
            }
        }
    }

    public static function loadESSeasons($flash = true)
    {
        try {
            $misoItems = [];

            $esList = Seasons::list();
            $dbLeagues = Db::table(League::TABLE)
                ->join(Sport::TABLE, League::TABLE.'.sport_guid', '=', Sport::TABLE.'.guid')
                ->select(League::TABLE.'.*', Sport::TABLE.'.name as sport_name', Sport::TABLE.'.slug as sport_slug')
                ->get()->all();

            $dbSeasons = DB::select("select * from scs_osdb_seasons");
            $dbIds = array_map(function ($item) {
                if ($item) {
                    return $item->guid;
                } else {
                    throw new SystemException('~~ ADS->onUpdateSeason - error on dbIds');
                }
            }, $dbSeasons);

            // \Log::info('~~ ADS->onUpdateSeasons - DB Seasons: '.count($dbIds), ['count#'=>count($dbIds)]);
            $esIds = array_map(function ($item) {
                return $item['id'];
            }, $esList);
            // \Log::info('~~ ADS->onUpdateSeasons - ES seasons: '.count($esIds), ['count#'=>count($esIds)]);

            $index = 0;
            foreach ($esIds as $esId) {
                $index++;
                if (!in_array($esId, $dbIds)) {
                    // insert new Season into DB
                    \Log::warning('~~ ADS->onUpdateSeasons - unmatched esId: '.$esId.' - creating season', ['unmatched esID'=>$esId]);
                    $key = array_search($esId, array_column($esList, 'id'));
                    $esSeason = $esList[$key];
                    $leagueId = $esSeason['league']['id'];
                    $dbLeague = current(array_filter(
                        $dbLeagues,
                        function ($item) use ($leagueId) {
                            return $item->guid == $leagueId;
                        }
                    ));
                    if ($dbLeague) {
                        // TODO: use DB directly to avoid afterSave call
                        SeasonModel::create([
                            'guid'=>$esId,
                            'year'=>$esSeason['year'],
                            'type'=>isset($esSeason['type']) ? $esSeason['type'] : "REG",
                            'status'=>isset($esSeason['status']) ? $esSeason['status'] : null,
                            'season_id'=>isset($esSeason['season_id']) ? $esSeason['season_id'] : null,
                            'competition_id'=>isset($esSeason['competition_id']) ? $esSeason['competition_id'] : null,
                            'start_date'=>isset($esSeason['start_date']) ? $esSeason['start_date']: null,
                            'end_date'=>isset($esSeason['end_date']) ? $esSeason['end_date']: null,
                            'league_guid' => $esSeason['league']['id']
                        ]);
                        $dbSeason = Db::table(Season::TABLE)->where('guid', $esId)->first();
                        $misoItems[] = self::constructProductForMiso($dbLeague, $dbSeason);
                    } else {
                        \Log::error('~~ ADS->onUpdateSeasons - cannot get league for: '.$esId);
                    }
                }  else { // update existing season
                    $key = array_search($esId, array_column($esList, 'id'));
                    $esSeason = $esList[$key];
                    $searchedValue = $esId;
                    $dbSeasonsFiltered = array_filter(
                        $dbSeasons,
                        function ($e) use (&$searchedValue) {
                            return $e->guid == $searchedValue;
                        }
                    );
                    $dbSeason = !empty($dbSeasonsFiltered) && count($dbSeasonsFiltered) > 0 ? array_values($dbSeasonsFiltered)[0] : null;
                    if (isset($dbSeason) && $dbSeason){
                        $update = [];
                        $fields = ['status', 'start_date', 'end_date', 'season_id', 'competition_id'];
                        foreach ($fields as $field) {
                            $dbValue = $dbSeason->$field;
                            $esValue = isset($esSeason[$field]) ? $esSeason[$field] : null;
                            if ($field == 'start_date' || $field == 'end_date') {
                                $dbValue = strtotime($dbValue);
                                $esValue = strtotime($esValue);
                            }
                            if (isset($esValue) && $dbValue != $esValue) {
                                $update[$field] = $esSeason[$field];
                            }
                        }
                        if (count($update) > 0) {
                            SeasonModel::where('guid', $esId)
                                ->update($update);
                            // add item to Miso
                            $dbSeason = Db::table(Season::TABLE)->where('guid', $esId)->first();
                            $leagueId = $dbSeason->league_guid;
                            $dbLeague = current(array_filter(
                                $dbLeagues,
                                function ($item) use ($leagueId) {
                                    return $item->guid == $leagueId;
                                }
                            ));
                            $misoItems[] = self::constructProductForMiso($dbLeague, $dbSeason);
                        }
                    }
                }
            }
            // TODO: process removed items

            // send update to Miso
            $errors = MisoSearchService::instance()->upload("products", $misoItems);

            if ($flash) Flash::success('Updated Seasons');
            // \Log::info('~~ ADS->onUpdateSeasons - success');
        }
        catch (\Exception $ex) {
            if ($flash) Flash::error('Error during Seasons import: ' . $ex->getMessage());
            \Log::error('~~ Error during import - Seasons:'. " [".$ex->getTraceAsString()."]");
        }
    }

    public static function constructProductForMiso($dbLeague, $dbSeason)
    {
        $createdAt = str_replace(' ', 'T', $dbSeason->created_at).'Z';
        $updatedAt = str_replace(' ', 'T', $dbSeason->updated_at).'Z';
        $title = $dbLeague->name . '-' . $dbSeason->year . '-' . $dbSeason->type;
        $result = [
            "type" => "seasons",
            "product_id" => $dbSeason->guid,
            "title" => $title,
            "description" => $title,
            "product_group_id" => $dbLeague->guid,
            "categories" => [[$dbLeague->sport_name, $dbLeague->name]],
            "tags" => [$dbLeague->sport_slug, $dbLeague->slug, strval($dbSeason->year), $dbSeason->type],
            "created_at" => $createdAt,
            "updated_at" => $updatedAt,
            "custom_attributes" => [
                "sport" => $dbLeague->sport_name,
                "league" => $dbLeague->name,
                "status" => $dbSeason->status
            ]
        ];
        return $result;
    }

    public static function uploadToMisoSearch($flash = true, $league = null)
    {
        try {
            $dbLeagues = Db::table(League::TABLE)
                ->join(Sport::TABLE, League::TABLE.'.sport_guid', '=', Sport::TABLE.'.guid')
                ->select(League::TABLE.'.*', Sport::TABLE.'.name as sport_name', Sport::TABLE.'.slug as sport_slug')
                ->get()->all();

            $dbSeasons = $league
                ? DB::select("select * from ". Season::TABLE .
                    " where league_guid = '" . $league . "'")
                : DB::select("select * from ". Season::TABLE);

            $items = [];
            foreach ($dbSeasons as $dbSeason) {
                $v = $dbSeason->league_guid;
                $dbLeague = $entry = current(array_filter($dbLeagues, function($e) use($v){ return $e->guid == $v; }));
                if ($dbLeague === false) {
                    \Log::warning('~~ Season->uploadToMisoSearch - League not found: '.$v);
                    continue;
                }
                $items[] = self::constructProductForMiso($dbLeague, $dbSeason);
            }
            $errors = MisoSearchService::instance()->upload("products", $items);

            if ($errors) {
                if ($flash) Flash::success('Seasons upload to Miso FAILED, please check logs');
                \Log::warning('~~ Season->uploadToMisoSearch - errors', ['errors' => $errors]);
            } else {
                if ($flash) Flash::success('Uploaded Seasons to Miso');
                // \Log::info('~~ Season->uploadToMisoSearch - success');
            }
        }
        catch (\Exception $ex) {
            if ($flash) Flash::error('Exception during Season upload to Miso: ' . $ex->getMessage());
            \Log::error('~~ Error: Season->uploadToMisoSearch - exception:'. " [".$ex->getTraceAsString()."]");
        }
    }
}
