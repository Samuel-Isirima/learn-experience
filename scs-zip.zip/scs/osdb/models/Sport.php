<?php namespace SCS\Osdb\Models;

use Model;

/**
 * Model
 */
class Sport extends Model
{
    use \October\Rain\Database\Traits\Validation;

    public const TABLE = 'scs_osdb_sport';

    /**
     * @var string The database table used by the model.
     */
    public $table = self::TABLE;
    public $primaryKey = 'guid';
    public $incrementing = false;
    public $jsonable = ['ticker_leagues'];

    /**
     * @var array Validation rules
     */
    public $rules = [
    ];

    public $hasMany = [
        'league' => 'scs\osdb\models\League'
    ];
}
