<?php namespace SCS\Osdb\Models;

use Cookie;
use Request;
use Model;
use Flash;
use Illuminate\Support\Facades\DB;
use October\Rain\Database\Traits\Validation;
use SCS\Osdb\Classes\ES\ESModel;
use SCS\Osdb\Classes\ES\Leagues;
use SCS\Osdb\Classes\ES\Players;
use SCS\Osdb\Classes\ES\Teams;
use SCS\Osdb\Classes\Services\ElasticsearchService;
use SCS\Osdb\Classes\Services\MisoSearchService;
use SCS\Osdb\Classes\Util\SlugUtil;
use SCS\Osdb\Controllers\Resizer;


/**
 * Model
 */
class Player extends Model
{
    use Validation;

    public $implement = [
        'October.Rain.Database.Behaviors.Purgeable'
    ];

    public $purgeable = ['_team_name', '_position', '_jersey_number', '_birthdate', '_birthplace',
        '_bio_college', '_bio_high_school', '_updated', '_status', '_reference',
        '_weight', '_height', '_teaminfo', '_headshot_high_res'];

    public const TABLE = 'scs_osdb_player';

    /**
     * @var string The database table used by the model.
     */
    public $table = 'scs_osdb_player';
    public $primaryKey = 'guid';
    public $incrementing = false;


    /**
     * @var array Validation rules
     */
    public $rules = [
    ];

    /** Relations **/
    //@@ Will change to attach many for biography images
//    public $attachOne = [
//        'logo' => 'System\Models\File',
//    ];

    public $belongsTo = [
        'team' => ['scs\osdb\models\Team', 'key' => 'team_guid']
    ];

    public $attachOne = [
        'image_fullbody' => 'System\Models\File',
        'charities_image' => 'System\Models\File',
    ];

    public $attachMany = [
        'biography_images' => 'System\Models\File',
        'team_logo' => 'System\Models\File'
    ];

    public $jsonable = ['social_links', 'endorsements', 'business', 'charities', 'contracts', 'grouppedContracts', 'contact', 'agent', 'bio', 'awards'];

    public function getLeagueFilter()
    {
        $leagues = Leagues::getLeagues();
        $result = [];
        foreach ($leagues as $league){
            $result[$league['id']] = $league['alias'];
        }
        return $result;
    }

    public function getLeagueNameAttribute()
    {
        if ($this->team_guid === null) {
            if ($this->team !== null) {
                $team = Team::where('name', 'like', "%".$this->team."%")->first();
                if ($team !== null) {
                    $league = League::where('guid', '=', $team->league_guid)->first();
                    if ($league !== null) {
                        return $league->name;
                    } else {
                        \Log::error('~~ Player->getLeagueNameAttribute - invalid league attribute: ' . $team->league_guid);
                        return null;
                    }
                } else {
                    \Log::error('~~ Player->getLeagueNameAttribute - invalid league attribute for team: ' . $this->team);
                    return null;
                }
            }
        } else {
            $team = Team::where('guid', '=', $this->team_guid)->first();
            if ($team !== null) {
                $league = League::where('guid', '=', $team->league_guid)->first();
                if ($league !== null) {
                    return $league->name;
                } else {
                    \Log::error('~~ Player->getLeagueNameAttribute - invalid league attribute for team guid: ' . $team->team_guid);
                    return null;
                }
            }
        }
    }

    public function getGrouppedContractsAttribute($value)
    {
        $contracts = json_decode($this->attributes['contracts']);
        if (!isset($contracts)) return null;
        usort($contracts, function($a, $b)
        {
            $aValue = intval($a->end_year);
            $bValue = intval($b->end_year);
            if ($aValue == $bValue) return 0;
            return $bValue - $aValue;
        });
        $result = [];
        foreach ($contracts as $contract) {
            $startYear = intval($contract->year_started);
            $endYear = intval($contract->end_year);
            $key = $startYear . '-' . $endYear;
            if (!array_key_exists($key, $result)) {
                $result[$key] = [];
            }
            $result[$key][] = $contract;
        }
        return json_encode($result);
    }

    public function extendWithESData()
    {
        $adsData = Players::getById($this->guid);

        $teamid = array_get($adsData, 'team.id');

        // if team guid is wrong update it here
        if ($this->team_guid != $teamid) {
            \Db::table('scs_osdb_player')
                ->where('guid', $this->guid)
                ->update(['team_guid' => $teamid]);
        }


        $contracts = json_decode($this->attributes['contracts']);
        if (!isset($contracts)) return null;
        usort($contracts, function($a, $b)
        {
            $aValue = intval($a->end_year);
            $bValue = intval($b->end_year);
            if ($aValue == $bValue) return 0;
            return $bValue - $aValue;
        });
        $contractsResult = [];
        foreach ($contracts as $contract) {
            $startYear = intval($contract->year_started);
            $endYear = intval($contract->end_year);
            $key = $startYear . '-' . $endYear;
            if (!array_key_exists($key, $contractsResult)) {
                $contractsResult[$key] = [];
            }
            $contractsResult[$key][] = $contract;
        }

        $cumulativeYears = [];
        foreach ($contractsResult as $randomKey => $teamData) {
            $startYear = intval($teamData[0]->year_started);
            $endYear =  intval($teamData[0]->end_year);
            $years = $endYear - $startYear;
        
            $teamName = $teamData[0]->team; // Replace spaces with underscores
        
            if (!isset($cumulativeYears[$teamName])) {
                $cumulativeYears[$teamName] = $years;
            } else {
                $cumulativeYears[$teamName] += $years;
            }
        }

        //reverse soft the cumulative years
        // arsort($cumulativeYears);

        //get the team names from the cumulative years
        $teamNames = array_keys($cumulativeYears);

        $this->_former_teams = $teamNames;
        $this->_cumulative_years = $cumulativeYears;
        $this->_team_name = array_get($adsData, 'team.name');
        $this->_team_id = array_get($adsData, 'team.team_id');
        $this->_team_slug = array_get($adsData, 'team.slug');
        $this->_position = array_get($adsData, 'position');
        $this->_status = array_get($adsData, 'status');
        $this->_updated = array_get($adsData, 'updated');
        $this->_reference = array_get($adsData, 'reference');
        $this->_jersey_number = array_get($adsData, 'jersey_number');
        $this->_birthdate = array_get($adsData, 'birthdate');
        $this->_birthplace = array_get($adsData, 'birth_place');
        $this->_weight = array_get($adsData, 'weight');
        $this->_height = array_get($adsData, 'height');
        $this->_teaminfo = '{ "logopath": "'. strtolower(array_get($adsData, 'league.alias')) . '/' . array_get($adsData, 'team.slug') .'", "name":"' . array_get($adsData, 'team.market') . ' ' . array_get($adsData, 'team.name'). '"}';
        $this->_bio_born = array_get($adsData, 'birthdate') . ' ' . array_get($adsData, 'birthplace');
        $this->_bio_position = array_get($adsData, 'position');
        $this->_bio_college = array_get($adsData, 'college');
        $this->_bio_high_school = array_get($adsData, 'high_school');
        $this->_bio_draft = array_get($adsData, 'draft.year');
        $this->_headshot_high_res = array_get($adsData, 'headshot.high_res');
        $this->_headshot_low_res = array_get($adsData, 'headshot.low_res');

        $league = strtolower(array_get($adsData, 'league.alias'));
        $playerId = array_get($adsData, 'player_id');
        $this->_widget_player_id = $league == 'nfl' ? 'sd:player:'.$this->guid : $playerId;
        $this->_league = $league;
        $this->_seasons = array_get($adsData, 'seasons');

//                $this->_conference = array_get($adsData, 'conference.name');
//                $this->_division = array_get($adsData, 'division.name');
//                $this->_venue_location = array_get($adsData, 'venue.city') . ', ' . array_get($adsData, 'venue.state') ;
//                $this->_venue_name = array_get($adsData, 'venue.name');
//                $this->_venue_capacity = array_get($adsData, 'venue.capacity');
//                $this->_foundedYear = "Need ADS Data";//array_get($adsData, 'founded');
    }

    public function scopeIsFeatured($query, $value = 1)
    {
        return $query->where('is_featured', $value);
    }

    public function scopeHasTeam($query)
    {
        return $query->whereNotNull('team_guid');
    }

    /*public static function tmp($team) {
        if (!empty($contract->team)) {
            $team = strtolower($contract->team);
            $slug = str_slug($team);
            $dbTeam = $entry = current(
                array_filter(
                    $dbTeams, function ($e) use ($slug) {
                    return $e->slug == $slug;
                }
                )
            );
            if ($dbTeam !== false) {
                // existing team
                if (empty($contract->team_logo)) {
                    $logoUrl = '/logos/' . $league->slug . '/' . $slug . '/logo-dark.svg';
                    if ($mediaLib->exists($logoUrl)) {
                        $contract->team_logo = $logoUrl;
                        $changed = true;
                    } else {
                        Flash::error('NO team logo in MediaLibrary for team ' . $team);
                        \Log::error('~~ Player->onProcessTeamLogos NO team logo in MediaLibrary for player='. $player->guid.', team='.$slug);
                    }
                }
                if (empty($contract->team_slug)) {
                    $contract->team_slug = $league->slug . '/' . $slug;
                    $changed = true;
                }
            } else {
                \Log::info('~~ Player->onProcessTeamLogos NO DB Team for player='. $player->guid.', team='.$slug);
                // old team logo
                $logoUrl = '/old-logos/' . $league->slug . '/logo-' . $slug . '-dark.svg';
                if (empty($contract->team_logo)) {
                    if ($mediaLib->exists($logoUrl)) {
                        $contract->team_logo = $logoUrl;
                        $changed = true;
                    }
                }
            }
        }
    }*/

    public function beforeSave()
    {
        if (empty($this->custom_headshot)) $this->custom_headshot = null;
        parent::beforeSave();
    }

    public function afterSave()
    {
        $esPlayer = Players::getById($this->guid);
        $dbPlayer = Db::table(Player::TABLE)->where('guid', $this->guid)->first();

        // remove headshots from cache
        Resizer::clearImages($this->guid, 'png');

        if ($dbPlayer != null && $esPlayer != null) {
            $dbLeague = Db::table(League::TABLE)
                ->where(League::TABLE.'.guid', '=', $esPlayer['league']['id'])
                ->join(Sport::TABLE, League::TABLE.'.sport_guid', '=', Sport::TABLE.'.guid')
                ->select(League::TABLE.'.*', Sport::TABLE.'.name as sport_name', Sport::TABLE.'.slug as sport_slug')
                ->first();
            if ($dbLeague) {
                // send update to Miso
                $misoItem = self::constructProductForMiso($dbLeague, $dbPlayer, $esPlayer);
                $errors = MisoSearchService::instance()->upload("products", [$misoItem]);
            }
        }
    }

    public static function loadESPlayers($flash, $league = null)
    {
        try {
            $misoItems = [];

            $esList = $league ? [] : Players::list() ;
            if ($league) {
                $body = [
                    'query' => []
                ];
                ESModel::addAndTerm($body, 'league.id', $league);
                $response = ElasticsearchService::instance()->search(Players::$index, $body);
                $esList = $response->items;
            }

            $dbPlayers = $league
                ? DB::select("select player.guid as guid, player.team_guid as team_guid, player.name as name from ". Player::TABLE . " player " .
                    " left join ".Team::TABLE." team on team.guid = player.team_guid ".
                    " where league_guid = '" . $league . "'")
                : DB::select("select guid, team_guid, name from ". Player::TABLE);

            $dbLeagues = Db::table(League::TABLE)
                ->join(Sport::TABLE, League::TABLE.'.sport_guid', '=', Sport::TABLE.'.guid')
                ->select(League::TABLE.'.*', Sport::TABLE.'.name as sport_name', Sport::TABLE.'.slug as sport_slug')
                ->get()->all();

            $dbIds = array_map(function ($item) {
                if ($item) {
                    return $item->guid;
                } else {
                    throw new SystemException('~~ ADS->onUpdatePlayer - error on dbIds');
                }
            }, $dbPlayers);
            // \Log::info('~~ ADS->onUpdatePlayer - DB players: '.count($dbIds), ['count#'=>count($dbIds)]);
            $esIds = array_map(function ($item) {
                if ($item) {
                    return $item['id'];
                } else {
                    throw new SystemException('~~ ADS->onUpdatePlayer - error on esIds');
                }
            }, $esList);
            // \Log::info('~~ ADS->onUpdatePlayer - ES players: '.count($esIds), ['count#'=>count($esIds)]);

            $teamDbIds = Db::select("select guid from ". Team::TABLE);
            $teamIds = array_map(function ($item) {
                if ($item) {
                    return $item->guid;
                } else {
                    throw new SystemException('~~ ADS->onUpdatePlayer - error on teamIds');
                }
            }, $teamDbIds);
            // \Log::info('~~ ADS->onUpdatePlayer - DB teams: '.count($teamIds), ['count#'=>count($teamIds)]);

            foreach ($esIds as $esId) {
                try {
                    $key = array_search($esId, array_column($esList, 'id'));
                    $esPlayer = $esList[$key];
                    if (!in_array($esId, $dbIds)) {
                        // insert new Player into DB
                        // \Log::warning('~~ ADS->onUpdatePlayer - unmatched esId: '.$esId.' - creating player', ['unmatched esID'=>$esId]);

                        // skip players without team and players which team is not in CMS
                        $teamId = isset($esPlayer['team']) ? $esPlayer['team']['id'] : null;
                        $playerName = isset($esPlayer['full_name']) ? $esPlayer['full_name'] : null;
                        if (empty($playerName)) \Log::error('~~ ADS->onUpdatePlayer - ES player without name found: '.$esId);
                        if (!empty($playerName) && (empty($teamId) || !empty($teamId) && (in_array($teamId, $teamIds))) ){
                            // use DB directly to avoid afterSave call
                            // METHOD FOR CREATING OR UPDATING
                            // if ($playerExists = Db::table('scs_osdb_player')->where('guid', $esId)->first()) {
                            //     Db::table('scs_osdb_player')->where('guid', $esId)->update([
                            //         'name' => $playerName,
                            //         'team_guid' => $teamId,
                            //         'slug' => $esId // using GUID for the slug now due to collision possibility.
                            //     ]);
                            // }
                            // else {
                            //     Db::table('scs_osdb_player')->insert([
                            //         'guid'=>$esId,
                            //         'name'=>$playerName,
                            //         'team_guid'=> $teamId,
                            //         'slug'=>$esId // using GUID for the slug now due to collision possibility.
                            //     ]);
                            // }
                            // METHOD FOR CREATING (closer to original method)
                            if (!$playerExists = Db::table('scs_osdb_player')->where('guid', $esId)->first()) {
                                Db::table('scs_osdb_player')->insert([
                                    'guid'=>$esId,
                                    'name'=>$playerName,
                                    'team_guid'=> $teamId,
                                    'slug'=>$esId // using GUID for the slug now due to collision possibility.
                                ]);
                            }
                            // add item to Miso list
                            $dbPlayer = Db::table(Player::TABLE)->where('guid', $esId)->first();
                            $v = $esPlayer['league']['id'];
                            $dbLeague = $entry = current(array_filter($dbLeagues, function($e) use($v){ return $e->guid == $v; }));
                            if ($dbLeague !== false) {
                                $misoItems[] = self::constructProductForMiso($dbLeague, $dbPlayer, $esPlayer);
                            }
                        } else {
                            \Log::error('~~ ADS->onUpdatePlayer - cannot get team for: '.$esId);
                        }
                    } else { // update existing player team_guid if needed
                        $key = array_search($esId, array_column($esList, 'id'));
                        $esPlayer = $esList[$key];
                        $searchedValue = $esId;
                        $dbPlayersFiltered = array_filter(
                            $dbPlayers,
                            function ($e) use (&$searchedValue) {
                                return $e->guid == $searchedValue;
                            }
                        );
                        $dbPlayer = !empty($dbPlayersFiltered) && count($dbPlayersFiltered) > 0 ? array_values($dbPlayersFiltered)[0] : null;
                        $teamId = isset($esPlayer['team']) ? $esPlayer['team']['id'] : null;
                        $playerName = isset($esPlayer['full_name']) ? $esPlayer['full_name'] : $dbPlayer->name;
                        if (isset($dbPlayer) && $dbPlayer && ($dbPlayer->team_guid != $teamId || $dbPlayer->name != $playerName)){
                            Player::where('guid', $esId)
                                ->update([
                                    'name'=>$playerName,
                                    'team_guid' => $teamId]);
                            // add item to Miso list
                            $dbPlayer = Db::table(Player::TABLE)->where('guid', $esId)->first();
                            $v = $esPlayer['league']['id'];
                            $dbLeague = $entry = current(array_filter($dbLeagues, function($e) use($v){ return $e->guid == $v; }));
                            if ($dbLeague !== false) {
                                $misoItems[] = self::constructProductForMiso($dbLeague, $dbPlayer, $esPlayer);
                            }
                        }
                    }

                    /*
                    this might be breaking something - remove for now
                    // process missing and invalid team guids - added since we need to reprocess some errors in team_guids
                    if (in_array($esId, $pwtIds)) {
                        $key = array_search($esId, array_column($esList, 'id'));
                        $esPlayer = $esList[$key];
                        // skip players without team and players which team is not in CMS
                        $teamId = isset($esPlayer['team']) ? $esPlayer['team']['id'] : null;
                        Player::upsert([
                            'guid'=>$esId,
                            'name'=>$esPlayer['full_name'],
                            'team_guid'=> $esPlayer['team']['id'],
                            'slug'=>$esId                           //using GUID for the slug now due to collision possibility.
                        ], ['guid', 'slug'], ['team_guid']);
                    }
                    */
                }
                catch (\Exception $ex) {
                    \Log::error('~~ Error during import - Player='.$esId.': '. $ex->getMessage() . " [".$ex->getTraceAsString()."]");
                }
            }

            // TODO: process removed items

            // send update to Miso
            $errors = MisoSearchService::instance()->upload("products", $misoItems);

            if ($flash) Flash::success('Updated Players');
            // \Log::info('~~ ADS->onUpdatePlayers - success');
        }
        catch (\Exception $ex) {
            if ($flash) Flash::error('Error during Players import: ' . $ex->getMessage());
            \Log::error('~~ Error during import - Players: '. $ex->getMessage() . " [".$ex->getTraceAsString()."]");
        }
    }

    public static function uploadToMisoSearch($flash = true, $league = null)
    {
        try {
            $dbLeagues = Db::table(League::TABLE)
                ->join(Sport::TABLE, League::TABLE.'.sport_guid', '=', Sport::TABLE.'.guid')
                ->select(League::TABLE.'.*', Sport::TABLE.'.name as sport_name', Sport::TABLE.'.slug as sport_slug')
                ->get()->all();

            $esPlayers = $league ? [] : Players::list(null, ["excludes" => ["seasons", "draft", "headshot"]]);
            if ($league) {
                $body = [
                    'query' => []
                ];
                ESModel::addAndTerm($body, 'league.id', $league);
                $response = ElasticsearchService::instance()->search(Players::$index, $body, null, ["excludes" => ["seasons", "draft", "headshot"]]);
                $esPlayers = $response->items;
            }
            $dbPlayers = $league
                ? DB::select("select player.* from ". Player::TABLE . " player " .
                    " inner join ".Team::TABLE." team on team.guid = player.team_guid ".
                    " where league_guid = '" . $league . "'")
                : DB::select("select * from ". Player::TABLE);

            $items = [];
            foreach ($dbPlayers as $dbPlayer) {
                $key = array_search($dbPlayer->guid, array_column($esPlayers, 'id'));
                if ($key === false) {
                    \Log::warning('~~ Player->uploadToMisoSearch - ES player not found: '.$dbPlayer->guid);
                    continue;
                }
                $esPlayer = $esPlayers[$key];
                $v = $esPlayer['league']['id'];
                $dbLeague = $entry = current(array_filter($dbLeagues, function($e) use($v){ return $e->guid == $v; }));
                if ($dbLeague === false) {
                    \Log::warning('~~ Player->uploadToMisoSearch - League not found: '.$v);
                    continue;
                }

                $items[] = self::constructProductForMiso($dbLeague, $dbPlayer, $esPlayer);
            }

            $errors = MisoSearchService::instance()->upload("products", $items);

            if ($errors) {
                if ($flash) Flash::success('Players upload to Miso FAILED, please check logs');
                \Log::warning('~~ Player->uploadToMisoSearch - errors', ['errors' => $errors]);
            } else {
                if ($flash) Flash::success('Uploaded Players to Miso');
                // \Log::info('~~ Player->uploadToMisoSearch - success');
            }
        }
        catch (\Exception $ex) {
            if ($flash) Flash::error('Exception during Player upload to Miso: ' . $ex->getMessage());
            \Log::error('~~ Error: Player->uploadToMisoSearch - exception:'. " [".$ex->getTraceAsString()."]");
        }
    }

    public static function constructProductForMiso($dbLeague, $dbPlayer, $esPlayer)
    {
        $createdAt = str_replace(' ', 'T', $dbPlayer->created_at).'Z';
        $updatedAt = str_replace(' ', 'T', $dbPlayer->updated_at).'Z';
        $biography = null;
        if (!empty($dbPlayer->bio)) {
            $bio = json_decode($dbPlayer->bio);
            $biography = isset($bio->biography) ? $bio->biography : null;
        }
        $teamName = null;
        $teamSlug = null;
        if (!empty($esPlayer['team'])) {
            $teamName = $esPlayer['team']['full_name'];
            $teamSlug = $esPlayer['team']['slug'];
        }
        $draftYear = !empty($esPlayer['draft']) && isset($esPlayer['draft']['year']) ? (string)$esPlayer['draft']['year'] : null;
        $category = [$dbLeague->sport_name, $dbLeague->name];
        if (!empty($teamName)) $category[] = $teamName;
        $tags = [$dbLeague->sport_slug, $dbLeague->slug];
        if (!empty($teamSlug)) $tags[] = $teamSlug;

        $result = [
            "type" => "players",
            "product_id" => $dbPlayer->guid,
            "title" => $dbPlayer->name,
            "description" => $biography,
            "product_group_id" => $dbPlayer->team_guid,
            "categories" => [$category],
            "tags" => $tags,
            "created_at" => $createdAt,
            "updated_at" => $updatedAt,
            "custom_attributes" => [
                "sport" => $dbLeague->sport_name,
                "league" => $dbLeague->name,
                "team" => $teamName,
                "position" => isset($esPlayer['position']) ? (string)$esPlayer['position'] : null,
                "jersey_number" => isset($esPlayer['jersey_number']) ? (string)$esPlayer['jersey_number'] : null,
                "nickname" => $dbPlayer->nickname,
                "birthplace" => isset($esPlayer['birth_place']) ? (string)$esPlayer['birth_place'] : null,
                "draft_year" => $draftYear,
                "is_featured" => $dbPlayer->is_featured,
                "is_verified" => $dbPlayer->is_verified
            ]
        ];
        return $result;
    }

    public static function sendPageViewToMiso($product_id, $product_group_id, $referrer, $title)
    {
        try {
            $url = Request::url();
            $anonymous_id = Cookie::get('miso_search_anonymous_id');
            $item = [
                "type" => "product_detail_page_view",
                "product_ids" => ["$product_id"],
                "product_group_ids" => ["$product_group_id"],
                "anonymous_id" => "$anonymous_id",
                "timestamp" => gmdate("Y-m-d\TH:i:s\Z"),
                "context" => [
                    "page" => [
                        "url" => "$url",
                        "referrer" => "$referrer",
                        "title" => "$title"
                    ]
                ]
            ];
            $errors = MisoSearchService::instance()->upload("interactions", [$item]);

            if ($errors) {
                \Log::warning('~~ Player->sendPageViewToMiso - errors', ['errors' => $errors]);
            }
        } catch (\Exception $ex) {
            \Log::error('~~ Error: Player->sendPageViewToMiso - exception:'. " [".$ex->getTraceAsString()."]");
        }
    }
}
