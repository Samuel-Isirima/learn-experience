<?php namespace scs\osdb\Models;

use Backend\Models\ImportModel;

/**
 * TeamImport Model
 */
class TeamImport extends ImportModel
{
    /**
     * @var array The rules to be applied to the data.
     */
    public $rules = ['guid' => 'required'];

    public function importData($results, $sessionKey = null)
    {
        
        foreach ($results as $row => $data) {
            try {

                $team_guid = $data['guid'];

                $team = Team::where('guid', $team_guid)->first();

                //$this->logError($row, $team);  //<- cheap way to debug

                if( $team )
                {
                    //adding a overwrite check, for now import is a save process ONLY setting new values, does not overwrite values.
                    //Social links are always populated after the first save event, even if blank
                    if( $team['social_links'] == "" )
                    {
                        $team_data = [
                                        'foundedby' => $data['foundedby'],
                                        'social_links' => json_decode($data['social_links']),
                                        'executive_team' => json_decode($data['executive_team']),
                                        'notable_alumni' => json_decode($data['notable_alumni']),
                                        'history' => $data['history'],
                                        'metadata_firsts' => json_decode($data['metadata_firsts'])
                                    ];


                        $team->update($team_data);
                        //Team::where('guid', $team_guid)->update('social_links' => $data['social_links']);

                        //$this->logError($row, $team_data['social_links']);

                        $this->logUpdated();
                    }
                    else
                    {
                        $this->logError($row, $team['name'] . ": Cannot import record, data already exists.");
                    }
                }
                else
                {
                    //no action - we are only updating existing data.
                }
                
            } catch (\Exception $ex) {
                $this->logError($row, $ex->getMessage());
            }
        }
        
    }
}