<?php namespace scs\osdb\Models;

use Backend\Models\ExportModel;

/**
 * PlayerExport Model
 */
class PlayerExport extends ExportModel
{
    public function exportData($columns, $sessionKey = null)
    {
        //$players = Player::where('guid', 'bd519b9f-7539-4282-a741-3bd2bf532c40')->take(1)->get(); //good testing line
        $players = Player::select('*')->get();     

        $players->each(function($player) use ($columns) {
            $player->addVisible($columns);
        });
        $collection = collect($players->toArray());
        
        $data = $collection->map(function ($item) {
            if(is_array($item)){
                foreach($item as $key => $value) {
                    if(is_array($value)) {
                        $item[$key] = json_encode($value);
                    }
                }
            }
            return $item;
        });

        return $data->toArray();
    }
}