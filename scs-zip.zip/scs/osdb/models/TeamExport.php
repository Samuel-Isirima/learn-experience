<?php namespace scs\osdb\Models;

use Backend\Models\ExportModel;

/**
 * TeamExport Model
 */
class TeamExport extends ExportModel
{
    public function exportData($columns, $sessionKey = null)
    {
        //$teams = Team::all();     //Calls AfterFetch, therefore want to avoid this one.  
        //$teams = Team::where('slug', 'toronto-raptors')->take(1)->get(); //good testing line
        $teams = Team::select('*')->get();     

        $teams->each(function($team) use ($columns) {
            $team->addVisible($columns);
        });
        $collection = collect($teams->toArray());
        
        $data = $collection->map(function ($item) {
            if(is_array($item)){
                foreach($item as $key => $value) {
                    if(is_array($value)) {
                        $item[$key] = json_encode($value);
                    }
                }
            }
            return $item;
        });

        return $data->toArray();
    }
}