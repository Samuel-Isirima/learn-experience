<?php namespace SCS\Osdb\Models;

use Cookie;
use Request;
use Illuminate\Support\Facades\DB;
use Model;
use Flash;
use SCS\Osdb\Classes\ES\Leagues;
use SCS\Osdb\Classes\Services\ElasticsearchService;
use SCS\Osdb\Classes\Services\MisoSearchService;


/**
 * Model
 */
class League extends Model
{
    use \October\Rain\Database\Traits\Validation;

    const INDEX = 'leagues';
    public const TABLE = 'scs_osdb_league';

    /**
     * @var string The database table used by the model.
     */
    public $table = 'scs_osdb_league';
    public $primaryKey = 'guid';
    public $incrementing = false;

    /**
     * @var array Validation rules
     */
    public $rules = [
    ];

    /** Relations **/
    public $belongsTo = [
        'sport' => ['scs\osdb\models\Sport', 'key' => 'sport_guid']
    ];

    public $hasMany = [
        'team' => 'scs\osdb\models\Team',
        'playerstatistics' => 'scs\statistics\models\PlayerStatisticsDictionary'
    ];

    public function getImageAssetPathAttribute()
    {
        return $this->slug;
    }


    //Sample on how to work with the appending json objects.

    //protected $appends = ['conferences', 'TeamCarousel'];
    //public $jsonable = ['conferences', 'TeamCarousel'];
    
    public function afterSave()
    {
        // TODO: somehow detect and not run for ADS export page
        // Example - update "alias" field
        /*$id = $this->getAttribute('guid');
        $alias = $this->getAttribute('alias');
        $index = 'leagues';
        $fields = ['alias' => $alias];
        $response = ElasticsearchService::instance()->update(self::INDEX, $id, $fields);*/
    }

    public static function uploadToMisoSearch($flash = true)
    {
        try {
            //$esList = Leagues::list();
            $dbLeagues = Db::table(League::TABLE)
                ->join(Sport::TABLE, League::TABLE.'.sport_guid', '=', Sport::TABLE.'.guid')
                ->select(League::TABLE.'.*', Sport::TABLE.'.name as sport_name', Sport::TABLE.'.slug as sport_slug')
                ->get()->all();

            $items = [];
            foreach ($dbLeagues as $dbLeague) {
                $createdAt = str_replace(' ', 'T', $dbLeague->created_at).'Z';
                $updatedAt = str_replace(' ', 'T', $dbLeague->updated_at).'Z';
                $items[] = [
                    "type" => "leagues",
                    "product_id" => $dbLeague->guid,
                    "title" => $dbLeague->name,
                    "description" => $dbLeague->name,
                    "product_group_id" => $dbLeague->sport_guid,
                    "categories" => [[ $dbLeague->sport_name]],
                    "tags" => [$dbLeague->sport_slug, $dbLeague->slug],
                    "created_at" => $createdAt,
                    "updated_at" => $updatedAt,
                    "custom_attributes" => ["sport" => $dbLeague->sport_name]
                ];
            }
            $errors = MisoSearchService::instance()->upload("products", $items);

            if ($errors) {
                if ($flash) Flash::success('Leagues upload to Miso FAILED, please check logs');
                \Log::warning('~~ League->uploadToMisoSearch - errors', ['errors' => $errors]);
            } else {
                if ($flash) Flash::success('Uploaded Leagues to Miso');
                // \Log::info('~~ League->uploadToMisoSearch - success');
            }
        }
        catch (\Exception $ex) {
            if ($flash) Flash::error('Exception during Leagues upload to Miso: ' . $ex->getMessage());
            \Log::error('~~ Error: League->uploadToMisoSearch - exception:'. " [".$ex->getTraceAsString()."]");
        }
    }

    public static function sendPageViewToMiso($product_id, $product_group_id, $referrer, $title)
    {
        try {
            $url = Request::url();
            $anonymous_id = Cookie::get('miso_search_anonymous_id');
            $item = [
                "type" => "product_detail_page_view",
                "product_ids" => ["$product_id"],
                "product_group_ids" => ["$product_group_id"],
                "anonymous_id" => "$anonymous_id",
                "timestamp" => gmdate("Y-m-d\TH:i:s\Z"),
                "context" => [
                    "page" => [
                        "url" => "$url",
                        "referrer" => "$referrer",
                        "title" => "$title"
                    ]
                ]
            ];
            $errors = MisoSearchService::instance()->upload("interactions", [$item]);

            if ($errors) {
                \Log::warning('~~ League->sendPageViewToMiso - errors', ['errors' => $errors]);
            }
        } catch (\Exception $ex) {
            \Log::error('~~ Error: League->sendPageViewToMiso - exception:'. " [".$ex->getTraceAsString()."]");
        }
    }
}
