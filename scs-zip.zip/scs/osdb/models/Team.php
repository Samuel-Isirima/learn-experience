<?php namespace SCS\Osdb\Models;

use Cookie;
use Request;
use Model;
use Flash;
use Illuminate\Support\Facades\DB;
use SCS\Osdb\Classes\ES\ESModel;
use SCS\Osdb\Classes\ES\Leagues;
use SCS\Osdb\Classes\ES\Teams;
use SCS\Osdb\Classes\Services\ElasticsearchService;
use SCS\Osdb\Classes\Services\MisoSearchService;

/**
 * Model
 */
class Team extends Model
{
    use \October\Rain\Database\Traits\Validation;

    public $implement = [
        'October.Rain.Database.Behaviors.Purgeable'
    ];

    public $purgeable = ['_conference', '_division', '_venue_location', '_venue_name', '_venue_capacity', '_foundedYear', '_leagueinfo', '_teaminfo'];

    public const TABLE = 'scs_osdb_team';

    /**
     * @var string The database table used by the model.
     */
    public $table = 'scs_osdb_team';
    public $primaryKey = 'guid';
    public $incrementing = false;

    /**
     * @var array Validation rules
     */
    public $rules = [
    ];

    /** Relations **/
    public $belongsTo = [
        'league' => ['scs\osdb\models\League', 'key' => 'league_guid'],
    ];
    public $belongsToMany = [
    ];
    public $hasMany = [
        'player' => 'scs\osdb\models\Player'
    ];

    public $attachMany = [
        'historical_images' => 'System\Models\File'
    ];

    public $jsonable = ['metadata_firsts', 'social_links', 'executive_team', 'notable_alumni', 'awards', 'endorsements'];

    public function getLeagueFilter()
    {
        $leagues = Leagues::getLeagues();
        $result = [];
        foreach ($leagues as $league){
            $result[$league['id']] = $league['alias'];
        }
        return $result;
    }

    //returns back the Asset path used for the Team object
    public function getImageAssetPathAttribute()
    {
        if ($this->league) {
            //is checking to see if it is a object or string - list or form usage
            if (gettype($this->league) != "string") {
                return $this->league->name .'/'.$this->slug;
            } else {
                return $this->league .'/'.$this->slug;
            }
        } else {
            return $this->slug;
        }
    }

    public function extendWithESData()
    {
        $adsData = Teams::getById($this->guid);

        $this->_conference = array_get($adsData, 'conference.name');
        $this->_division = array_get($adsData, 'division.name');
        $this->_venue_location = array_get($adsData, 'venue.city');
        $venueState = array_get($adsData, 'venue.state');
        if ($venueState) $this->_venue_location .= ', ' . $venueState ;
        $this->_venue_name = array_get($adsData, 'venue.name');
        $this->_venue_capacity = array_get($adsData, 'venue.capacity');

        $league = strtolower(array_get($adsData, 'league.alias'));
        $teamId = array_get($adsData, 'team_id');
        $this->_widget_team_id = $league == 'nfl' ? 'sd:team:'.$this->guid : $teamId;

        $this->_foundedYear = array_get($adsData, 'founded'); //array_get($adsData, 'founded'); ONLY AVAILABLE for NBA - therefore not being included.
        $this->_league = $league;

        $this->_leagueinfo = '{ "league": "' . strtolower(array_get($adsData, 'league.alias')) . '", "name":"' . array_get($adsData, 'league.name') . '"}';
        $this->_teaminfo = '{ "logopath": "' . strtolower(array_get($adsData, 'league.alias')) . '/' . $this->slug . '", "name":"' . $this->name . '"}';

        if (key_exists("staff", $adsData)) {
            $index = array_search('manager', array_map('strtolower', array_column($adsData['staff'],'position')));
            if ($index !== false) $this->_manager = $adsData['staff'][$index]['full_name'];
            $index = array_search('head coach',array_map('strtolower', array_column($adsData['staff'],'position')));
            if ($index !== false) $this->_headcoach = $adsData['staff'][$index]['full_name'];
        } else {
            $this->_manager = null;
            $this->_headcoach = null;
        }
    }

    // public function afterFetch()
    // {
    //     // \Log::warning('~~ call to old Team afterFetch().');
    //     $this->extendWithESData();
    // }

    public function afterSave()
    {
        $esTeam = Teams::getById($this->guid);
        $dbTeam = Db::table(Team::TABLE)->where('guid', $this->guid)->first();
        if ($dbTeam != null && $esTeam != null) {
            // send update to Miso
            $dbLeague = Db::table(League::TABLE)
                ->where(League::TABLE.'.guid', '=', $dbTeam->league_guid)
                ->join(Sport::TABLE, League::TABLE.'.sport_guid', '=', Sport::TABLE.'.guid')
                ->select(League::TABLE.'.*', Sport::TABLE.'.name as sport_name', Sport::TABLE.'.slug as sport_slug')
                ->first();
            if ($dbLeague != null) {
                $misoItem = self::constructProductForMiso($dbLeague, $dbTeam, $esTeam);
                $errors = MisoSearchService::instance()->upload("products", [$misoItem]);
            }
        }
    }

    public function scopeIsFeatured($query, $value = 1)
    {
        return $query->where('is_featured', $value);
    }

    public static function loadESTeams($flash, $league = null)
    {
        try {
            $misoItems = [];

            $esList = $league ? [] : Teams::list() ;
            if ($league) {
                $body = [
                    'query' => []
                ];
                ESModel::addAndTerm($body, 'league.id', $league);
                $response = ElasticsearchService::instance()->search(Teams::$index, $body);
                $esList = $response->items;
            }

            $dbTeams = $league
                ? DB::select("select guid, name, slug from ". Team::TABLE . " where league_guid = '" . $league . "'")
                : DB::select("select guid, name, slug from ". Team::TABLE);
            $dbIds = array_map(function ($item) {
                return $item->guid;
            }, $dbTeams);
            // \Log::info('~~ ADS->onUpdateTeams - DB teams: '.count($dbIds), ['count#'=>count($dbIds)]);

            $esIds = array_map(function ($item) {
                return $item['id'];
            }, $esList);
            // \Log::info('~~ ADS->onUpdateTeams - ES teams: '.count($esIds), ['count#'=>count($esIds)]);

            $dbLeagues = Db::table(League::TABLE)
                ->join(Sport::TABLE, League::TABLE.'.sport_guid', '=', Sport::TABLE.'.guid')
                ->select(League::TABLE.'.*', Sport::TABLE.'.name as sport_name', Sport::TABLE.'.slug as sport_slug')
                ->get()->all();

            foreach ($esIds as $esId) {
                try {
                    if (!in_array($esId, $dbIds)) {
                        // insert new Team into DB
                        \Log::warning('~~ ADS->onUpdateTeams - unmatched esId: '.$esId.' - creating team', ['unmatched esID'=>$esId]);
                        $key = array_search($esId, array_column($esList, 'id'));
                        $esTeam = $esList[$key];
                        $leagueId = $esTeam['league']['id'];
                        $dbLeague = $entry = current(array_filter($dbLeagues, function($e) use($leagueId){ return $e->guid == $leagueId; }));
                        if ($dbLeague) {
                            // TODO: use DB directly to avoid afterSave call
                            Team::create([
                                'guid'=>$esId,
                                'name'=>$esTeam['full_name'],
                                'league_guid' => $esTeam['league']['id'],
                                'slug'=>$esTeam['slug']
                            ]);
                            // also send Product to Miso
                            $misoItems[] = self::constructProductForMiso($dbLeague, null, $esTeam);
                        } else {
                            \Log::error('~~ ADS->onUpdateTeams - cannot get league for: '.$esId);
                        }
                    } else {
                        $key = array_search($esId, array_column($esList, 'id'));
                        $esTeam = $esList[$key];
                        $leagueId = $esTeam['league']['id'];
                        $dbLeague = $entry = current(array_filter($dbLeagues, function($e) use($leagueId){ return $e->guid == $leagueId; }));
                        if ($dbLeague) {
                            $searchedValue = $esId;
                            $dbTeamsFiltered = array_filter(
                                $dbTeams,
                                function ($e) use (&$searchedValue) {
                                    return $e->guid == $searchedValue;
                                }
                            );
                            $dbTeam = !empty($dbTeamsFiltered) && count($dbTeamsFiltered) > 0 ? array_values($dbTeamsFiltered)[0] : null;
                            $teamName = isset($esTeam['full_name']) ? $esTeam['full_name'] : $dbTeam->name;
                            $teamSlug = isset($esTeam['slug']) ? $esTeam['slug'] : $dbTeam->slug;
                            if (isset($dbTeam) && $dbTeam && ($dbTeam->slug != $teamSlug || $dbTeam->name != $teamName)){
                                Team::where('guid', $esId)
                                    ->update([
                                        'name'=>$teamName,
                                        'slug' => $teamSlug]);
                                // add item to Miso list
                                $misoItems[] = self::constructProductForMiso($dbLeague, null, $esTeam);
                            }
                        } else {
                            \Log::error('~~ ADS->onUpdateTeams - cannot get league for: '.$esId);
                        }
                    }
                }
                catch (\Exception $ex) {
                        \Log::error('~~ Error during import - Team='.$esId.':'. " [".$ex->getTraceAsString()."]");
                    }
            }

            // send new items to Miso
            if (count($misoItems) > 0) {
                $errors = MisoSearchService::instance()->upload("products", $misoItems);
            }
            // TODO: process removed items

            if ($flash) Flash::success('Updated Teams');
            // \Log::info('~~ ADS->onUpdateTeams - success');
        }
        catch (\Exception $ex) {
            if ($flash) Flash::error('Error during Teams import: ' . $ex->getMessage());
            \Log::error('~~ Error during import - Teams:'. " [".$ex->getTraceAsString()."]");
        }
    }

    public static function constructProductForMiso($dbLeague, $dbTeam, $esTeam)
    {
        $founded_year = null;
        $arena_name = null;
        if ($dbTeam != null && !empty($dbTeam->metadata_firsts)) {
            $metadata = json_decode($dbTeam->metadata_firsts);
            $founded = $metadata->founded;
            if (!empty($founded)) {
                $parts = explode('/', $founded);
                $founded_year = end($parts);
            }
            $arena_name = $metadata->arena_name;
        }
        $createdAt = $dbTeam != null ? str_replace(' ', 'T', $dbTeam->created_at).'Z' : gmdate("Y-m-d\TH:i:s\Z");
        $updatedAt = $dbTeam != null ? str_replace(' ', 'T', $dbTeam->updated_at).'Z' : gmdate("Y-m-d\TH:i:s\Z");
        $result = [
            "type" => "teams",
            "product_id" => $esTeam['id'],
            "title" => $esTeam['full_name'],
            "description" => $dbTeam != null ? $dbTeam->history : $esTeam['full_name'],
            "product_group_id" => $esTeam['league']['id'],
            "categories" => [[ $dbLeague->sport_name, $dbLeague->name]],
            "tags" => [$dbLeague->sport_slug, $dbLeague->slug, $esTeam['slug']],
            "created_at" => $createdAt,
            "updated_at" => $updatedAt,
            "custom_attributes" => [
                "sport" => $dbLeague->sport_name,
                "league" => $dbLeague->name,
                "market" => $esTeam['market'],
                "division_name" => $esTeam['division']['name'],
                "conference_name" => $esTeam['conference']['name'],
                "founded_year" => $founded_year,
                "arena_name" => $arena_name,
                "alias" => $esTeam['alias'],
                "is_featured" => $dbTeam != null ? $dbTeam->is_featured : 0
            ]
        ];
        return $result;
    }

    public static function uploadToMisoSearch($flash = true, $league = null)
    {
        try {
            $dbLeagues = Db::table(League::TABLE)
                ->join(Sport::TABLE, League::TABLE.'.sport_guid', '=', Sport::TABLE.'.guid')
                ->select(League::TABLE.'.*', Sport::TABLE.'.name as sport_name', Sport::TABLE.'.slug as sport_slug')
                ->get()->all();

            $esTeams = $league ? [] : Teams::list(null, ["excludes" => ["staff", "players"]]);
            if ($league) {
                $body = [
                    'query' => []
                ];
                ESModel::addAndTerm($body, 'league.id', $league);
                $response = ElasticsearchService::instance()->search(Teams::$index, $body, null, ["excludes" => ["staff", "players"]]);
                $esTeams = $response->items;
            }
            $dbTeams = $league
                ? DB::select("select * from ". Team::TABLE .
                    " where league_guid = '" . $league . "'")
                : DB::select("select * from ". Team::TABLE);

            $items = [];
            foreach ($dbTeams as $dbTeam) {
                $key = array_search($dbTeam->guid, array_column($esTeams, 'id'));
                if ($key === false) {
                    \Log::warning('~~ Team->uploadToMisoSearch - ES team not found: '.$dbTeam->guid);
                    continue;
                }
                $esTeam = $esTeams[$key];
                $v = $dbTeam->league_guid;
                $dbLeague = $entry = current(array_filter($dbLeagues, function($e) use($v){ return $e->guid == $v; }));
                if ($dbLeague === false) {
                    \Log::warning('~~ Team->uploadToMisoSearch - League not found: '.$v);
                    continue;
                }

                $items[] = self::constructProductForMiso($dbLeague, $dbTeam, $esTeam);
            }
            $errors = MisoSearchService::instance()->upload("products", $items);

            if ($errors) {
                if ($flash) Flash::success('Teams upload to Miso FAILED, please check logs');
                \Log::warning('~~ Team->uploadToMisoSearch - errors', ['errors' => $errors]);
            } else {
                if ($flash) Flash::success('Uploaded Teams to Miso');
                // \Log::info('~~ Team->uploadToMisoSearch - success');
            }
        }
        catch (\Exception $ex) {
            if ($flash) Flash::error('Exception during Team upload to Miso: ' . $ex->getMessage());
            \Log::error('~~ Error: Team->uploadToMisoSearch - exception:'. " [".$ex->getTraceAsString()."]");
        }
    }

    public static function sendPageViewToMiso($product_id, $product_group_id, $referrer, $title)
    {
        try {
            $url = Request::url();
            $anonymous_id = Cookie::get('miso_search_anonymous_id');
            $item = [
                "type" => "product_detail_page_view",
                "product_ids" => ["$product_id"],
                "product_group_ids" => ["$product_group_id"],
                "anonymous_id" => "$anonymous_id",
                "timestamp" => gmdate("Y-m-d\TH:i:s\Z"),
                "context" => [
                    "page" => [
                        "url" => "$url",
                        "referrer" => "$referrer",
                        "title" => "$title"
                    ]
                ]
            ];
            $errors = MisoSearchService::instance()->upload("interactions", [$item]);

            if ($errors) {
                \Log::warning('~~ Team->sendPageViewToMiso - errors', ['errors' => $errors]);
            }
        } catch (\Exception $ex) {
            \Log::error('~~ Error: Team->sendPageViewToMiso - exception:'. " [".$ex->getTraceAsString()."]");
        }
    }
}
