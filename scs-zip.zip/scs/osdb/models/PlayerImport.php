<?php namespace scs\osdb\Models;

use Backend\Models\ImportModel;
use Illuminate\Support\Facades\DB;

/**
 * PlayerImport Model
 */
class PlayerImport extends ImportModel
{
    /**
     * @var array The rules to be applied to the data.
     */
    public $rules = ['guid' => 'required'];

    public function importData($results, $sessionKey = null)
    {
        set_time_limit(3000);   //setting a longer time limit due to the amount of data this is going to parse.

        foreach ($results as $row => $data) {
            try {

                $player_guid = $data['guid'];

                //Changed over to the DB process due to the Model::afterfetch being called with the following; 
                //$player = Player::where('guid', $player_guid)->first();

                $player = Db::table(Player::TABLE)->where('guid', $player_guid)->get()->first();
                                           
                if( $player )
                {
                    //adding a overwrite check, for now import is a save process ONLY setting new values, does not overwrite values.
                    //Social links are always populated after the first save event, even if blank
                    if( $player -> social_links == "" )
                    //if( $player['social_links'] == "" )
                    {
                        //$player_data = [
                        //                'social_links' => json_decode($data['social_links']),
                        //                'contracts' => json_decode($data['contracts']),
                        //                'endorsements' => json_decode($data['endorsements']),
                        //                'charities' => json_decode($data['charities']),
                        //                'agent' => json_decode($data['agent']),
                        //                'bio' => json_decode($data['bio'])
                        //            ];
                        
                        //$player->update($player_data);

/*
                        Db::update("update ". Player::TABLE ." set 
                                                    social_links='".$data['social_links']."' 
                                                    , contracts='".$data['contracts']."' 
                                                    , endorsements='".$data['endorsements']."' 
                                                    , charities='".$data['charities']."' 
                                                    , agent='".$data['agent']."' 
                                                    , bio='".$data['bio']."' 
                            where guid = '" . $player_guid . "'");
*/                            
/*
                        Db::table(Player::TABLE)->where('guid', $player_guid)->update(
                                                    ['social_links' => $data['social_links']],
                                                    ['contracts' => $data['contracts']],
                                                    ['endorsements' => $data['endorsements']],
                                                    ['charities' => $data['charities']],
                                                    ['agent' => $data['agent']],
                                                    ['bio' => $data['bio']]
                                                    );
*/
                        Db::table(Player::TABLE)->where('guid', $player_guid)->update(['social_links' => $data['social_links']]);
                        Db::table(Player::TABLE)->where('guid', $player_guid)->update(['contracts' => $data['contracts']]);
                        Db::table(Player::TABLE)->where('guid', $player_guid)->update(['endorsements' => $data['endorsements']]);
                        Db::table(Player::TABLE)->where('guid', $player_guid)->update(['charities' => $data['charities']]);
                        Db::table(Player::TABLE)->where('guid', $player_guid)->update(['agent' => $data['agent']]);
                        Db::table(Player::TABLE)->where('guid', $player_guid)->update(['bio' => $data['bio']]);
                        Db::table(Player::TABLE)->where('guid', $player_guid)->update(['contact' => $data['contact']]);

                        $this->logUpdated();
                    }
                    else
                    {
                        $this->logError($row, $player->name . ": Cannot import record, data already exists.");
                        //$this->logError($row, $player['name'] . ": Cannot import record, data already exists.");
                    }
                }
                else
                {
                    //no action - we are only updating existing data.
                }
                
            } catch (\Exception $ex) {
                $this->logError($row, $ex->getMessage());
            }
        }
        
    }
}