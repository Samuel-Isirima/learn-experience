<?php

Route::get('{leagueSlug}/players/{playerName}/{detailsType}/{guid}', 'SCS\Osdb\Controllers\Player@redirectDetailsToSlug');
// define routes to redirect old url structure to new url structure
Route::get('{leagueSlug}/players/{playerName}/{guid}', 'SCS\Osdb\Controllers\Player@redirectProfileToSlug')
    ->where('guid', '^(?!bio$|biography$|business$|contracts$|endorsements$|philanthropy$|statistics$).*'); // exclude the page specific routes which is valid for the new url structure

