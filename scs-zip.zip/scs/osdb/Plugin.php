<?php namespace SCS\Osdb;

use Backend;
use Carbon\Carbon;
use Event;
use SCS\Osdb\Classes\ES\Leagues;
use SCS\Osdb\Classes\StaticMenu\StaticMenuExtensions;
use SCS\Osdb\Controllers\Player;
use SCS\Osdb\Models\League;
use SCS\Osdb\Models\Season;
use SCS\Osdb\Models\Team;
use SCS\Osdb\Models\Player as PlayerModel;
use System\Classes\PluginBase;
use DateTime;
use System\Classes\PluginManager;
use Backend\Classes\NavigationManager;

class Plugin extends PluginBase
{

    public function pluginDetails()
    {
        return [
            'name' => 'OSDB',
            'description' => 'Plugin for Sport, League, Player, Team and general site updates',
            'author' => 'SCS',
            'icon' => 'icon-database'
        ];
    }

    public function boot()
    {
        parent::boot();

        StaticMenuExtensions::initialize();

        // TODO: do we need granular permissions on Builder?
        // $pluginManager = PluginManager::instance()->findByIdentifier('Rainlab.Builder');
        // $navigationManager = NavigationManager::instance();

        // if (class_exists('\RainLab\Builder\Controllers\Index')) {

        //     \RainLab\Builder\Controllers\Index::extend(function ($model) {
        //         Event::listen('backend.menu.extendItems', function ($navigationManager) {
        //             $menu = $navigationManager->listMainMenuItems();
        //         });

        //     });
        // }
    }

    public function registerComponents()
    {
    }

    public function registerSettings()
    {
    }

    public function registerSchedule($schedule)
    {
        $schedule->call(function () {
            \Log::info('~~ ADS update ESSeasons - scheduled call -> starts '.date('Y-m-d_H:i:s'));
            Season::loadESSeasons(false);
            \Log::info('~~ ADS update ESSeasons - scheduled call <- ends '.date('Y-m-d_H:i:s'));
        })->hourly();

        // call ADS update for Teams and Players by league to prevent too long calls
        $leagues = Leagues::getLeagues();
        foreach ($leagues as $league){
            $leagueId =  $league['id'];
            $schedule->call(function () use ($leagueId) {
                \Log::info('~~ ADS update ESTeams ['.$leagueId.'] - scheduled call -> starts '.date('Y-m-d_H:i:s'));
                Team::loadESTeams(false, $leagueId);
                \Log::info('~~ ADS update ESTeams ['.$leagueId.'] - scheduled call <- ends '.date('Y-m-d_H:i:s'));
            })->hourly();
            $schedule->call(function () use ($leagueId) {
                \Log::info('~~ ADS update loadESPlayers ['.$leagueId.'] - scheduled call -> starts '.date('Y-m-d_H:i:s'));
                PlayerModel::loadESPlayers(false, $leagueId);
                \Log::info('~~ ADS update loadESPlayers ['.$leagueId.'] - scheduled call <- ends '.date('Y-m-d_H:i:s'));
            })->hourly();
        }
    }

    public function registerMarkupTags()
    {
        return[
            'functions' => [
                'GetPlayerAge' => function ($birthdate)
                {
                    if (null === $birthdate) {
                        return null;
                    }
                    $birthdate = new DateTime($birthdate);
                    $today = new DateTime('today');

                    return $birthdate->diff($today)->y;
                },
                'ShuffleActionCards' => function ($teamSeasonList, $players) {
                    $teams = [];
                    if (!empty($teamSeasonList)) {
                        foreach ($teamSeasonList as $league) {
                            foreach($league as $team) {
                                $team['is_team_card'] = true;
                                $teams[]= $team;
                            }
                        }
                    }
                    if (empty($teams) && empty($players)) return [];
                    if (empty($teams)) return $players;
                    if (empty($players)) return $teams;
                    if (count($teams) > count($players)) {
                        $longArray = $teams;
                        $shortArray = $players;
                    } else {
                        $longArray = $players;
                        $shortArray = $teams;
                    }
                    $interval = floor(count($longArray) / count($shortArray));
                    $items = [];
                    $i = 0;
                    foreach ($longArray as $longArrayItem) {
                        $items[]= $longArrayItem;
                        if (++$i >= $interval) {
                            $i = 0;
                            if (!empty($shortArray)) $items[]= array_shift($shortArray);
                        }
                    }
                    if (!empty($shortArray)) $items = array_merge($items, $shortArray);
                    return $items;
                }
            ],
            'filters' => [
                'player_height' => function ($inches) {
                    return Player::formatHeight($inches);
                },
                'player_weight' => function ($lbs) {
                    return Player::formatWeight($lbs);
                },
                'league_widget_name' => function($league){
                    return strtolower($league) == 'mls' ? 'soccer' : $league;
                },
                'league_slug' => function ($url) {
                    $slugs = League::all()->pluck('slug')->join('|');
                    if (!empty($slugs)) {
                        $matches = [];
                        if (preg_match("/\/($slugs)(\/|$)/", $url, $matches)) {
                            return $matches[1];
                        }
                    }
                    return '';
                },
                'encode_name' => function ($name) {
                    return Player::encodeName($name);
                },
                'intval' => function ($value) {
                    return intval($value);
                },
                'no_empty_paragraphs' => function ($value) {
                    $value = preg_replace('/<\s*p[^>]*\/>/', '', $value);
                    $value = preg_replace('/<\s*p[^>]*>\s*(<\s*br\/?\s*>)*\s*<\/\s*p\s*>/', '', $value);
                    return $value;
                },
                'time_ago' => function ($value) {
                    return Carbon::parse($value)->diffForHumans();
                }
            ]
        ];
    }

    public function registerPermissions()
    {
        return [
            'scs.osdb.access' => [
                'label' => 'Access and Edit OSDB content.',
                // 'order' => 200,
                'tab' => 'OSDB',
                // 'roles' => ['developer','publisher']
            ],
        ];
    }

    public function registerFormWidgets()
    {
        return [
            'SCS\Osdb\FormWidgets\ContractTeam' => 'contractteam'
        ];
    }

    // public function registerNavigation()
    // {
    //     return [
    //         /*
    //         'main-menu-osdb' => [
    //             'label'       => 'OSDB',
    //             'url'         => Backend::url('scs/osdb/sport'),
    //             'icon'        => 'icon-database',
    //             'permissions' => ['scs.osdb.*'], // PERMISSIONS FOR THIS
    //             'order'       => 10,
    //             'sideMenu' => [
    //                 'side-menu-sport' => [
    //                     'label' => 'Sport',
    //                     'icon'        => 'icon-soccer-ball-o',
    //                     'url'         =>  Backend::url('scs/osdb/sport'),
    //                 ],
    //                 'side-menu-league' => [
    //                     'label' => 'League',
    //                     'icon'        => 'icon-trophy',
    //                     'url'         =>  Backend::url('scs/osdb/league'),
    //                 ],
    //                 'side-menu-team' => [
    //                     'label' => 'Team',
    //                     'icon'        => 'icon-users',
    //                     'url'         =>  Backend::url('scs/osdb/team'),
    //                 ],
    //                 'side-menu-player' => [
    //                     'label' => 'Player',
    //                     'icon'        => 'icon-user',
    //                     'url'         =>  Backend::url('scs/osdb/player'),
    //                 ],
    //             ]
    //         ],
    //         'main-menu-osdb' => [
    //             'label'       => 'ADS',
    //             'url'         => Backend::url('scs/osdb/ads'),
    //             'icon'        => 'icon-server',
    //             'permissions' => ['scs.osdb.*'], // PERMISSIONS FOR THIS
    //             'order'       => 900,
    //         ],
    //         */
    //     ];
    // }
}
