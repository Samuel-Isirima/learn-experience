<?php namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableUpdateScsOsdbTeam3 extends Migration
{
    public function up()
    {
        Schema::table('scs_osdb_team', function($table)
        {
            $table->text('notable_alumni')->nullable();
        });
    }
    
    public function down()
    {
        Schema::table('scs_osdb_team', function($table)
        {
            $table->dropColumn('notable_alumni');
        });
    }
}
