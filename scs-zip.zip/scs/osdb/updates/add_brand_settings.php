<?php namespace SCS\Osdb\Updates;

use Seeder;
use DB;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;

class AddBrandSettings extends Migration
{
    public function up()
    {
        DB::table('system_settings')->updateOrInsert(
            [
                'item' => 'backend_brand_settings',
                'value' => '{"app_name":"OSDB","app_tagline":"Online Sports DataBase","primary_color":"#4f5458","secondary_color":"#708598","accent_color":"#ecf0f1","menu_mode":"inline","custom_css":""}'
            ]
        );
    }

    public function down()
    {
    }
}
