<?php namespace SCS\Osdb\Updates;

use SCS\Osdb\Models\Season;
use Schema;
use October\Rain\Database\Updates\Migration;

class TableUpdateScsOsdbSeasons extends Migration
{
    public function up()
    {
        $seasons = Season::all();
        $seasonCount = [];
        foreach ($seasons as $i => $season) {
            $count = 0;
            if (array_key_exists($season->guid, $seasonCount)) $count = $seasonCount[$season->guid];
            $seasonCount[$season->guid] = $count + 1;
        }
        foreach ($seasonCount as $key => $value){
            if ($value > 1) {
                $season = null;
                foreach ($seasons as $i => $item) {
                    if ($item->guid == $key) {
                        $season = $item;
                        break;
                    }
                }
                if ($season) {
                    Season::where('guid', $key)->delete();
                    Season::create([
                        'guid'=>$season->guid,
                        'year'=>$season->year,
                        'type'=>$season->type,
                        'status'=>$season->status,
                        'season_id'=>$season->season_id,
                        'competition_id'=>$season->competition_id,
                        'start_date'=>$season->start_date,
                        'end_date'=>$season->end_date,
                        'league_guid' => $season->league_guid,
                        'is_current' => $season->is_current
                    ]);
                }
            }
        }
        Schema::table('scs_osdb_seasons', function($table)
        {
            $table->primary(['guid']);
        });
    }
    
    public function down()
    {
    }
}
