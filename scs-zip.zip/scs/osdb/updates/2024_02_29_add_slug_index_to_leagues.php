<?php
namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class AddSlugIndexToLeague extends Migration
{
    public function up()
    {
        Schema::table('scs_osdb_league', function ($table) {
            $table->index('slug');
        });
    }

    public function down()
    {
        Schema::table('scs_osdb_league', function ($table) {
            $table->dropIndex(['slug']);
        });
    }
}
