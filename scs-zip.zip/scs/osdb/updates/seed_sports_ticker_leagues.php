<?php namespace SCS\Osdb\Updates;

use SCS\Osdb\Models\Sport;
use Seeder;
use DB;
use October\Rain\Database\Updates\Migration;

class SeedSportTickerLeagues extends Migration
{
    public function up()
    {
        $sports = Sport::all();
        foreach ($sports as $i => $sport) {
            if (empty($sport->ticker_leagues)) {
                switch ($sport->slug) {
                    case 'baseball':
                        $sport->ticker_leagues = [ ['league' => 'MLB', 'slug' => 'mlb', 'ignore_seasons' => "0"]];
                        break;
                    case 'american-football':
                        $sport->ticker_leagues = [ ['league' => 'NFL', 'slug' => 'nfl', 'ignore_seasons' => "0"]];
                        break;
                    case 'basketball':
                        $sport->ticker_leagues = [ ['league' => 'NBA', 'slug' => 'nba', 'ignore_seasons' => "0"]];
                        break;
                    case 'hockey':
                        $sport->ticker_leagues = [ ['league' => 'NHL', 'slug' => 'nhl', 'ignore_seasons' => "1"]];
                        break;
                    case 'soccer':
                        $sport->ticker_leagues = [ ['league' => 'MLS', 'slug' => 'soccer', 'ignore_seasons' => "0"]];
                        break;
                }
                if (!empty($sport->ticker_leagues)) $sport->save();
            }
        }
    }

    public function down()
    {
    }
}
