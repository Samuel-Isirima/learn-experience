<?php namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableUpdateScsOsdbLeague2 extends Migration
{
    public function up()
    {
        Schema::table('scs_osdb_league', function($table)
        {
            $table->string('hero_series', 191)->nullable();
        });
    }

    public function down()
    {
        Schema::table('scs_osdb_league', function($table)
        {
            $table->dropColumn('hero_series');
        });
    }
}
