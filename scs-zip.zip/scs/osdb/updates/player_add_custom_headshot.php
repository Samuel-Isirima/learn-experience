<?php namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class PlayerAddCustomHeadshot extends Migration
{
    public function up()
    {
        Schema::table('scs_osdb_player', function ($table) {
            $table->string('custom_headshot', 1024)->nullable();
        });
    }

    public function down()
    {
        Schema::table('scs_osdb_player', function ($table) {
            $table->dropColumn('custom_headshot');
        });
    }
}
