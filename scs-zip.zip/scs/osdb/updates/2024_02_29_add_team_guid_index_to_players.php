<?php
namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class AddTeamGuidIndexToPlayers extends Migration
{
    public function up()
    {
        Schema::table('scs_osdb_player', function ($table) {
            $table->index('team_guid');
            $table->index('is_featured');
            $table->index('updated_at');
        });
    }

    public function down()
    {
        Schema::table('scs_osdb_player', function ($table) {
            $table->dropIndex(['team_guid']);
            $table->dropIndex(['is_featured']);
            $table->dropIndex(['updated_at']);
        });
    }
}
