<?php namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableUpdateScsOsdbTeam4 extends Migration
{
    public function up()
    {
        Schema::table('scs_osdb_team', function($table)
        {
            $table->text('endorsements')->nullable();
        });
    }
    
    public function down()
    {
        Schema::table('scs_osdb_team', function($table)
        {
            $table->dropColumn('endorsements');
        });
    }
}
