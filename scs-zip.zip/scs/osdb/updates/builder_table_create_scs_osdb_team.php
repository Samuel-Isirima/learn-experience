<?php namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateScsOsdbTeam extends Migration
{
    public function up()
    {
        Schema::create('scs_osdb_team', function ($table) {
            $table->engine = 'InnoDB';
            $table->string('guid');
            $table->string('name');
            $table->string('alias');
            $table->string('foundedby')->nullable();
            $table->text('metadata_firsts')->nullable();
            $table->text('social_links')->nullable();
            $table->string('league_guid')->nullable();
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
            $table->primary(['guid']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('scs_osdb_team');
    }
}
