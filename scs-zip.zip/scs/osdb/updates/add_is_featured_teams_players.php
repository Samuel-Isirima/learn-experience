<?php namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class AddIsFeaturedTeamsPlayers extends Migration
{
    public function up()
    {
        Schema::table('scs_osdb_team', function ($table) {
            $table->boolean('is_featured')->default(0);
        });
        Schema::table('scs_osdb_player', function ($table) {
            $table->boolean('is_featured')->default(0);
        });
    }

    public function down()
    {
        Schema::table('scs_osdb_team', function ($table) {
            $table->dropColumn('is_featured');
        });
        Schema::table('scs_osdb_player', function ($table) {
            $table->dropColumn('is_featured');
        });
    }
}
