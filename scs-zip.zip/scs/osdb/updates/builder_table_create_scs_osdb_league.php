<?php namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateScsOsdbLeague extends Migration
{
    public function up()
    {
        Schema::create('scs_osdb_league', function ($table) {
            $table->engine = 'InnoDB';
            $table->string('guid');
            $table->string('name');
            $table->string('alias');
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
            $table->string('sport_guid')->default('null');
            $table->primary(['guid']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('scs_osdb_league');
    }
}
