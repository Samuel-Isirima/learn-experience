<?php namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableCreateScsOsdbPlayer extends Migration
{
    public function up()
    {
        Schema::create('scs_osdb_player', function ($table) {
            $table->engine = 'InnoDB';
            $table->string('guid');
            $table->string('name');
            $table->string('nickname')->nullable();
            $table->string('alias');
            $table->text('bio')->nullable();
            $table->text('charities')->nullable();
            $table->text('contracts')->nullable();
            $table->text('business')->nullable();
            $table->text('endorsements')->nullable();
            $table->text('agent')->nullable();
            $table->text('contact')->nullable();
            $table->text('social_links')->nullable();
            $table->string('team_guid')->nullable();
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
            $table->primary(['guid']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('scs_osdb_player');
    }
}
