<?php namespace SCS\Osdb\Updates;

use Seeder;
use SCS\Osdb\Models\Sport;

class SeedSportTable2 extends Seeder
{
    public function run()
    {
        $sports = Sport::all()->toArray();
        $toAdd = [
            "NHL" => [ 'guid'=> '4d', 'name'=>"Hockey", 'slug' => "hockey", 'ticker_leagues' =>
                [["league" => "NHL","slug" => "nhl","ignore_seasons" => "1"]]
            ],
            "MLS" => [ 'guid'=> '5e', 'name'=>"Soccer", 'slug' => "soccer", 'ticker_leagues' =>
                [["league" =>"MLS","slug" => "soccer","ignore_seasons" => "0"]]
            ]
        ];
        foreach ($toAdd as $sport){
            $index = array_search($sport['slug'], array_column($sports, 'slug'));
            if ($index == false) {
                Sport::create($sport);
            }
        }
    }
}
