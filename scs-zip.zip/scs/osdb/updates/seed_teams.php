<?php namespace SCS\Osdb\Updates;

use Seeder;
use DB;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;

class SeedTeams extends Migration
{
    public function up()
    {
        $teamsArchive = 'scs_osdb_team.sql';

        $pathTeams = base_path() . '/plugins/scs/osdb/updates/' . $teamsArchive;
        $sqlTeams = file_get_contents($pathTeams);
        DB::unprepared($sqlTeams);
    }

    public function down()
    {
    }
}
