<?php namespace SCS\Osdb\Updates;

use Seeder;
use DB;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;
use SCS\Osdb\Models\Sport;
use SCS\Osdb\Models\League;
use SCS\Osdb\Models\Team;
use SCS\Osdb\Models\Player;

class SeedDefaultGuids extends Migration
{
    public function up()
    {
        Sport::upsert(
            ['guid' => '00', 'name' => 'n/a', 'slug' => 'no-sport'],
            ['guid', 'name', 'slug']
        );
        League::upsert(
            ['guid' => '00000000-0000-0000-0000-000000000000', 'name' => 'n/a', 'slug' => 'no-league', 'sport_guid' => '00'],
            ['guid', 'name', 'slug']
        );
        Team::upsert(
            ['guid' => '00000000-0000-0000-0000-000000000000', 'name' => 'n/a', 'slug' => 'no-team', 'league_guid' => '00000000-0000-0000-0000-000000000000'],
            ['guid', 'name', 'slug']
        );
        Player::upsert(
            ['guid' => '00000000-0000-0000-0000-000000000000', 'name' => 'n/a', 'slug' => 'no-player', 'team_guid' => '00000000-0000-0000-0000-000000000000'],
            ['guid', 'name', 'slug']
        );
    }

    public function down()
    {
        Sport::destroy(['00']);
        League::destroy(['00000000-0000-0000-0000-000000000000']);
        Team::destroy(['00000000-0000-0000-0000-000000000000']);
        Player::destroy(['00000000-0000-0000-0000-000000000000']);
    }
}
