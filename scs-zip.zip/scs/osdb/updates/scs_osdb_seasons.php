<?php namespace SCS\OSDB\Updates;

use Schema;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;

class CreateSeasonsTable extends Migration
{
    public function up()
    {
        Schema::create(
            'scs_osdb_seasons',
            function (Blueprint $table) {
                $table->engine = 'InnoDB';
                $table->string('guid');
                $table->timestamp('created_at')->nullable();
                $table->timestamp('updated_at')->nullable();
                $table->timestamp('deleted_at')->nullable();
                $table->boolean('is_current')->default(false);
                $table->integer('year')->default(2);
                $table->string('type', 128);
                $table->string('status', 128);
                $table->timestamp('start_date')->nullable();
                $table->timestamp('end_date')->nullable();
                $table->string('league_guid');
            }
        );
    }

    public function down()
    {
        Schema::dropIfExists('scs_osdb_seasons');
    }
}
