<?php namespace SCS\Osdb\Updates;

use Seeder;
use DB;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;

class AddLogSettings extends Migration
{
    public function up()
    {
        DB::table('system_settings')->updateOrInsert(
            [
                'item' => 'system_log_settings',
                'value' => '{"log_events":"1","log_requests":"1","log_theme":"0"}'
            ]
        );
    }

    public function down()
    {
    }
}
