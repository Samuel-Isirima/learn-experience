<?php namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableUpdateScsOsdbSport extends Migration
{
    public function up()
    {
        Schema::table('scs_osdb_sport', function($table)
        {
            $table->renameColumn('alias', 'slug');
        });
    }
    
    public function down()
    {
        Schema::table('scs_osdb_sport', function($table)
        {
            $table->renameColumn('slug', 'alias');
        });
    }
}
