<?php namespace SCS\Osdb\Updates;

use Seeder;
use SCS\Osdb\Models\Sport;

class SeedSportTable extends Seeder
{
    public function run()
    {
        Sport::create([ 'guid'=> '1a', 'name'=>"Baseball", 'alias' => "baseball"]);
        Sport::create([ 'guid'=> '2b', 'name'=>"American Football", 'alias' => "american-football"]);
        Sport::create([ 'guid'=> '3c', 'name'=>"Basketball", 'alias' => "basketball"]);
        Sport::create([ 'guid'=> '4d', 'name'=>"Hockey", 'alias' => "hockey"]);
        Sport::create([ 'guid'=> '5e', 'name'=>"Soccer", 'alias' => "soccer"]);
    }
}
