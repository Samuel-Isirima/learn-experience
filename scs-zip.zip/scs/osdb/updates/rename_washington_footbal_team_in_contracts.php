<?php namespace SCS\OSDB\Updates;

use Schema;
use Db;
use October\Rain\Database\Updates\Seeder;
use SCS\Osdb\Models\Player;

class RenameWashingtonFootbalTeamInContracts extends Seeder
{
    public function run()
    {
        /*do {
            $sql = "
                update scs_osdb_player p
                inner join json_table(
                    p.contracts,
                    '$[*]' columns(
                    rowid FOR ORDINALITY,
                    team text PATH '$.team',
                    team_slug text PATH '$.team_slug',
                    team_logo text PATH '$.team_logo'
                    )
                ) c on c.team = 'Washington Football Team'
                set p.contracts = JSON_REPLACE(p.contracts, CONCAT('$[', c.rowid - 1, '].team_slug'),
                    'nfl\/washington-commanders');
                    
                update scs_osdb_player p
                inner join json_table(
                    p.contracts,
                    '$[*]' columns(
                    rowid FOR ORDINALITY,
                    team text PATH '$.team',
                    team_slug text PATH '$.team_slug',
                    team_logo text PATH '$.team_logo'
                    )
                ) c on c.team = 'Washington Football Team'
                set p.contracts = JSON_REPLACE(p.contracts, CONCAT('$[', c.rowid - 1, '].team_logo'),
                    'logos\/nfl\/washington-commanders\/logo-dark.svg');
                    
                update scs_osdb_player p
                inner join json_table(
                    p.contracts,
                    '$[*]' columns(
                    rowid FOR ORDINALITY,
                    team text PATH '$.team',
                    team_slug text PATH '$.team_slug',
                    team_logo text PATH '$.team_logo'
                    )
                ) c on c.team = 'Washington Football Team'
                set p.contracts = JSON_REPLACE(p.contracts, CONCAT('$[', c.rowid - 1, '].team'),
                    'Washington Commanders')     
            ";

            DB::unprepared($sql);
            $cnt = Db::select("select count(*) as c from scs_osdb_player p where contracts like '%Washington Football Team%';");
        } while ($cnt[0]->c > 0);*/
    }
}
