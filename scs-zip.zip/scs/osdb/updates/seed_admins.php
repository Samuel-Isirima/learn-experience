<?php namespace SCS\Osdb\Updates;

use Seeder;
use DB;
use Backend\Models\User;
use Backend\Models\UserRole;
use Backend\Models\UserGroup;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;
use BackendAuth;

class SeedAdmins extends Migration
{
    public $adminSCSemail = 'support@wearescs.com';
    public $adminDevLead = 'rcorbett@wearescs.com';

    public function up()
    {
        // *** create proper groups ***
        $this->createAdminRolesGroups();
        // *** delete old admin users ***
        // DB::table('backend_users')->delete();
        // *** create admin users ***
        $this->createAdminUsers();

        $adminUsers = User::all();
        foreach ($adminUsers as $i => $admin) {
            $admin->addGroup(UserGroup::where('code', 'owners')->first());
            $admin->is_superuser = true;
            $admin->role_id = UserRole::where('code', 'owner')->first()->id;
            $admin->save();
        }
    }

    public function down()
    {
        //DB::table('backend_users')->delete();
    }

    private function createAdminRolesGroups()
    {
        $this->rolePublisher = UserRole::updateOrCreate([
            'name' => 'Publisher',
            'code' => UserRole::CODE_PUBLISHER,
            'description' => 'Site editor with access to publishing tools.',
        ]);

        $this->roleDeveloper = UserRole::updateOrCreate([
            'name' => 'Developer',
            'code' => UserRole::CODE_DEVELOPER,
            'description' =>
                'Site administrator with access to developer tools.',
        ]);

        $this->roleOwner = UserRole::updateOrCreate([
            'name' => 'Owner',
            'code' => 'owner',
            'description' => 'Site owner with full access to developer tools.',
        ]);

        $this->groupOwner = UserGroup::updateOrCreate([
            'name' => 'Owners',
            'code' => UserGroup::CODE_OWNERS,
            'description' => 'Default group for website owners.',
            'is_new_user_default' => false,
        ]);
    }

    private function createAdminUsers()
    {
        $adminUserSupport = BackendAuth::findUserByLogin('osdb_master');
        if (null === $adminUserSupport) {
            $adminUserSupport = BackendAuth::register(
                [
                'login' => 'osdb_master',
                'email' => $this->adminSCSemail,
                'password' => 'SCS5upp0rt!99',
                'password_confirmation' => 'SCS5upp0rt!99',
                'first_name' => 'SCS',
                'last_name' => 'Support',
                'permissions' => ['superuser' => 1],
            ],
                true
            );
        }
        $adminUserRWC = BackendAuth::findUserByLogin('rcorbett@wearescs.com');
        if (null === $adminUserRWC) {
            $adminUserRWC = BackendAuth::register(
                [
                'login' => $this->adminDevLead,
                'email' => $this->adminDevLead,
                'password' => 'pXm86JMVai2zSp7ztuAKJsGHgj5xjhGA',
                'password_confirmation' => 'pXm86JMVai2zSp7ztuAKJsGHgj5xjhGA',
                'first_name' => 'Robb',
                'last_name' => 'Corbett',
                'permissions' => ['superuser' => 1],
            ],
                true
            );
        }
        $adminUserRR = BackendAuth::findUserByLogin('ryan@osdbsports.com');
        if (null === $adminUserRR) {
            $adminUserRR = BackendAuth::register(
                [
                'login' => 'ryan@osdbsports.com',
                'email' => 'ryan@osdbsports.com',
                'password' => 'pleaseCreateNewPassword!',
                'password_confirmation' => 'pleaseCreateNewPassword!',
                'first_name' => 'Ryan',
                'last_name' => 'Rottman',
                'permissions' => ['superuser' => 1],
            ],
                true
            );
        }
        $adminUserMG = BackendAuth::findUserByLogin('michael@osdbsports.com');
        if (null === $adminUserMG) {
            $adminUserMG = BackendAuth::register(
                [
                'login' => 'michael@osdbsports.com',
                'email' => 'michael@osdbsports.com',
                'password' => 'pleaseCreateNewPassword!',
                'password_confirmation' => 'pleaseCreateNewPassword!',
                'first_name' => 'Michael',
                'last_name' => 'Goldman',
                'permissions' => ['superuser' => 1],
            ],
                true
            );
        }
        $adminUserAB = BackendAuth::findUserByLogin('adrianbrown626@gmail.com');
        if (null === $adminUserAB) {
            $adminUserAB = BackendAuth::register(
                [
                'login' => 'adrianbrown626@gmail.com',
                'email' => 'adrianbrown626@gmail.com',
                'password' => 'pleaseCreateNewPassword!',
                'password_confirmation' => 'pleaseCreateNewPassword!',
                'first_name' => 'Adrian',
                'last_name' => 'Brown',
                'permissions' => ['superuser' => 1],
            ],
                true
            );
        }
        $adminUserPF = BackendAuth::findUserByLogin('philfaunt24@gmail.com');
        if (null === $adminUserPF) {
            $adminUserPF = BackendAuth::register(
                [
                    'login' => 'philfaunt24@gmail.com',
                    'email' => 'philfaunt24@gmail.com',
                    'password' => 'pleaseCreateNewPassword!',
                    'password_confirmation' => 'pleaseCreateNewPassword!',
                    'first_name' => 'Phil',
                    'last_name' => 'Faunt',
                    'permissions' => ['superuser' => 1],
                ],
                true
            );
        }
    }
}
