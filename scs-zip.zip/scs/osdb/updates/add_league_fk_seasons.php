<?php namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class AddLeagueGuidToSeasons extends Migration
{
    public function up()
    {

        Schema::table('scs_osdb_seasons', function ($table) {
            $table->foreign('league_guid')->references('guid')->on('scs_osdb_league');
        });
    }

    public function down()
    {
        Schema::table('scs_osdb_seasons', function ($table) {
            $table->dropForeign('scs_osdb_seasons_league_guid_foreign');
        });
    }
}
