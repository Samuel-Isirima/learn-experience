<?php
namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;
use SCS\Osdb\Models\Player;
use SCS\Osdb\Traits\SlugTrait;

use Illuminate\Support\Str;


class ChangeSlugPlayers extends Migration
{

    protected $slugArray = [];

    public function up()
    {
        // Chunk size 
        $chunkSize = 5000;


        // Process players in chunks
        Player::select('guid', 'name', 'slug', 'old_slug')
            ->chunk($chunkSize, function ($players) {

                foreach ($players as $player) {

                    echo '.'; // to track progress
    
                    // Generate new slug
                    $slug = $this->generateUniqueSlug($player->name);

                    // Update slug
    
                    // Prepare the update data
                    $updateData = [
                        'old_slug' => $player->slug,
                        'slug' => $slug
                    ];

                    try {
                        // Update the player record
                        Player::where('guid', $player->guid)->update($updateData);
                    } catch (\Throwable $th) {

                        echo json_encode($player);
                        throw $th;
                    }


                }
            });
    }

    public function down()
    {

        // Chunk size 
        $chunkSize = 5000;

        // Process players in chunks
        Player::select('guid', 'name', 'slug', 'old_slug')
            ->chunk($chunkSize, function ($players) {
                foreach ($players as $player) {
                    // return old slug if it exists
                    if ($player->old_slug) {

                        $updateData = [
                            'slug' => $player->slug,
                        ];

                        // Update the player record
                        Player::where('guid', $player->guid)->update($updateData);
                    }
                }
            });
    }



    public function generateUniqueSlug($name)
    {
        // Generate initial slug


        // Remove all non-alphanumeric characters (excluding spaces)
        $cleanName = preg_replace('/[^A-Za-z0-9\s]/', '', $name);

        $baseSlug = Str::slug(strtolower($cleanName));
        $slug = $baseSlug;

        // Check if slug already exists
        if (!in_array($slug, $this->slugArray)) {
            $this->slugArray[] = $slug;
            return $slug;
        }

        // If slug already exists, append numerical suffix
        $suffix = 2;
        $slug = $baseSlug . '-' . $suffix;
        while (in_array($slug, $this->slugArray)) {
            $slug = $baseSlug . '-' . $suffix;
            $suffix++;
        }
        $this->slugArray[] = $slug;
        return $slug;
    }
}
