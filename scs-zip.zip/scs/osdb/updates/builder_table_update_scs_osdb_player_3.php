<?php namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableUpdateScsOsdbPlayer3 extends Migration
{
    public function up()
    {
        Schema::table('scs_osdb_player', function($table)
        {
            $table->boolean('is_verified')->default(0);
        });
    }
    
    public function down()
    {
        Schema::table('scs_osdb_player', function($table)
        {
            $table->dropColumn('is_verified');
        });
    }
}
