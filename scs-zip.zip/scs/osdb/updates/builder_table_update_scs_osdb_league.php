<?php namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableUpdateScsOsdbLeague extends Migration
{
    public function up()
    {
        Schema::table('scs_osdb_league', function($table)
        {
            $table->renameColumn('alias', 'slug');
        });
    }
    
    public function down()
    {
        Schema::table('scs_osdb_league', function($table)
        {
            $table->renameColumn('slug', 'alias');
        });
    }
}
