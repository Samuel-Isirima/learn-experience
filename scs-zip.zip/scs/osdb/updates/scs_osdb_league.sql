-- --------------------------------------------------------
-- Host:                         new-stage-osdb.cjq2enqmzb1q.us-west-2.rds.amazonaws.com
-- Server version:               8.0.20 - Source distribution
-- Server OS:                    Linux
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table staging_cms.scs_osdb_league
CREATE TABLE IF NOT EXISTS `scs_osdb_league` (
  `guid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `sport_guid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'null',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table staging_cms.scs_osdb_league: ~4 rows (approximately)
/*!40000 ALTER TABLE `scs_osdb_league` DISABLE KEYS */;
REPLACE INTO `scs_osdb_league` (`guid`, `name`, `slug`, `created_at`, `updated_at`, `sport_guid`) VALUES
	('00000000-0000-0000-0000-000000000000', 'n/a', 'no-league', '2021-02-17 15:54:05', '2021-02-17 15:54:05', '00'),
	('2fa448bc-fc17-4d3d-be03-e60e080fdc26', 'MLB', 'mlb', '2021-02-17 16:00:46', '2021-02-17 16:00:46', '1a'),
	('3c6d318a-6164-4290-9bbc-bf9bb21cc4b8', 'NFL', 'nfl', '2021-02-17 16:00:46', '2021-02-17 16:00:46', '2b'),
	('4353138d-4c22-4396-95d8-5f587d2df25c', 'NBA', 'nba', '2021-02-17 16:00:46', '2021-02-17 16:00:46', '3c');
/*!40000 ALTER TABLE `scs_osdb_league` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
