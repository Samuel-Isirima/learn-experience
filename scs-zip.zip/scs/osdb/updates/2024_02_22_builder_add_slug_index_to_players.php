<?php
namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class AddSlugIndexToPlayers extends Migration
{
    public function up()
    {
        Schema::table('scs_osdb_player', function ($table) {
            $table->string('old_slug')->nullable();
            $table->unique('slug');
        });
    }

    public function down()
    {
        Schema::table('scs_osdb_player', function ($table) {
            $table->dropColumn('old_slug');
            $table->dropUnique('scs_osdb_player_slug_unique');
        });
    }
}
