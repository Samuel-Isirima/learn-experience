-- --------------------------------------------------------
-- Host:                         new-stage-osdb.cjq2enqmzb1q.us-west-2.rds.amazonaws.com
-- Server version:               8.0.20 - Source distribution
-- Server OS:                    Linux
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table staging_cms.scs_osdb_sport
CREATE TABLE IF NOT EXISTS `scs_osdb_sport` (
  `guid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table staging_cms.scs_osdb_sport: ~4 rows (approximately)
/*!40000 ALTER TABLE `scs_osdb_sport` DISABLE KEYS */;
REPLACE INTO `scs_osdb_sport` (`guid`, `name`, `created_at`, `updated_at`, `slug`) VALUES
	('00', 'n/a', '2021-02-17 15:54:05', '2021-02-17 15:54:05', 'no-sport'),
	('1a', 'Baseball', '2021-02-17 15:54:04', '2021-02-17 15:54:04', 'baseball'),
	('2b', 'American Football', '2021-02-17 15:54:04', '2021-02-17 15:54:04', 'american-football'),
	('3c', 'Basketball', '2021-02-17 15:54:04', '2021-02-17 15:54:04', 'basketball');
/*!40000 ALTER TABLE `scs_osdb_sport` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
