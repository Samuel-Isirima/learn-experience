<?php namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class AddSportsTickerLeagues extends Migration
{
    public function up()
    {
        Schema::table('scs_osdb_sport', function($table)
        {
            $table->text('ticker_leagues')->nullable();
        });
    }

    public function down()
    {
        Schema::table('scs_osdb_sport', function($table)
        {
            $table->dropColumn('ticker_leagues');
        });
    }
}
