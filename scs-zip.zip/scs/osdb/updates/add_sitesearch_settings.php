<?php namespace SCS\Osdb\Updates;

use Seeder;
use DB;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;

class AddSitesearchSettings extends Migration
{
    public function up()
    {
        DB::table('system_settings')->updateOrInsert(
            [
                'item' => 'offline_sitesearch_settings',
                'value' => '{"mark_results":"1","log_queries":"0","excerpt_length":"250","log_keep_days":365,"rainlab_blog_enabled":"1","rainlab_blog_label":"Editorials","rainlab_blog_page":"editorial\\/editorialArticle","rainlab_pages_enabled":"1","rainlab_pages_label":"Page","indikator_news_enabled":"1","indikator_news_label":"News","indikator_news_posturl":"\\/news","octoshop_products_enabled":"1","octoshop_products_label":"","octoshop_products_itemurl":"\\/product","snipcartshop_products_enabled":"1","snipcartshop_products_label":"","jiri_jkshop_enabled":"1","jiri_jkshop_label":"","jiri_jkshop_itemurl":"\\/product","radiantweb_problog_enabled":"1","radiantweb_problog_label":"Blog","arrizalamin_portfolio_enabled":"1","arrizalamin_portfolio_label":"Portfolio","arrizalamin_portfolio_url":"\\/portfolio\\/project","vojtasvoboda_brands_enabled":"1","vojtasvoboda_brands_label":"Brands","vojtasvoboda_brands_url":"\\/brand","responsiv_showcase_enabled":"1","responsiv_showcase_label":"Showcase","responsiv_showcase_url":"\\/showcase\\/project","graker_photoalbums_enabled":"1","graker_photoalbums_label":"PhotoAlbums","graker_photoalbums_album_page":"404","graker_photoalbums_photo_page":"404","cms_pages_enabled":"1","cms_pages_label":"Page"}'
            ]
        );
    }

    public function down()
    {
    }
}
