<?php namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableUpdateScsOsdbPlayer2 extends Migration
{
    public function up()
    {
        Schema::table('scs_osdb_player', function ($table) {
            $table->text('agent')->nullable()->unsigned(false)->default(null)->change();
        });
    }

    public function down()
    {
        // Schema::table('scs_osdb_player', function($table)
        // {
        //     $table->string('agent', 191)->nullable()->unsigned(false)->default(null)->change();
        // });
    }
}
