<?php namespace SCS\Osdb\Updates;

use Seeder;
use DB;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;

class SeedPlayers extends Migration
{
    public function up()
    {
        $playerArchive = 'scs_osdb_player.sql';

        $pathPlayer = base_path() . '/plugins/scs/osdb/updates/' . $playerArchive;
        $sqlPlayer = file_get_contents($pathPlayer);
        DB::unprepared($sqlPlayer);
    }

    public function down()
    {
    }
}
