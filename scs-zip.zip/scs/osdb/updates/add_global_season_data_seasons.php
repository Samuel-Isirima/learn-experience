<?php namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class AddGlobalSeasonsDataToSeasons extends Migration
{
    public function up()
    {

        Schema::table('scs_osdb_seasons', function ($table) {
            $table->string('season_id', 128)->nullable();
            $table->string('competition_id', 128)->nullable();
        });
    }

    public function down()
    {
        Schema::table('scs_osdb_seasons', function ($table) {
            $table->dropColumn('season_id');
            $table->dropColumn('competition_id');
        });
    }
}
