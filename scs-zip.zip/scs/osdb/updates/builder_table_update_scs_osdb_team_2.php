<?php namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableUpdateScsOsdbTeam2 extends Migration
{
    public function up()
    {
        Schema::table('scs_osdb_team', function($table)
        {
            $table->text('executive_team')->nullable();
            $table->text('history')->nullable();
        });
    }
    
    public function down()
    {
        Schema::table('scs_osdb_team', function($table)
        {
            $table->dropColumn('executive_team');
            $table->dropColumn('history');
        });
    }
}
