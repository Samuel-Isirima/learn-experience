<?php namespace SCS\Osdb\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class AwardsTeamAddTitlesCount extends Migration
{
    public function up()
    {
        Schema::table('scs_osdb_team', function($table)
        {
            $table->integer('awarded_division_title_count')->nullable();
            $table->integer('awarded_conference_title_count')->nullable();
        });
    }

    public function down()
    {
        Schema::table('scs_osdb_team', function($table)
        {
            $table->dropColumn('awarded_division_title_count');
            $table->dropColumn('awarded_conference_title_count');
        });
    }
}
