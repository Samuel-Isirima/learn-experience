<?php namespace SCS\Osdb\Controllers;

use Backend\Classes\Controller;
use BackendMenu;
use Cms\Classes\Page;
use Config;
use Flash;
use Illuminate\Support\Facades\DB;
use SCS\Osdb\Classes\ES\Leagues;
use SCS\Osdb\Classes\ES\Players;
use SCS\Osdb\Classes\Services\MisoSearchService;
use SCS\Osdb\Classes\Util\SlugUtil;
use SCS\Osdb\Models\League;
use SCS\Osdb\Models\League as LeagueModel;
use SCS\Osdb\Models\Sport;
use SCS\Osdb\Models\Team;
use SCS\Osdb\Models\Team as TeamModel;
use SCS\Osdb\Models\Sport as SportModel;
use SCS\Osdb\Models\Player as PlayerModel;
use SCS\Osdb\Controllers\Seo as SeoController;


class Player extends Controller
{

    public $requiredPermissions = ['scs.osdb.*'];

    public $implement = [        'Backend\Behaviors\ListController',        'Backend\Behaviors\FormController', 'Backend.Behaviors.ImportExportController'    ];

    public $listConfig = 'config_list.yaml';
    public $formConfig = 'config_form.yaml';
    public $importExportConfig = 'config_import_export.yaml';
    public $player = null;

    public function __construct()
    {
        parent::__construct();
        BackendMenu::setContext('SCS.Osdb', 'main-menu-osdb', 'side-menu-player');
    }

    public static function getBornThisWeek()
    {
        $players = Players::bornThisWeek();
        $dbPlayers = PlayerModel::whereIn('guid', array_column($players, 'id'))->select('guid', 'custom_headshot', 'slug')->get()->all();
        $players = Leagues::addCustomHeadshotUrl($players, $dbPlayers);
        return $players;
    }

    public static function getBornToday()
    {
        $players = Players::bornToday();
        $dbPlayers = PlayerModel::whereIn('guid', array_column($players, 'id'))
            ->where('is_featured', true)
            ->select('guid', 'custom_headshot', 'slug')
            ->get()
            ->all();
        $players = Leagues::addCustomHeadshotUrl($players, $dbPlayers);
        return $players;
    }

    public function update($recordId, $context = null)
    {
        $this->addJs('/plugins/scs/osdb/controllers/assets/js/cloudflareUtil.js');

        $model = $this->formFindModelObject($recordId);
        $model->extendWithESData();
        $this->pageTitle = $model['name'];
        $this->player = $model;
        $this->initForm($model);
    }

    public static function onStartPage($page)
    {
        $_playerSlug = $page->param('slug');
        $leagueId = Players::getPlayerLeague($_playerSlug);
        $_thisPlayerLeague = LeagueModel::where('guid', '=', $leagueId);
        if (isset($_thisPlayerLeague)) {
            if (empty($_thisPlayerLeague->slug)) {
                \Redirect::to('/404')->with('message', 'Cannot find that league');
            }
            $page['playerLeague'] = $_thisPlayerLeague;
        }
    }

    public static function onEndPage($page, $subtitle = null)
    {
        try {
            // it could be ES player, missed in DB - trying to add
            if (empty($page['record'])) {
                try {
                // trying to add record to DB and then get it
                $esId = $page->controller->vars['this']['param']['slug'];
                $esPlayer = Players::getById($esId);
                if ($esPlayer) {
                    $teamId = isset($esPlayer['team']) ? $esPlayer['team']['id'] : null;
                    $playerName = isset($esPlayer['full_name']) ? $esPlayer['full_name'] : null;
                    $teamDbIds = Db::select("select guid from ". Team::TABLE);
                    $teamIds = array_map(function ($item) {
                        if ($item) {
                            return $item->guid;
                        }
                    }, $teamDbIds);
                    $dbLeagues = Db::table(League::TABLE)
                        ->join(Sport::TABLE, League::TABLE.'.sport_guid', '=', Sport::TABLE.'.guid')
                        ->select(League::TABLE.'.*', Sport::TABLE.'.name as sport_name', Sport::TABLE.'.slug as sport_slug')
                        ->get()->all();
                    if (!empty($playerName) && (empty($teamId) || !empty($teamId) && (in_array($teamId, $teamIds))) ){
                        // TODO: use DB directly to avoid afterSave call
                        \SCS\Osdb\Models\Player::create([
                            'guid'=>$esId,
                            'name'=>$playerName,
                            'team_guid'=> $teamId,
                                'slug' => SlugUtil::generatePlayerSlug($playerName),
                        ]);
                        // add item to Miso list
                        $dbPlayer = \SCS\Osdb\Models\Player::where('guid', $esId)->first();
                        $page['record'] = $dbPlayer;

                        $v = $esPlayer['league']['id'];
                        $dbLeague = $entry = current(array_filter($dbLeagues, function($e) use($v){ return $e->guid == $v; }));
                        if ($dbLeague !== false) {
                            $misoItems[] = \SCS\Osdb\Models\Player::constructProductForMiso($dbLeague, $dbPlayer, $esPlayer);
                            // send update to Miso
                            $errors = MisoSearchService::instance()->upload("products", $misoItems);
                        }
                    }
                }
                } catch (\Exception $ex) {
                    \Log::error('~~ Error during adding Player to DB: '. $ex->getMessage() . " [".$ex->getTraceAsString()."]");
                }
            }

            $player = $page['record'];
            if (isset($player)) {
                $page['record']->extendWithESData();
                $page['playerSlug'] = $player->slug;
                $page['leagueSlug'] = $player->_league;
                $page['widgetPlayerId'] = $player->_widget_player_id;
                if (!empty($page['record']->team)) {
                    $page['teamName'] = $player->team->name;
                    $page['teamSlug'] = $player->team->slug;
                    $page['widgetTeamId'] = $player->_team_id;
                }
                if (empty($page['teamName']) && !empty($page['record']['contracts'])) {
                    foreach ($page['record']['contracts'] as $contract) {
                        if ($contract['active'] == 1) {
                            $page['teamName'] = $contract['team'];
                            break;
                        }
                    }   
                }
                if (!empty($page['record']['_position'])) {
                    $page['record']->playerPositionLabel = SeoController::getPositionLabel($page['record']['_position'], $player->_league);
                }

                $page['record']['url'] = $page->currentPageUrl();
                $page['share_links'] = SeoController::getShareLinks($page['record'], 'player', ['twitterExcerpt' => false]);
                $page['jsonld'] = SeoController::getJsonLD($page, 'player');


            }
        } catch (\Exception $e) {
        }

        $record = $page['record'];
        $record['url'] = $page->currentPageUrl();
        $page['record'] = $record;

        $liveUrl = 'https://www.osdbsports.com';

        $page->page->title = $page->page->meta_title = "OSDB - {$page['record']->name} - {$page->teamName}";
        if ($subtitle) {
            $page->page->title .= " - $subtitle";
        }

        if (!empty($page['record']->bio['biography'])) {
            $page->page->meta_description  =  \SCS\Osdb\Controllers\Seo::getExcerpt($page['record']->bio['biography'], 255, '...', false);
        } else {
            $page->page->meta_description = "{$page['record']->name} - {$page->teamName}";
            if(!empty($page['record']['playerPositionLabel'])){
                $page->page->meta_description .= ' (' . $page['record']['playerPositionLabel'] . ')';
            }
        }

        if ($page['record']['custom_headshot']) {
            $page->page->meta_image_url = $liveUrl . \SCS\Osdb\Controllers\Resizer::resize(url(Config::get('cms.storage.media.path')).$page['record']['custom_headshot'], 280);
        } elseif ($page['record']['_headshot_high_res']) {
            $page->page->meta_image_url = $liveUrl . \SCS\Osdb\Controllers\Resizer::resize($page['record']['_headshot_high_res'], 280);
        } else {
            $page->page->meta_image_url = null;
        }

        $page->page->jsonld = $page->jsonld;
        $page->page->share_links = $page->share_links;

        if ($page['record']) {
            \SCS\Osdb\Models\Player::sendPageViewToMiso(
                $page['record']['guid'],
                $page['record']['team_guid'],
                request()->header('referer'),
                $page->page->title
            );
        }
    }

    public function onUnflagFeatured()
    {
        $featuredPlayers = \SCS\Osdb\Models\Player::where('is_featured', 1)->get();
        if (null === $featuredPlayers || count($featuredPlayers) <= 0) {
            Flash::error('no players set to featured!');
            return null;
        }
        $unfeaturedPlayers = "";
        foreach ($featuredPlayers as $i => $player) {
            $player->is_featured = false;
            $player->save();
            $unfeaturedPlayers = $unfeaturedPlayers . $player->name . ", ";
        }
        Flash::success('players unfeatured: '.$unfeaturedPlayers);
    }

    public function onProcessTeamLogos()
    {
        \Log::info('~~ Player->onProcessTeamLogos - STARTS');
        $mediaLib = \System\Classes\MediaLibrary::instance();
        $players = Db::table(PlayerModel::TABLE)
            ->join(TeamModel::TABLE, PlayerModel::TABLE.'.team_guid', '=', TeamModel::TABLE.'.guid')
            ->select(PlayerModel::TABLE.'.*', TeamModel::TABLE.'.league_guid as league_guid', TeamModel::TABLE.'.slug as team_slug')
            ->get()->all();
        $dbTeams = Db::table(TeamModel::TABLE)->get()->all();
        $leagues = Db::table(LeagueModel::TABLE)
            ->join(SportModel::TABLE, LeagueModel::TABLE.'.sport_guid', '=', SportModel::TABLE.'.guid')
            ->select(LeagueModel::TABLE.'.*', SportModel::TABLE.'.name as sport_name', SportModel::TABLE.'.slug as sport_slug')
            ->get()->all();
        foreach ($players as $player) {
            try {
                $v = $player->league_guid;
                $league = $entry = current(
                    array_filter(
                        $leagues, function ($e) use ($v) {
                            return $e->guid == $v;
                        }
                    )
                );
                if ($league === false) {
                    \Log::warning('~~ Player->onProcessTeamLogos - League not found: '.$league);
                    continue;
                }
                if (!empty($player->contracts)) {
                    $contracts = json_decode($player->contracts);
                    if (!empty($contracts)) {
                        $changed = false;
                        // pre-process - split contracts with "&" in team name
                        do {
                            $teams = [];
                            $index = -1;
                            for ($i = 0; $i < count($contracts); $i++) {
                                $contract = $contracts[$i];
                                if (!empty($contract->team && strpos($contract->team, '&') !== false)) {
                                    $teams = explode('&', $contract->team);
                                    $index = $i;
                                    break;
                                }
                            }
                            if ($index != -1) {
                                $changed = true;
                                $contracts[$index]->team = trim($teams[0]);
                                for ($i = 1; $i < count($teams); $i++) {
                                    $contract = clone $contracts[$index];
                                    $contract->team = trim($teams[$i]);
                                    array_splice($contracts, $index + $i, 0, [$contract]);
                                }
                            }
                        } while ($index != -1);
                        // set up team logo and team slug
                        foreach ($contracts as &$contract) {
                            if (!empty($contract->team)) {
                                $team = strtolower($contract->team);
                                $slug = str_slug($team);
                                $dbTeam = $entry = current(
                                    array_filter(
                                        $dbTeams, function ($e) use ($slug) {
                                            return $e->slug == $slug;
                                        }
                                    )
                                );
                                if ($dbTeam !== false) {
                                    // existing team
                                    if (empty($contract->team_logo)) {
                                        $logoUrl = '/logos/' . $league->slug . '/' . $slug . '/logo-dark.svg';
                                        if ($mediaLib->exists($logoUrl)) {
                                            $contract->team_logo = $logoUrl;
                                            $changed = true;
                                        } else {
                                            \Log::error('~~ Player->onProcessTeamLogos NO team logo in MediaLibrary for player='. $player->guid.', team='.$slug);
                                        }
                                    }
                                    if (empty($contract->team_slug)) {
                                        $contract->team_slug = $league->slug . '/' . $slug;
                                        $changed = true;
                                    }
                                } else {
                                    \Log::info('~~ Player->onProcessTeamLogos NO DB Team for player='. $player->guid.', team='.$slug);
                                    // old team logo
                                    $logoUrl = '/old-logos/' . $league->slug . '/logo-' . $slug . '-dark.svg';
                                    if (empty($contract->team_logo)) {
                                        if ($mediaLib->exists($logoUrl)) {
                                            $contract->team_logo = $logoUrl;
                                            $changed = true;
                                        }
                                    }
                                }
                            }
                        }

                        if ($changed) {
                            PlayerModel::where('guid', $player->guid)
                                ->update(
                                    [
                                    'contracts' => json_encode($contracts)]
                                );
                        }
                    }
                }
            } catch (\Exception $ex){
                \Log::error('~~ Player->onProcessTeamLogos EXCEPTION for player='. $player->guid.':'. " [".$ex->getTraceAsString()."]");
            }
        }
        \Log::info('~~ Player->onProcessTeamLogos - ENDS');
        Flash::success('Players contracts processed');
    }

    public static function formatHeight($inches)
    {
        if ($inches && intval($inches) > 0) {
            $feet = floor($inches / 12);
            $inches = $inches % 12;
            return "$feet'$inches\"";
        }
        return "--";
    }

    public static function formatWeight($lbs)
    {
        if ($lbs && intval($lbs) > 0) {
            return "$lbs";
        }
        return "--";
    }

    public static function formatBirthdate($birthdate)
    {
        if ($birthdate) {
            try {
                return strftime("%B %e, %Y", (new \DateTime($birthdate))->getTimestamp());
            } catch (\Exception $e) {
            }
        }
        return "";
    }

    public static function encodeName($name)
    {
        if (!empty($name)) {
            $name = preg_replace('/[^\s\w\-]/', '', $name);
            $name = preg_replace('/\s+/', '-', $name);
            $name = preg_replace('/--+/', '-', $name);
            $name = preg_replace('/^-+/', '', $name);
            $name = preg_replace('/-+$/', '', $name);
            $name = strtolower($name);
        }
        return $name;
    }

    public function listExtendQuery($query)
    {
        $query->addSelect(League::TABLE . '.name as league_name');

        $query->leftJoin(Team::TABLE, Team::TABLE . '.guid', '=', \SCS\Osdb\Models\Player::TABLE . '.team_guid');
        $query->leftJoin(League::TABLE, League::TABLE . '.guid', '=', Team::TABLE . '.league_guid');
    }


    // redirects players old url to the new url
    // e.g /nfl/players/devin-funchess/7f5f2a81-ac40-420c-9421-5b9e2a21faf8 to /nfl/players/devin-funchess
    public function redirectProfileToSlug($leagueSlug, $playerName, $guid)
    {

        $slug = $playerName; // old url playerName is same as slug for many players.

        // get the player's slug from db
        $player = PlayerModel::find($guid, ['slug']);

        if ($player) {
            $slug = $player->slug;
        }


        $url = Page::url('player', [
            'leagueSlug' => $leagueSlug,
            'playerName' => $playerName,
            'slug' => $slug
        ]);

        // redirect to the new url
        return redirect()->to($url, 301);
    }


    // redirects players old url to the new url
    // e.g /nfl/players/devin-funchess/biography/7f5f2a81-ac40-420c-9421-5b9e2a21faf8 to /nfl/players/devin-funchess/biography
    public function redirectDetailsToSlug($leagueSlug, $playerName, $detailsType, $guid)
    {

        $slug = $playerName; // old url playerName is same as slug for many players.

        // get the player's slug from db
        $player = PlayerModel::find($guid, ['slug']);

        if ($player) {
            $slug = $player->slug;
        }


        $profileUrl = Page::url('player', [
            'leagueSlug' => $leagueSlug,
            'playerName' => $playerName,
            'slug' => $slug
        ]);

        $url = $profileUrl . '/' . $detailsType;

        // redirect to the new url
        return redirect()->to($url, 301);
    }
}
