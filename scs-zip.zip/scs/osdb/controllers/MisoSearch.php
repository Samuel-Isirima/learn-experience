<?php namespace SCS\Osdb\Controllers;

use Backend\Classes\Controller;
use Illuminate\Support\Facades\DB;
use Model;
use Flash;
use Artisan;
use SCS\Osdb\Classes\Services\ElasticsearchService;
use SCS\Osdb\Classes\ES\Teams;
use SCS\Osdb\Classes\ES\Leagues;
use SCS\Osdb\Classes\ES\Players;
use SCS\Osdb\Classes\ES\Seasons;
use SCS\Osdb\Models\Sport;
use SCS\Osdb\Models\Team;
use SCS\Osdb\Models\League;
use SCS\Osdb\Models\Player;
use SCS\Osdb\Models\Season;

class MisoSearch extends Controller
{

    public $requiredPermissions = ['scs.osdb.*'];

    public function index()
    {
        $this->fillLeagues();
    }

    public function fillLeagues()
    {
        $leagues = Leagues::getLeagues();
        $result = [];
        foreach ($leagues as $league){
            $result[$league['id']] = $league['alias'];
        }
        $this->vars['leagues'] = $result;
    }

    public function onUploadLeagues()
    {
        League::uploadToMisoSearch(true);
    }

    public function onUploadSeasons()
    {
        $league = post('league');
        Season::uploadToMisoSearch(true, $league);
    }

    public function onUploadTeams()
    {
        $league = post('league');
        Team::uploadToMisoSearch(true, $league);
    }

    public function onUploadPlayers()
    {
        $league = post('league');
        Player::uploadToMisoSearch(true, $league);
    }
}
