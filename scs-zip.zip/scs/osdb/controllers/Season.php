<?php namespace SCS\Osdb\Controllers;

use Backend\Classes\Controller;
use BackendMenu;
use Input;
use SCS\Osdb\Models\Season as SeasonModel;
use SCS\Osdb\Models\Sport;
use SCS\Osdb\Models\League;

class Field
{
    public $attributes;
    public $placeholder;
    public $name;
    public $leagueAlias;
    public $id;
    public $options;
    public $value;
    public $selectedValue;
}

class Season extends Controller
{

    public $requiredPermissions = ['scs.osdb.*'];

    public $implement = [        'Backend\Behaviors\ListController',        'Backend\Behaviors\FormController'    ];

    public $listConfig = 'config_list.yaml';
    public $formConfig = 'config_form.yaml';

    public function __construct()
    {
        parent::__construct();
        BackendMenu::setContext('SCS.Osdb', 'main-menu-osdb', 'side-menu-seasons');
        $this->fillSeasons();
    }

    public function fillSeasons()
    {
        $this->vars['seasonSelectors'] = [];
        $leagues = League::all();
        foreach ($leagues as $league) {
            $this->fillLeagueSeasons($league->guid, $league->slug);
        }
    }

    public function fillLeagueSeasons($leagueGuid, $league)
    {
        $items = SeasonModel::where('league_guid', $leagueGuid)->orderBy('year', 'desc')->get();
        $options = [];
        $selectedValue = null;
        foreach ($items as $item) {
            $sd = preg_replace('/( [0-9]{2}:[0-9]{2}:[0-9]{2}.*)/','',$item->start_date);
            $ed = preg_replace('/( [0-9]{2}:[0-9]{2}:[0-9]{2}.*)/','',$item->end_date);
            $options[$item->guid] = "$item->year $item->type " . "[$sd - $ed, $item->status]";
            if ($league != 'nfl') {
                $options[$item->guid] .= " (id# $item->season_id)";
            }
            if ($item->is_current) $selectedValue = $item->guid;
        }
        $field = new Field;
        $field->leagueAlias = strtoupper($league);
        $field->placeholder = "$field->leagueAlias current Season not selected";
        $field->name = $league.'-season';
        $field->id = $league.'-season';
        $field->options = $options;
        $field->value = null;
        $field->selectedValue = $selectedValue;

        $this->vars['seasonSelectors'][] = $field;
    }

    public function onSetCurrentSeasons()
    {
        $leagues = League::all();
        foreach ($leagues as $league) {
            $season = Input::get("$league->slug-season");
            SeasonModel::setCurrentSeason($league->guid, $season);
        }
        return true;
    }

    public function onLoadSeasons()
    {
        SeasonModel::loadESSeasons();
    }

    public static function getCurrentSeasons()
    {

        // for the start date we want to use the current day.
        $startTimespan = date("Y-m-d H:i:s");
        // for the end date we want yesterdsay.
        $endTimespan = date("Y-m-d H:i:s",strtotime("-1 days"));

        $leagues = [];
        foreach (League::all() as $league) {
            $s = SeasonModel::where('league_guid',$league->guid)->where('end_date','>', $endTimespan)->where('start_date','<', $startTimespan)->first();
            if ($s) {
                $leagues[$league->slug] = [
                    'status' => $s['status'],
                    'start_date' => $s['start_date'],
                    'end_date' => $s['end_date'],
                    'season_id' => $s['season_id'],
                    'competition_id' => $s['competition_id'],
                ];
            }
        }
        return $leagues;
    }

    public static function getTickerSeasons()
    {
       // for the start date we want to use the current day.
       $startTimespan = date("Y-m-d H:i:s");
       // for the end date we want yesterdsay.
       $endTimespan = date("Y-m-d H:i:s",strtotime("-1 days"));

        $dbLeagues = League::get()->all();
        $sports = Sport::all();

        $leagues = [];

        foreach ($sports as $sport) {
            foreach ($sport->ticker_leagues as $tickerLeague) {
                $leagueInfo = [
                    'league' => $tickerLeague['league'],
                    'ignore_seasons' => $tickerLeague['ignore_seasons']
                ];
                if ($tickerLeague['ignore_seasons']) {
                    $leagues[$tickerLeague['slug']] = $leagueInfo;
                } else {
                    $index = array_search($tickerLeague['slug'], array_column($dbLeagues, 'slug'));
                    if ($index !== false) {
                        $league = $dbLeagues[$index];
                        $s = SeasonModel::where('league_guid', $league->guid)->where('end_date','>', $endTimespan)->where('start_date','<', $startTimespan)->first();
                        if ($s) {
                            $leagues[$tickerLeague['slug']] = $leagueInfo;
                        }
                    }
                }
            }
        }

        return $leagues;
    }
}
