<?php namespace SCS\Osdb\Controllers;

use Backend\Classes\Controller;
use SCS\Osdb\Models\League as LeagueModel;
use SCS\Osdb\Models\Season;
use SCS\Osdb\Models\Team as TeamModel;
use SCS\Osdb\Models\Player as PlayerModel;
use BackendMenu;

class League extends Controller
{

    public $requiredPermissions = ['scs.osdb.*'];

    public $implement = [
        'Backend\Behaviors\ListController',
        'Backend\Behaviors\FormController'
    ];

    public $listConfig = 'config_list.yaml';
    public $formConfig = 'config_form.yaml';

    public function __construct()
    {
        parent::__construct();
        BackendMenu::setContext('SCS.Osdb', 'main-menu-osdb', 'side-menu-league');
    }

    public static function onStartPage($page)
    {
        $_leagueSlug = $page['leagueSlug'] = $page->param('slug');
        $_thisLeagePage = self::GetLeagueBySlug($_leagueSlug);
        if (isset($_thisLeagePage)) {
            if (empty($_thisLeagePage->slug)) {
                \Redirect::to('/404')->with('message', 'Cannot find that league');
            }
            $page['leaguePage'] = $_thisLeagePage;

            // set up current season for widgets
            $season = Season::getCurrentSeasonByLeagueSlug($_leagueSlug);
            if (!empty($season)){
                if ($_leagueSlug == 'nfl') $page['widgetSeason'] = $season->year;
                else $page['widgetSeason'] = $season->season_id;
                $page['widgetCompetitionId'] = $season->competition_id;
            }
        }
    }

    //do the API call here.
    // Build the base object
    //
    //do specific functions to return data as JSON on needs
    //can generic them

    public static function GetLeagueBySlug($slug)
    {
        $_league = LeagueModel::where('slug', '=', $slug)->first();
        if ($_league) {
            return $_league;
        }
        \Log::error('~~ League->GetLeagueBySlug - invalid league lookup: ' . $slug);
        return \Redirect::to('404')->with('message', 'Cannot find that league');
    }

    public static function GetLeagueByTeamSlug($slug)
    {
        $_team = TeamModel::where('slug', '=', $slug)->first();
        if ($_team) {
            $_league = LeagueModel::where('guid', '=', $_team->league_guid)->first();
            if ($_league) {
                return $_league;
            }
            \Log::error('~~ League->GetLeagueByTeamSlug - invalid league lookup: ' . $_team->league_guid);
            return \Redirect::to('404')->with('message', 'Cannot find that league');
        }
        \Log::error('~~ League->GetLeagueByTeamSlug - invalid team lookup: ' . $slug);
        return \Redirect::to('404')->with('message', 'Cannot find that team');
    }

    public static function GetLeagueByPlayerSlug($slug)
    {
        $_player = PlayerModel::where('guid', '=', $slug)->first();
        if ($_player) {
            $_team = TeamModel::where('guid', '=', $_player->team_guid)->first();
            if ($_team) {
                $_league = LeagueModel::where('guid', '=', $_team->league_guid)->first();
                if ($_league) {
                    return $_league;
                }
                \Log::error('~~ League->GetLeagueByPlayerSlug - invalid league lookup: ' . $_team->league_guid);
                return \Redirect::to('404')->with('message', 'Cannot find that league');
            }
            \Log::error('~~ League->GetLeagueByPlayerSlug - invalid team lookup: ' . $_player->team_guid);
            return \Redirect::to('404')->with('message', 'Cannot find that team');
        }
        \Log::error('~~ League->GetLeagueByPlayerSlug - invalid player lookup: ' . $slug);
        return \Redirect::to('404')->with('message', 'Cannot find that player');
    }

}
