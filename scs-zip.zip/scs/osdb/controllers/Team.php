<?php namespace SCS\Osdb\Controllers;

use Backend\Classes\Controller;
use BackendMenu;
use SCS\Osdb\Classes\ES\Leagues;
use SCS\Osdb\Classes\ES\Teams;
use SCS\Osdb\Classes\ES\TeamSeasons;
use SCS\Osdb\Models\Season;
use SCS\Osdb\Models\Player;
use SCS\Osdb\Models\Team as TeamModel;
use SCS\Osdb\Controllers\Seo as SeoController;
use Flash;
use Db;

class Team extends Controller
{

    public $requiredPermissions = ['scs.osdb.*'];

    public $implement = [        'Backend\Behaviors\ListController',        'Backend\Behaviors\FormController', 'Backend.Behaviors.ImportExportController'    ];

    public $listConfig = 'config_list.yaml';
    public $formConfig = 'config_form.yaml';
    public $importExportConfig = 'config_import_export.yaml';

    public $team = null;


    public function __construct()
    {
        parent::__construct();
        BackendMenu::setContext('SCS.Osdb', 'main-menu-osdb', 'side-menu-team');
    }

    public static function getRosterPlayers($slug)
    {
        $team = Teams::getBySlug($slug);
        $ids = [];
        foreach ($team['players'] as $player) {
            if (!array_key_exists('active', $player) || $player['active']) $ids[] = $player['id'];
        }
        $players = Leagues::getPlayers(null, $slug, $ids);
        $dbPlayers = Player::whereIn('guid', array_column($players, 'id'))->select('guid', 'custom_headshot', 'slug')->get()->all();
        $players = Leagues::addCustomHeadshotUrl($players, $dbPlayers);
        
        return $players;
    }

    public static function onStartPage($page)
    {
        $_teamSlug = $page['teamSlug'] = $page->param('slug');
        $_thisTeamLeague = \SCS\Osdb\Controllers\League::GetLeagueByTeamSlug($_teamSlug);
        $team = Teams::getBySlug($_teamSlug);
        $teamModel = isset($team) && isset($team['id']) ? TeamModel::where('guid', $team['id'])->first() : null;
        if ($teamModel) {
            $teamModel ->extendWithESData();
            $page['id'] = $teamModel->guid;
            $page['teamDivision'] = $teamModel->_division;
            $page['teamConference'] = $teamModel->_conference;
            $page['teamArena'] = $teamModel->_venue_name;
            $page['teamArenaCap'] = $teamModel->_venue_capacity;
            $page['teamArenaLocation'] = $teamModel->_venue_location;
            $page['teamHeadCoach'] = $teamModel->_headcoach;
            $page['teamManager'] = $teamModel->_manager;
        } else {
            $page['teamDivision'] = null;
        }
        if (isset($_thisTeamLeague)) {
            if (empty($team) || empty($_thisTeamLeague->slug)) {
                \Redirect::to('/404')->with('message', 'Cannot find that league');
            } else {
                $page['teamLeague'] = $_thisTeamLeague;
                $page['leagueSlug'] = strtoupper($_thisTeamLeague->slug);
                switch ($_thisTeamLeague->slug) {
                    case 'nfl':
                        $page['widgetTeamId'] = 'sd:team:' . $team['id'];
                        break;
                    case 'mls':
                        $page['widgetTeamId'] = str_replace('soccer-', '', array_get($team, 'team_id'));
                        break;
                    default:
                        $page['widgetTeamId'] = array_get($team, 'team_id');
                }
                // set up current season for widgets
                $season = Season::getCurrentSeason($_thisTeamLeague->guid);
                if (!empty($season)) {
                    if ($_thisTeamLeague->slug == 'nfl') {
                        $page['widgetSeason'] = $season->year;
                    } else if (null !== $season->season_id) {
                        $page['widgetSeason'] = $season->season_id;
                    } else {
                        $page['widgetSeason'] = $season->guid;
                    }
                }
                // set up division for widgets
                $page['widgetDivision'] = null;

                if ($team && !empty($team['conference']) && !empty($team['division'])) {
                    switch (strtolower($_thisTeamLeague->name)) {
                        case 'mlb':
                            $page['widgetDivision'] = str_replace(' ', '', $team['conference']['name']) . $team['division']['name'];
                            break;
                        case 'nba':
                            $page['widgetDivision'] =
                                substr_compare($team['division']['name'], 'east', -strlen('east')) === 0
                                || substr_compare($team['division']['name'], 'est', -strlen('est')) === 0
                                    ? $team['division']['name'] . 'ern'
                                    : $team['division']['name'];
                            break;
                        case 'nfl':
                            $page['widgetDivision'] = strtolower($team['division']['alias']);
                            break;
                        case 'mls':
                            $alias = strtolower($team['division']['alias']);
                            $parts = explode(" ", $alias);
                            $page['widgetDivision'] = $parts[0];
                            break;
                    }
                }
                // get team record and rank
                if (!empty($season)) {
                    $teams = TeamSeasons::getTeamSeasonRankingList($_thisTeamLeague->slug, [$team['id']], 1);
                }
                if (!empty($teams)) {
                    if ($teams[0] && isset($teams[0]['rank']) && ($teams[0]['rank']['division'])) {
                        $ranking = $teams[0]['rank']['division'];
                        $rankMod = ($teams[0]['rank']['division'] % 100);
                        if (in_array($rankMod, array(1, 2, 3, 11, 12, 13, 21, 22, 23, 31, 32, 33))) {
                            switch ($teams[0]['rank']['division'] % 10) {
                                // Handle 1st, 2nd, 3rd
                                case 1:
                                    $ranking = $teams[0]['rank']['division'] . "st";
                                    break;
                                case 2:
                                    $ranking = $teams[0]['rank']['division'] . "nd";
                                    break;
                                case 3:
                                    $ranking = $teams[0]['rank']['division'] . "rd";
                                    break;
                            }
                        } else {
                            $ranking = $teams[0]['rank']['division'] . "th";
                        }

                        $page['rank'] = $ranking . " in " . $teams[0]['division']['name'];
                        $page['rank'] = $ranking . " in " . $teams[0]['division']['name'];

                        if ((isset($teams[0]['win']) && $teams[0]['win'] > 0) || (isset($teams[0]['loss']) && $teams[0]['loss'] > 0)) {
                            $page['winloss'] = $teams[0]['win'] . " - " . $teams[0]['loss'];
                        } else {
                            $page['winloss'] = null;
                        }
                    }
                }
            }
        }
    }


    public static function onEndPage($page, $subtitle = null)
    {
        try {
            $page['record']['url'] = $page->currentPageUrl();   
            $page['share_links'] = SeoController::getShareLinks($page['record'], 'team', ['twitterExcerpt' => false]);            
            $page['jsonld'] = SeoController::getJsonLD($page, 'team');

        } catch (\Exception $e) {
        }

        if(!empty($page['record']['name'])){
            $title = "OSDB - " . $page['record']['name'];
            if ($subtitle) {
                $title .= " - $subtitle";
            }

            $page->page->title = $page->page->meta_title = $title;
            $page->page->meta_description = $title;

            if (!empty($page['record']->history)) {
                $page->page->meta_description  =  \SCS\Osdb\Controllers\Seo::getExcerpt($page['record']->history, 255, '...', false);
            } else {
                $page->page->meta_description = $title;
            }

            $liveUrl = 'https://www.osdbsports.com';

            $page->page->meta_image_url = "https://osdb-assets.s3.us-west-2.amazonaws.com/themes/osdb/assets/images/league/"
                . strtolower($page['record']['league']['name'])
                ."/"
                . strtolower($page['record']['slug'])
                . "/logo-dark.png";
        }

        $page->page->share_links = $page->share_links;
        $page->page->jsonld = $page->jsonld;

        if ($page['record']) {
            \SCS\Osdb\Models\Team::sendPageViewToMiso(
                $page['record']['guid'],
                $page['record']['league_guid'],
                request()->header('referer'),
                $page->page->title
            );
        }
    }
    
    public function update($recordId, $context = null)
    {
        $this->addJs('/plugins/scs/osdb/controllers/assets/js/cloudflareUtil.js');

        $model = $this->formFindModelObject($recordId);
        $model->extendWithESData();
        $this->pageTitle = $model['name'];
        $this->team = $model;
        $this->initForm($model);
    }

    public function onUnflagFeatured()
    {
        $featuredTeams = \SCS\Osdb\Models\Team::where('is_featured', 1)->get();
        if (null === $featuredTeams || count($featuredTeams) <= 0) {
            Flash::error('no teams set to featured!');
            return null;
        }
        $unfeaturedTeams = "";
        foreach ($featuredTeams as $i => $team) {
            $team->is_featured = false;
            $team->save();
            $unfeaturedTeams = $unfeaturedTeams . $team->name . ", ";
        }
        Flash::success('teams unfeatured: '.$unfeaturedTeams);
    }

    public function onFixTeam()
    {
        $sql = "
                update scs_osdb_player p
                inner join json_table(
                    p.contracts,
                    '$[*]' columns(
                    rowid FOR ORDINALITY,
                    team text PATH '$.team',
                    team_slug text PATH '$.team_slug',
                    team_logo text PATH '$.team_logo'
                    )
                ) c on c.team = 'Washington Football Team'
                set p.contracts = JSON_REPLACE(p.contracts, CONCAT('$[', c.rowid - 1, '].team_slug'),
                    'nfl\/washington-commanders');
                    
                update scs_osdb_player p
                inner join json_table(
                    p.contracts,
                    '$[*]' columns(
                    rowid FOR ORDINALITY,
                    team text PATH '$.team',
                    team_slug text PATH '$.team_slug',
                    team_logo text PATH '$.team_logo'
                    )
                ) c on c.team = 'Washington Football Team'
                set p.contracts = JSON_REPLACE(p.contracts, CONCAT('$[', c.rowid - 1, '].team_logo'),
                    'logos\/nfl\/washington-commanders\/logo-dark.svg');
                    
                update scs_osdb_player p
                inner join json_table(
                    p.contracts,
                    '$[*]' columns(
                    rowid FOR ORDINALITY,
                    team text PATH '$.team',
                    team_slug text PATH '$.team_slug',
                    team_logo text PATH '$.team_logo'
                    )
                ) c on c.team = 'Washington Football Team'
                set p.contracts = JSON_REPLACE(p.contracts, CONCAT('$[', c.rowid - 1, '].team'),
                    'Washington Commanders')     
            ";

        DB::unprepared($sql);
        $cnt = Db::select("select count(*) as c from scs_osdb_player p where contracts like '%Washington Football Team%';");
        Flash::success('Records with old team: '.$cnt[0]->c);
    }
}
