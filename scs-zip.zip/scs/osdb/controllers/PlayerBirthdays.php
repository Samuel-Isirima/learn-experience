<?php namespace SCS\OSDB\Controllers;

use BackendMenu;
use Backend\Classes\Controller;
use DateInterval;
use DateTime;
use SCS\Osdb\Classes\ES\Leagues;
use SCS\Osdb\Models\Player;
use SCS\Osdb\Models\Player as PlayerModel;

/**
 * Player Birthdays Back-end Controller
 */
class PlayerBirthdays extends Controller
{
    /**
     * @var array Behaviors that are implemented by this controller.
     */
    public $implement = [
        'Backend.Behaviors.FormController',
        'Backend.Behaviors.ListController'
    ];

    /**
     * @var string Configuration file for the `FormController` behavior.
     */
    public $formConfig = 'config_form.yaml';

    /**
     * @var string Configuration file for the `ListController` behavior.
     */
    public $listConfig = 'config_list.yaml';

    public function __construct()
    {
        parent::__construct();
        BackendMenu::setContext('SCS.OSDB', 'osdb', 'playerbirthdays');
        $this->getNextBirthdayPlayers();
    }

    public function getNextBirthdayPlayers() {
        $estDate = (new DateTime('America/New_York'));
        $startDate = $estDate->format("Y-m-d");
        $endDate = $estDate->add(new DateInterval('P3D'))->format("Y-m-d");
        $this->vars['nextWeekBirthdays'] = [];
        $this->vars['startDate'] = $startDate;
        $this->vars['endDate'] = $endDate;
        //$players = \SCS\Osdb\Classes\ES\Players::playersNextWeek();
        $players = \SCS\Osdb\Classes\ES\Players::bornBetween(strtotime($startDate), strtotime($endDate));
        $dbPlayers = PlayerModel::whereIn('guid', array_column($players, 'id'))
            ->select('guid', 'custom_headshot', 'slug')
            ->get()
            ->all();
        $featuredList = collect($dbPlayers)->mapWithKeys(function ($item) {
            return [$item['guid'] => $item['is_featured']];
        })->toArray();
        foreach ($players as $key => $player) {
            $featuredExists = key_exists($player['id'], $featuredList);
            if ($featuredExists) {
                $p = [];
                $p['__id'] = $player['id'];
                $p['__fname'] = $player['first_name'];
                $p['__lname'] = $player['last_name'];
                $p['__team'] = array_has($player, 'team') && $player['team'] != null ? $player['team']['full_name'] : "";
                $p['__birthday'] = array_has($player, 'birthdate') ? $player['birthdate'] : "";
                $p['__inDB'] = $featuredExists ? "true" : "false";
                $p['__featured'] = $featuredExists ? $featuredList[$player['id']] ? "true" : "false" : "";
                $this->vars['nextWeekBirthdays'][$key] = $p;
            }
        }
    }

}
