<?php

namespace SCS\Osdb\Controllers;

use Carbon\Carbon;
use Exception;
use Intervention\Image\ImageManagerStatic as Image;

use Backend\Classes\Controller;

class Resizer extends Controller
{

    private static $_rootDomain = 'www.osdbsports.com';
    protected static $defaultImageNotFound = '/themes/osdb/assets/images/core/image-not-found.png';
    protected static $defaultStoragePath = 'themes/osdb/assets/images/imageresizecache';
    protected static $options = [];
    protected static $original;
    protected static $originalExtension;
    protected static $rootDir;
    // cache time in hours
    protected static $cacheTimeout = 12;

    /**
     * modified image resource
     */
    protected static $modimg;

    /**
     * The path to the image
     */
    protected static $origimage;


    public function __construct()
    {

    }

    /**
     * Clear specific cache images for players and teams
     *
     * @param  string $identifier - uuid for player or team
     * @param  string $extension  - can be png, jpg or *
     * @return void
     */
    public static function clearImages(string $identifier, string $extension)
    {

        self::$rootDir = dirname(dirname(dirname(dirname(dirname(__FILE__)))));

        $storedImagePath = self::$rootDir . '/' . trim(self::$defaultStoragePath, '/');

        $globPattern = $storedImagePath . '/*.' . trim($extension, '.');
        $imagesFiles = glob($globPattern);

        foreach ($imagesFiles as $imageFile) {
            if (strpos($imageFile, $identifier) !== false) {
                if (file_exists($imageFile)) {
                    unlink($imageFile);
                }
            }
        }
    }

    /**
     * Main function that will pull an image, resize and store in cache folder
     *
     * @param string  $image  - the path to the image
     * @param integer $width  - desired width
     * @param integer $height - desired height (optional)
     * @param string  $mode   - options are contain, cover, crop, auto, stretch
     * @param string  $format - set the output format of the image
     * 
     * @return string
     */
    public static function resize(string $image, int $width = null, int $height = null, string $mode = null, string $format = null): string
    {

        // initialize 
        self::$modimg = null;
        self::$options = null;

        self::$rootDir = dirname(dirname(dirname(dirname(dirname(__FILE__)))));

        $width = ($width > 0) ? $width : null;
        $height = ($height > 0) ? $height : null;

        $fileNameSuffix = ($width > 0) ? $width : '';
        $fileNameSuffix .= ($width > 0 && $height > 0) ? 'x' : '';
        $fileNameSuffix .= ($height > 0) ? $height : '';
        $fileNameSuffix .= ($mode) ? $mode : '';

        if (empty($image)) {
            return self::getLocalImageUrl(self::$defaultImageNotFound);
        }

        // use the folder name in combination with the file name because image names can be the same
        $tokens = explode('/', $image);
        $lastFolder = $tokens[sizeof($tokens) - 2];
        $filename = basename($image);

        self::$originalExtension = trim(pathinfo($filename, PATHINFO_EXTENSION), '.');

        if (empty($format)) {
            $format = self::$originalExtension;
        }

        $format = strtolower($format);

        if (!empty($format) && $format == 'jpeg') {
            $format = 'jpg';
        }

        $format = trim($format, '.');

        if ($format == 'svg') {
            // safeguard for if image is an svg. Just return the original url
            return $image;
        }


        $baseFileName = trim(str_replace($format, '', $filename), '.');

        $baseFileName = trim(str_replace($fileNameSuffix, '', $baseFileName), '_');

        $storedImagePath = self::$rootDir . '/' . trim(self::$defaultStoragePath, '/') . '/'
            . $lastFolder
            . '_'
            . $baseFileName
            . '_'
            . $fileNameSuffix
            . '.'
            . $format;

        if (file_exists($storedImagePath)) {
            $fileAge = time() - filemtime($storedImagePath);
            $fileAgeLimit = self::$cacheTimeout * 3600;
            if ($fileAge < $fileAgeLimit) {
                return self::getLocalImageUrl($storedImagePath);
            }
        }

        if (strpos($image, 'http') !== false) {
            // $imageContents = @file_get_contents($image);
            // the above takes too long to load. Adding connection close header reduces the time and improves performance.
            $context = stream_context_create(array('http' => array('header' => 'Connection: close\r\n')));
            $imageContents = @file_get_contents($image, false, $context);
        } else {
            $localFilePath = self::$rootDir . '/' . trim($image, '/');
            if (file_exists($localFilePath)) {
                $imageContents = @file_get_contents($localFilePath);
            } else {
                // safeguard in case image path not found
                return $image;
            }
        }

        if (empty($imageContents)) {
            return self::getLocalImageUrl(self::$defaultImageNotFound);
        }

        $width = ($width !== null) ? (int) $width : null;
        $height = ($height !== null) ? (int) $height : null;

        // Create directory if not exists
        $base = dirname($storedImagePath);
        if (!file_exists($base)) {
            mkdir($base, 0775, true);
        }

        @file_put_contents($storedImagePath, $imageContents);

        self::$origimage = $storedImagePath;

        $options['width'] = $width;
        $options['height'] = $height;
        $options['mode'] = $mode;
        $options['format'] = $format;

        $defaults = [
            'driver' => 'gd',
            'mode' => 'cover',
            'quality' => 80,
            'format' => 'jpg',
        ];

        self::$options = array_merge($defaults, $options);

        if (self::processImage()) {
            return self::getLocalImageUrl($storedImagePath);
        } else {
            return self::getLocalImageUrl(self::$defaultImageNotFound);
        }
    }


    /**
     * Return a clean ulr for local image
     *
     * @param  string $localFile
     * @return string
     */
    private static function getLocalImageUrl(string $localFile): string
    {

        // total hack until we can figure out why dev server reports being on http
        if ($_SERVER['HTTP_HOST'] === 'dev.osdbsports.com') {

            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
            $domainName = $_SERVER['HTTP_HOST'];

            $fileurl = $protocol . $domainName . str_replace(self::$rootDir, '', $localFile);

            return $fileurl;

        } else {
            return str_replace(self::$rootDir, '', $localFile);
        }
    }


    /**
     * Retrieve the Image Not Found image
     *
     * @return string
     */
    private static function getDefaultImage(): string
    {
        // Retrieve the Image Not Found image from settings
        $image = self::$defaultImageNotFound;

        // If available, apply it
        if (!empty($image)) {
            $image = base_path(ltrim(config('cms.storage.media.path'), '/')) . $image;
        }

        // If the image still doesn't exist, use the provided Image Not Found image
        if (!$image || !file_exists($image)) {
            $image = self::$defaultImageNotFound;
        }

        // If the 404 image format is not auto then apply this format
        $format = 'auto';
        if ($format !== 'auto') {
            self::$options['format'] = $format;
        }

        // Apply 404 image mode and quality
        self::$options['mode'] = 'cover';
        self::$options['quality'] = 65;

        return $image;
    }



    /**
     * Run the image through intervention
     *
     * @return boolean - true is success
     */
    private static function processImage()
    {

        $width = self::$options['width'] ?? null;
        $height = self::$options['height'] ?? null;

        $hasMinMaxConstraint = array_key_exists('min_height', self::$options) ||
            array_key_exists('max_height', self::$options) ||
            array_key_exists('min_width', self::$options) ||
            array_key_exists('max_width', self::$options);

        if (empty(self::$modimg)) {
            Image::configure(
                [
                    'driver' => 'gd'
                ]
            );

            try {
                // Default the image if it's a directory
                if (is_dir(self::$origimage)) {
                    throw new \Exception('Image file does not exist (is directory)');
                }

                // Default the image if it doesn't exist
                if (is_dir(self::$origimage)) {
                    throw new \Exception('Image file does not exist (not found)');
                }

                self::$modimg = self::$original = Image::make(self::$origimage);
            } catch (\Exception $e) {

                // file is junk so skip it
                if (file_exists(self::$origimage)) {
                    unlink(self::$origimage);
                }
                return false;
            }
        }

        if (($width !== null) || ($height !== null) || $hasMinMaxConstraint) {
            $oheight = self::$original->height();
            $owidth = self::$original->width();
            $oratio = $owidth / $oheight;

            $same = ($width === null || $height === null);

            if ($width === null && $height !== null) {
                $width = (int) ($height * $oratio);
            } elseif ($height === null && $width !== null) {
                $height = (int) ($width / $oratio);
            } else if ($width === null && $height === null) {
                $height = $oheight;
                $width = $owidth;
            }

            $ratio = $width / $height;
            $same = $same ?? ($ratio === $oratio);

            $resizeWidth = $width;
            $resizeHeight = $height;

            // Use fit mode?
            $fit = false;

            $fitPosition = 'center';

            // Allow upsizing of the image? (default: false)
            $allowUpsizing = (!empty(self::$options['upsize']) && (bool) self::$options['upsize']);

            // Should the canvas be resized to the dimensions specified?
            $resizeCanvas = false;

            // Figure out what to do, crop, pad, etc
            if (!empty(self::$options['mode'])) {
                switch (self::$options['mode']) {
                    case 'contain':
                        if ($same) {
                            break; // Nothing needs to be done
                        } elseif ($oratio > $ratio) {
                            // Was wider, is more thinner now, so calculate the height of the image ($height is now simply the canvas size)
                            $resizeHeight = $width / $oratio;
                            $resizeCanvas = true;
                        } else {
                            // Was taller, is more smaller now, so calculate the width of the image ($width is now simply the canvas size)
                            $resizeWidth = $height * $oratio;
                            $resizeCanvas = true;
                        }
                        break;
                    case 'cover':
                    case 'crop':
                        $fit = true;
                        break;
                    case 'auto':
                        self::$modimg->resizeCanvas($width, $height);
                        break;
                    case 'stretch':
                        // Use width and height, stretch to fit
                        break;
                    default:
                        //
                        break;
                }
            }

            if ($fit) {
                self::$modimg->fit(
                    $width,
                    $height,
                    function ($constraint) use ($allowUpsizing) {
                        if (!$allowUpsizing) {
                            $constraint->upsize(); // prevent upsizing
                        }
                    },
                    $fitPosition
                );
            } else {
                self::$modimg->resize(
                    $resizeWidth,
                    $resizeHeight,
                    function ($constraint) use ($allowUpsizing) {
                        if (!$allowUpsizing) {
                            $constraint->upsize(); // prevent upsizing
                        }
                    }
                );
            }

            if ($resizeCanvas) {
                self::$modimg->resizeCanvas($width, $height);
            }
        }

        self::$modimg->save(self::$origimage, self::$options['quality'] ?? null, self::$options['format'] ?? null);

        return true;

    }

}
