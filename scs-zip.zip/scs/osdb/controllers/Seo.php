<?php namespace SCS\Osdb\Controllers;

use Backend\Classes\Controller;
use SCS\Osdb\Controllers\Resizer;
use Config;

class Seo extends Controller
{

    private static $_rootDomain = 'www.osdbsports.com';


    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Generate standard format social share links 
     *
     * @param object $modelData - the model data
     * @param string $context   - type of page
     * @param array  $options   - ['twitterExcerpt' => true]
     *
     * @return array - list of share links for various share methods
     */
    public static function getShareLinks(object $modelData, string $context, $options = []): array
    {
        
        $isMobile = false;

        $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);
        $isMobile = is_numeric(strpos($useragent, "mobile"));
        $isIOs = (strstr($useragent, 'iphone') || strstr($useragent, 'ipad'));
        
        $excerpt = '';

        switch($context){

        case 'insight':
            $url = \Cms\Classes\Controller::getController()->currentPageUrl() . '?insight=' . $modelData->insightId;
            $title = $modelData->title;
            $excerpt = $modelData->excerpt;
            break;

        case 'editorial' :
            $url     = 'https://' . self::$_rootDomain . '/editorials/' . $modelData->slug;
            $title   = $modelData->title;
            $excerpt = !empty($modelData->excerpt) ? $modelData->excerpt : $modelData->content;
            break;

        case 'player' :
            $urlParts = parse_url($modelData->url);
            $url      = 'https://' . self::$_rootDomain . '/' . ltrim($urlParts['path'], '/');
            $title    = 'OSDB - ' . $modelData->name;

            if (!empty($modelData->bio['biography'])) {
                $excerpt  = $modelData->bio['biography'];
            } else {
                $excerpt  = "{$modelData->_team_name} ({$modelData->_position})"; 
            }
        
            break;

        case 'team' :
            $urlParts = parse_url($modelData->url);
            $url      = 'https://' . self::$_rootDomain . '/' . ltrim($urlParts['path'], '/');
            $title    = 'OSDB - ' . $modelData->name;
             
            if (!empty($modelData->history)) {
                $excerpt  = $modelData->history;
            } else {
                $excerpt  = "{$modelData->_team_name} ({$modelData->_position})"; 
            }

            break;

        }

        $excerpt = strip_tags($excerpt);
        $excerpt = html_entity_decode($excerpt);
   
        $encodedUrl   = urlencode($url);
        $encodedTitle = urlencode($title);
        $body         = $excerpt;
        $twitterBody  = $body;
        $encodedBody  = urlencode($body);

        // twitter is limited to 290 chars but we will pad to 240
        $charlimit   = 240;
        $twitterText =  $title.'%20%3A%20'.$twitterBody; //.$url;
        $msgLength   = strlen($twitterText);
        if (!empty($options['twitterExcerpt'])) {
            $twitterText = self::getExcerpt($twitterBody, $charlimit, '...', true);
            $twitterText   =  $encodedTitle.'%20%3A%20'.$twitterText;
        } else {
            $twitterText =  $encodedTitle;
        }
      
        // email is limited to 290 chars but we will pad to 240
        $charlimit = 240;
        $msgLength = strlen($body);

        $emailBody = htmlspecialchars($body);

        if ($msgLength > $charlimit) {
            $emailBody = self::getExcerpt($emailBody, $charlimit, '...', false);
        }

        // this is the identifier and hashtags on twitter
        $via       = 'OSDBSPORTS';
        $hash_tags = '';
  
        $text = $encodedTitle;

        if ($encodedBody) {
            $text .= '%20%3A%20';   // This is just " : "
            $text .= $encodedBody;
        }

        $links = [];

        $links['email']     = 'mailto:?subject='.htmlspecialchars($title).'&body='.$emailBody.'%0D%0A%0D%0A'.$encodedUrl;
        $links['facebook']  = 'http://www.facebook.com/sharer.php?t='.$encodedTitle.'&u='.$encodedUrl;
        $links['messenger'] = 'fb-messenger://share?link='.$encodedUrl;
        $links['twitter']   = 'https://twitter.com/intent/tweet?url='.$encodedUrl.'&text='.$twitterText.'&via='.$via.'&hashtags='.$hash_tags;
        $links['whatsapp']  = 'https://wa.me/?text='.$text.'%20'.$encodedUrl;
        $links['linkedin']  = 'https://www.linkedin.com/sharing/share-offsite/?url='.$encodedUrl;
        $links['pinterest'] = 'http://pinterest.com/pin/create/button/?url='.$encodedUrl;
    
        if ($isMobile) {
            if ($isIOs) {
                $links['sms'] = 'sms:&body='.str_replace('+', ' ', $text.'%0D%0A%0D%0A'.$encodedUrl);
            } else {
                $links['sms'] = 'sms:?body='.str_replace('+', ' ', $text.'%0D%0A%0D%0A'.$encodedUrl);
            }
        } else {
            $links['clipboard'] = $url;
        }

        return $links;

    }

    /**
     * Generate JSON-LD for page headers (seo)
     *
     * @param  object $richData - article, player or team  data
     * @param  string $context  - type of page
     * @return string - schemaContent for the application/ld+json script body
     */
    public static function getJsonLD(object $richData, string $context)
    {
        
        $schemaContent = null;

        $leagueSports = [
            'nfl' => 'American Football', 
            'nba' => 'Basketball', 
            'mlb' => 'Major League Baseball', 
            'mls' => 'Soccer', 
            'nhl' => 'Hockey',
        ];

        switch($context){

        case 'editorial' :

            $url     = 'https://' . self::$_rootDomain . '/editorials/' . $richData->page->slug;
            $title   = $richData->page->meta_title;
            $imageUrl = $richData->page->meta_image_url;
            $excerpt = $richData->page->meta_description;
            $publishedAt = $richData->page->published_at;
            $maxArticleBodyLimit   = 240;
            $excerpt = self::getExcerpt($excerpt, $maxArticleBodyLimit, '...', false);
            
            $schemaContent = '{' . "\n";
            $schemaContent .= '  "@context": "https://schema.org",'. "\n";  
            $schemaContent .= '  "@type": "NewsArticle",'. "\n";
            $schemaContent .= '  "url": "' . $url . '",'. "\n";
            $schemaContent .= '  "publisher":{'. "\n";
            $schemaContent .= '    "@type":"Organization",'. "\n";
                $schemaContent .= '    "name":"OSDB",' . "\n";
            $schemaContent .= '    "logo":"https://osdb-assets.s3.us-west-2.amazonaws.com/images/OSDB.png"'. "\n";
            $schemaContent .= '  },'. "\n";
            $schemaContent .= '  "headline": "' . $title . '",'. "\n";
            $schemaContent .= '  "articleBody": "' . $excerpt . '",'. "\n";
            $schemaContent .= '  "image":['. "\n";
            $schemaContent .= '    "' . $imageUrl . '"'. "\n";
            $schemaContent .= '  ],'. "\n";
            $schemaContent .= '  "datePublished":"' .  $publishedAt .'"'. "\n";
            $schemaContent .= '}';

            break;

        case 'player' :

            $playerName = $richData['record']['name'];

            $playerposition = !empty($richData['record']['playerPositionLabel']) ? $richData['record']['playerPositionLabel'] : null;

            $urlParts = parse_url($richData['record']['url']);
            $playerUrl = 'https://' . self::$_rootDomain . '/' . ltrim($urlParts['path'], '/');
          
            if ($richData['record']['custom_headshot']) {
                $playerImageUrl = 'https://' . self::$_rootDomain  . Resizer::resize(url(Config::get('cms.storage.media.path')).$richData['record']['custom_headshot'], 280);
            } elseif ($richData['record']['_headshot_high_res']) {
                $playerImageUrl = 'https://' . self::$_rootDomain  . Resizer::resize($richData['record']['_headshot_high_res'], 280);
            } else {
                $playerImageUrl = 'https://' . self::$_rootDomain . '/' . ltrim($richData->page->meta_image_url, '/');
            }
       
            $teamName = null;
            $teamUrl = null;
            $startDate = null;
            $endDate = null;
            $sport = null;

            if (!empty($richData['playerLeague']->slug) 
                && !empty($leagueSports[$richData['playerLeague']->slug])
            ) {
                $sport = $leagueSports[$richData['playerLeague']->slug];
            }
           
            if (empty($teamName) && !empty($richData['record']->team)) {
                $teamName = $richData['record']->team->name;
            }
        
            if (!empty($richData['record']['contracts'])) {

                foreach ($richData['record']['contracts'] as $contract) {

                    if ($contract['active'] == 1) {
                        $startDate = $contract['year_started'];
                        $endDate = $contract['end_year'];
                        $teamName = $contract['team'];
                        $teamUrl = 'https://' . self::$_rootDomain . '/' . ltrim($contract['team_slug']);
                        break;
                    }
                }   
            }

            $schemaContent = '{' . "\n";
            $schemaContent .= '  "@context": "https://schema.org",'. "\n";  
            $schemaContent .= '  "@type": "SportsTeam",'. "\n";  
            $schemaContent .= '  "sport": "' . $sport . '",'. "\n"; 
            $schemaContent .= '  "name": "' . $teamName . '",'. "\n"; 
            $schemaContent .= '  "url": "' . $teamUrl . '",'. "\n"; 
            $schemaContent .= '  "member": {'. "\n";  
            $schemaContent .= '    "@type": "OrganizationRole",'. "\n";  
            $schemaContent .= '    "member": {'. "\n";  
            $schemaContent .= '      "@type": "Person",'. "\n";  
            $schemaContent .= '      "name": "' . $playerName . '",'. "\n"; 
            $schemaContent .= '      "url": "' . $playerUrl . '",'. "\n";  
            $schemaContent .= '      "image": "' .  $playerImageUrl . '"'. "\n";  
            $schemaContent .= '    },'. "\n";  

            if (!empty($startDate) && !empty($endDate)) {
                $schemaContent .= '    "startDate": ' . preg_replace("/[^0-9]/", "", $startDate) .','. "\n"; 
                $schemaContent .= '    "endDate": ' . $endDate .','. "\n";   
            }

            if (!empty($playerposition)) {
                $schemaContent .= '    "roleName": "' . $playerposition . '",'. "\n";  
            }
          
            $schemaContent .= '  }'. "\n";    
            $schemaContent .= '}';

            $lastCommaPos = strrpos($schemaContent, ',');

            if ($lastCommaPos !== false) {
                $schemaContent = substr_replace($schemaContent, '', $lastCommaPos, 1);  // Remove the last comma
            }
            break;

        case 'team' :


            $teamName = $richData['record']['name'];
            $coachName = $richData['teamHeadCoach'];

            if (empty($coachName) 
                && !empty($richData['record']['metadata_firsts']['head_coach'])
            ) {
                $coachName = $richData['record']['metadata_firsts']['head_coach'];
            }

            $sport = null;

            $leagueSlug = strtolower($richData['leagueSlug']);
            if (!empty($leagueSlug) 
                && !empty($leagueSports[$leagueSlug])
            ) {
                $sport = $leagueSports[$leagueSlug];
            }

            $schemaContent = '{' . "\n";
            $schemaContent .= '  "@context": "https://schema.org",'. "\n";  
            $schemaContent .= '  "@type": "SportsTeam",'. "\n";  
            $schemaContent .= '  "name": "' . $teamName . '",'. "\n"; 
            $schemaContent .= '  "sport": "' . $sport . '",'. "\n"; 
            $schemaContent .= '  "coach": {'. "\n"; 
            $schemaContent .= '    "@type": "Person",'. "\n"; 
            $schemaContent .= '    "name": "' . $coachName . '"'. "\n"; 
            $schemaContent .= '  }'. "\n"; 
            $schemaContent .= '}'; 

            break;


        case 'home' :

            $schemaContent = '{' . "\n";
                $schemaContent .= '  "@context": "https://schema.org",' . "\n";
                $schemaContent .= '  "@type": "WebSite",' . "\n";
                $schemaContent .= '  "name": "OSDB",' . "\n";
            $schemaContent .= '  "url": "https://www.osdbsports.com",'. "\n"; 
            $schemaContent .= '  "logo": "https://osdb-assets.s3.us-west-2.amazonaws.com/images/OSDB.png",'. "\n";
            $schemaContent .= '  "sameAs": ['. "\n"; 
            $schemaContent .= '    "https://www.facebook.com/OSDB-Sports-1680622812237212",'. "\n"; 
            $schemaContent .= '    "https://www.twitter.com/OSDBSports",'. "\n"; 
            $schemaContent .= '    "https://www.instagram.com/osdb"'. "\n"; 
            $schemaContent .= '  ]'. "\n"; 
            $schemaContent .= '}';

            break;

        }

        return $schemaContent;

    }

    /**
     * Get pull position labels from short codes
     *
     * @param  string $positionCode - short code for postiton
     * @param  string $sportSlug    - slug for sport
     * @return string - full position lavel
     */
    public static function getPositionLabel(string $positionCode, string $sportSlug): string
    {

        $label = '';

        $positionCode = trim(strtoupper(preg_replace('/[\W]/', '', $positionCode)));

        $positionLabels = [
            'mlb' => [
                '1B' => 'First Baseman',
                '2B' => 'PitSecond Basemancher',
                '3B' => 'Third Baseman',
                'C' => 'Catcher',
                'CF' => 'Center Fielder',
                'CL' => 'Closer Pitcher',
                'CP' => 'Closing Pitcher',
                'IF' => 'Infield',
                'LF' => 'Left Fielder',
                'LRP' => 'Long Reliever Pitcher',
                'MRP' => 'Middle Relief Pitcher',
                'OF' => 'Outfield',
                'P' => 'Pitcher', 
                'RF' => 'Right Fielder',
                'SS' => 'Shortstop',
            ],
            'mls' => [
                'AM' => 'Attacking Midfielder',                
                'CB' => 'Center Back',
                'CF' => 'Center Forward', 
                'CM' => 'Central Midfielder',
                'DM' => 'Defensive Midfielder',    
                'GK' => 'Goalkeeper',
                'LB' => 'Left Fullback',
                'LM' => 'Left Midfielder',
                'LWB' => 'Left Wingback',
                'RB' => 'Right Fullback',
                'RM' => 'Right Midfielder',
                'RWB' => 'Right Wingback',
                'S' => 'Striker',
                'SS' => 'Second Striker',
                'SW' => 'Sweeper',
            ],
            'nba' => [
                'C' => 'Center',
                'F' => 'Forward',
                'FC' => 'Forward Center',
                'G' => 'Point Guard and Shooting Guard',
                'GF' => 'Shooting Guard and Small Forward',
                'PF' => 'Power Forward',
                'PG' => 'Point Guardard',
                'SF' => 'Small Forward',
                'SG' => 'Shooting Guard',
            ],
            'nfl' => [
                'C' => 'Center',
                'CB' => 'Cornerback',
                'DE' => 'Defensive End',
                'DB' => 'Defensive Back',
                'DT' => 'Defensive Tackle',
                'FB' => 'Running Back',
                'H' => 'Holder',
                'HB' => 'Running Back',
                'K' => 'Kicker',
                'KOS' => 'Kickoff Specialist',
                'KR' => 'Kick Returner',
                'LS' => 'Long Snapper',
                'MLB' => 'Middle Linebacker',
                'OG' => 'Offensive Guard',
                'OLB' => 'Outside Linebacker',
                'OT' => 'Offensive Tackle',
                'P' => 'Punter',
                'PR' => 'Punt Returner',
                'QB' => 'Quarterback',
                'R' => 'Receiver',
                'RB' => 'Running Back',
                'S' => 'Safety',
                'TE' => 'Tight End',
                'WR' => 'Wide Receiver',
            ],
        ];

        if (!empty($positionLabels[strtolower($sportSlug)][strtoupper($positionCode)])) {
            $label = $positionLabels[strtolower($sportSlug)][strtoupper($positionCode)];            
        }

        return $label;

    }


    /**
     * Truncate a long string
     *
     * @param  string  $content
     * @param  integer $charlimit
     * @param  string  $ellipsis
     * @return string
     */
    public static function getExcerpt(string $content, int $charlimit = 240, string $ellipsis = '...' , $urlEncode = false): string
    {
  
        $content = strip_tags($content);
        $msgLength = strlen($content);

        if ($msgLength > $charlimit) {
            $maxBodyLength = strlen($content) - ($msgLength - $charlimit);
            $content = preg_replace('/\s+?(\S+)?$/', '', substr($content, 0, $maxBodyLength));
  
            if ($urlEncode) {
                $content = urlencode($content);
            }
            $content = $content . $ellipsis;
        } 
  
        return $content;
          
    }

}
