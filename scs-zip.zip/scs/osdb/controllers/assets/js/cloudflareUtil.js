
function purgeCloudflarePlayer(slug, league, elementID) {
    console.log("purgeCloudflarePlayer");
    console.log("slug:", slug, "league:", league);
    const url = '/api/cloudflare/purge_player?slug=' + slug + '&league=' + league;
    purgeCloudflareProcess(url, elementID);
}


function purgeCloudflareUrl(page, elementID) {
    console.log("purgeCloudflareUrl");
    console.log("Page:", page);

    const url = '/api/cloudflare/purge_page?page=' + page;
    purgeCloudflareProcess(url, elementID);
}

function purgeCloudflareProcess(apiUrl, elementID) {

    console.log("purgeCloudflareProcess: ", apiUrl);


    const element = document.getElementById(elementID);
    const originalContent = (element) ? element.innerHTML : null;
    if (originalContent) {
        element.innerHTML = "Processing...";
    }

    // Perform the POST request using fetch
    fetch(apiUrl, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
        }
    })
        .then(response => {
            if (!response.ok) {
                throw new Error("Failed to clear cache");
            }
            return response.json();
        })
        .then(data => {
            if (originalContent) {
                element.innerHTML = originalContent;
            }
            alert(data.message);
        })
        .catch(error => {
            if (originalContent) {
                element.innerHTML = originalContent;
            }
            alert("Error: " + error.message);
        });

}