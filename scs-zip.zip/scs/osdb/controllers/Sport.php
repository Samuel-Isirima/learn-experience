<?php namespace SCS\Osdb\Controllers;

use Backend\Classes\Controller;
use BackendMenu;

class Sport extends Controller
{

    public $requiredPermissions = ['scs.osdb.*'];

    public $implement = [        'Backend\Behaviors\ListController',        'Backend\Behaviors\FormController'    ];
    
    public $listConfig = 'config_list.yaml';
    public $formConfig = 'config_form.yaml';

    public function __construct()
    {
        parent::__construct();
        BackendMenu::setContext('SCS.Osdb', 'main-menu-osdb', 'side-menu-sport');
    }
}
