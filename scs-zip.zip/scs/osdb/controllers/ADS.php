<?php namespace SCS\Osdb\Controllers;

use Backend\Classes\Controller;
use Illuminate\Support\Facades\DB;
use Model;
use Flash;
use Artisan;
use SCS\Osdb\Classes\Services\ElasticsearchService;
use SCS\Osdb\Classes\ES\Teams;
use SCS\Osdb\Classes\ES\Leagues;
use SCS\Osdb\Classes\ES\Players;
use SCS\Osdb\Classes\ES\Seasons;
use SCS\Osdb\Models\Sport;
use SCS\Osdb\Models\Team;
use SCS\Osdb\Models\League;
use SCS\Osdb\Models\Player;
use SCS\Osdb\Models\Season;

class ADS extends Controller
{

    public $requiredPermissions = ['scs.osdb.*'];

    public function index()
    {
        $teamsEsCount = Teams::count();
        $teamsDbCount = Db::select("select count(*) as cnt from ".Team::TABLE)[0]->cnt;
        $playersEsCount = Players::count();
        $playersDbCount = Db::select("select count(*) as cnt from ".Player::TABLE)[0]->cnt;

        $playersNoHeadshotsCount = Players::noHeadshotsCount();

        $this->vars['teamsES'] = $teamsEsCount;
        $this->vars['teamsDB'] = $teamsDbCount;
        $this->vars['playersES'] = $playersEsCount;
        $this->vars['playersDB'] = $playersDbCount;
        $this->vars['playersNoHeadshotsCount'] = $playersNoHeadshotsCount;

        $this->vars['AWS_ACCESS_KEY_ID'] = env('AWS_ACCESS_KEY_ID', 'see .env');
        $this->vars['AWS_SECRET_ACCESS_KEY'] = env('AWS_SECRET_ACCESS_KEY', 'see .env');
        $this->vars['AWS_REGION'] = env('AWS_REGION', 'see .env');
        $this->vars['AWS_ELASTICSEARCH_URL'] = env('AWS_ELASTICSEARCH_URL', 'see .env');

        $this->vars['KIBANA_USER_ARN'] = env('KIBANA_USER_ARN', 'see .env');

        $this->vars['AWS_S3_BUCKET_REGION'] = env('AWS_S3_BUCKET_REGION', 'see .env');
        $this->vars['AWS_S3_BUCKET_NAME'] = env('AWS_S3_BUCKET_NAME', 'see .env');
        $this->vars['AWS_S3_ACCESS_KEY'] = env('AWS_S3_ACCESS_KEY', 'see .env');
        $this->vars['AWS_S3_SECRET_KEY'] = env('AWS_S3_SECRET_KEY', 'see .env');

        $this->vars['APP_ENV'] = env('APP_ENV', 'see .env');

        $this->fillLeagues();
    }

    public function fillLeagues()
    {
        $leagues = Leagues::getLeagues();
        $result = [];
        foreach ($leagues as $league){
            $result[$league['id']] = $league['alias'];
        }
        $this->vars['leagues'] = $result;
    }

    /* Converts SportRadar guids to SportsData guids - don't use for now!

        //    public function onConvert()
        //    {
        //        // convert team guids
        //        $esTeamList = Teams::list(null, ['id', 'team_id']);
        //        $teamDbIds = Db::select("select guid from ". Team::TABLE);
        //        foreach ($teamDbIds as $teamDbId) {
        //            $key = array_search($teamDbId->guid, array_column($esTeamList, 'id'));
        //            if ($key) {
        //                $esTeam = $esTeamList[$key];
        //                // update FK team_guid in scs_osdb_player table
        //                Db::table(Player::TABLE)
        //                    ->where('team_guid', $teamDbId->guid)
        //                    ->update(['team_guid' => $esTeam['team_id']]);
        //                // update guid in scs_osdb_team table
        //                Db::table(Team::TABLE)
        //                    ->where('guid', $teamDbId->guid)
        //                    ->update(['guid' => $esTeam['team_id']]);
        //            }
        //        }
        //
        //        // convert player guids
        //        $esPlayerList = Players::list(null, ['id', 'player_id']);
        //        $playerDbIds = Db::select("select guid from ". Player::TABLE);
        //        foreach ($playerDbIds as $playerDbId) {
        //            $key = array_search($playerDbId->guid, array_column($esPlayerList, 'id'));
        //            if ($key) {
        //                $esPlayer = $esPlayerList[$key];
        //                // update guid in scs_osdb_team table
        //                Db::table(Player::TABLE)
        //                    ->where('guid', $playerDbId->guid)
        //                    ->update(['guid' => $esPlayer['player_id']]);
        //            }
        //        }
        //    }

    */

    public function onUpdateLeagues()
    {
        try {
            $esList = Leagues::list();
            $sports = Db::select("select * from ".Sport::TABLE);
            $dbIds = League::all()->getQueueableIds();
            // \Log::info('~~ ADS->onUpdateLeague - DB leagues: '.count($dbIds), ['count#'=>count($dbIds)]);
            $esIds = array_map(function ($item) {
                return $item['id'];
            }, $esList);
            // \Log::info('~~ ADS->onUpdateLeague - ES leagues: '.count($esIds), ['count#'=>count($esIds)]);

            foreach ($esIds as $esId) {
                if (!in_array($esId, $dbIds)) {
                    // insert new League into DB
                    \Log::warning('~~ ADS->onUpdateLeagues - unmatched esId: '.$esId.' - creating league', ['unmatched esID'=>$esId]);
                    $key = array_search($esId, array_column($esList, 'id'));
                    $esLeague = $esList[$key];
                    switch (strtolower($esLeague['alias'])) {
                        case 'mlb':
                            $sportAlias = 'baseball';
                            break;
                        case 'nfl':
                            $sportAlias = 'american-football';
                            break;
                        case 'nba':
                            $sportAlias = 'basketball';
                            break;
                        case 'mls':
                            $sportAlias = 'soccer';
                            break;
                        case 'nhl':
                            $sportAlias = 'hockey';
                            break;
                    }
                    if (isset($sportAlias)) {
                        $sport = current(array_filter(
                            $sports,
                            function ($item) use ($sportAlias) {
                                return $item->slug == $sportAlias;
                            }
                        ));
                        if ($sport) {
                            $sportId = $sport->guid;
                            // TODO: use DB directly to avoid afterSave call
                            League::create([
                                'guid'=>$esId,
                                'name'=>$esLeague['alias'],                 //set to always use the acryomn term
                                'sport_guid' => $sportId,
                                'slug'=>str_slug($esLeague['alias'], '-')   //set to alias as it should be the short name, i.e. nfl, mlb, nba ...
                            ]);
                        } else {
                            \Log::error('~~ ADS->onUpdateLeague - cannot get sport for: '.$esId);
                        }
                    } else {
                        \Log::error('~~ ADS->onUpdateLeague - invalid sportAlias for: '.$esId);
                    }
                }
            }
            // TODO: process removed items

            Flash::success('Updated Leagues');
            // \Log::info('~~ ADS->onUpdateLeagues - success');
        }
        catch (\Exception $ex) {
            Flash::error('Error during Leagues import: ' . $ex->getMessage());
            \Log::error('~~ Error during import - Leagues:'. " [".$ex->getTraceAsString()."]");
        }
    }

    public function onUpdateSeasons()
    {
        Season::loadESSeasons(true);
    }

    public function onUpdateTeams()
    {
        $league = post('league');
        Team::loadESTeams(true, $league);
    }

    public function onUpdatePlayers()
    {
        $league = post('league');
        Player::loadESPlayers(true, $league);
    }

    public function onShowPlayersWithoutHeadshots()
    {
        $league = post('league');
        $this->vars['playersNoHeadshots'] = Players::noHeadshots($league);
        return [
            '#no-headshots' => $this->makePartial('noheadshots')
        ];
    }
}
