<?php


namespace SCS\Osdb\Classes\StaticMenu\MenuItemTypes;


use Cms\Classes\Controller;
use Cms\Classes\Page as CmsPage;

class SlugBasedMenuItemType
{
    function resolveItem($item, $url, $theme)
    {
        $slug = strtolower($item->reference);
        $isTemplate = str_starts_with($slug, ':');
        if ($isTemplate) {
            $slug = Controller::getController()->getRouter()->getParameter(substr($slug, 1), $slug);
        }
        $itemUrl = CmsPage::url($item->cmsPage, ['slug' => $slug]);
        if (str_starts_with($item->viewBag['anchor'] ?? '', '#')) {
            $itemUrl .= $item->viewBag['anchor'];
        }
        return [
            'isActive' => $isTemplate
                ? $itemUrl == $url
                : (str_ends_with($url, "/$slug") || str_contains($url, "/$slug/")),
            'url' => $itemUrl
        ];
    }
}