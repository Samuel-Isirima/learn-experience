<?php

namespace SCS\Osdb\Classes\StaticMenu\MenuItemTypes;

use Cms\Classes\Controller;
use Cms\Classes\Page as CmsPage;
use Cms\Classes\Theme;

class PlayerMenuItemType extends SlugBasedMenuItemType implements IMenuItemType
{
    function getId()
    {
        return 'osdb-player';
    }

    function getName()
    {
        return 'OSDB Player';
    }

    function getTypeInfo()
    {
        return [
            'dynamicItems' => 0,
            'nesting' => 0,
            'references' => collect([':slug' => 'Current Player']),
            'cmsPages' => [
                CmsPage::load(Theme::getActiveTheme(), 'player'),
                CmsPage::load(Theme::getActiveTheme(), 'player/contracts'),
                CmsPage::load(Theme::getActiveTheme(), 'player/business'),
                CmsPage::load(Theme::getActiveTheme(), 'player/endorsements'),
                CmsPage::load(Theme::getActiveTheme(), 'player/biography'),
                CmsPage::load(Theme::getActiveTheme(), 'player/philanthropy'),
                CmsPage::load(Theme::getActiveTheme(), 'player/awards'),
                CmsPage::load(Theme::getActiveTheme(), 'player/statistics'),
            ]
        ];
    }

    function resolveItem($item, $url, $theme)
    {
        $slug = strtolower($item->reference);
        $router = Controller::getController()->getRouter();
        $slug = $router->getParameter(substr($slug, 1), $slug);
        $leagueSlug = $router->getParameter('leagueSlug');
        $playerName = $router->getParameter('playerName');
        $itemUrl = CmsPage::url($item->cmsPage, ['slug' => $slug, 'leagueSlug' => $leagueSlug, 'playerName' => $playerName]);
        if (str_starts_with($item->viewBag['anchor'] ?? '', '#')) {
            $itemUrl .= $item->viewBag['anchor'];
        }
        return [
            'isActive' => str_starts_with($url, $itemUrl),
            'url' => $itemUrl
        ];
    }
}