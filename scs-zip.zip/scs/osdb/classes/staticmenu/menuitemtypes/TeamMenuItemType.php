<?php

namespace SCS\Osdb\Classes\StaticMenu\MenuItemTypes;

use Cms\Classes\Controller;
use Cms\Classes\Page as CmsPage;
use Cms\Classes\Theme;
use SCS\Osdb\Models\Team;

class TeamMenuItemType extends SlugBasedMenuItemType implements IMenuItemType
{
    function getId()
    {
        return 'osdb-team';
    }

    function getName()
    {
        return 'OSDB Team';
    }

    function getTypeInfo()
    {
        return [
            'dynamicItems' => 0,
            'nesting' => 0,
            'references' => collect([':slug' => 'Current Team'])->merge(
                Team::all()->mapWithKeys(function ($it) {
                    return [$it->league->slug . '/' . $it->slug => $it->name];
                }))->all(),
            'cmsPages' => [
                CmsPage::load(Theme::getActiveTheme(), 'team'),
                CmsPage::load(Theme::getActiveTheme(), "team/history"),
                CmsPage::load(Theme::getActiveTheme(), "team/notable-players"),
                CmsPage::load(Theme::getActiveTheme(), "team/roster"),
                CmsPage::load(Theme::getActiveTheme(), "team/schedule"),
                CmsPage::load(Theme::getActiveTheme(), "team/standings"),
                CmsPage::load(Theme::getActiveTheme(), "team/stats"),
            ]
        ];
    }

    function resolveItem($item, $url, $theme)
    {
        $slug = strtolower($item->reference);
        $isTemplate = str_starts_with($slug, ':');
        if ($isTemplate) {
            $router = Controller::getController()->getRouter();
            $slug = $router->getParameter(substr($slug, 1), $slug);
            $leagueSlug = $router->getParameter('leagueSlug');
        } else {
            [$leagueSlug, $slug] = explode('/', $slug);
        }
        $itemUrl = CmsPage::url($item->cmsPage, ['slug' => $slug, 'leagueSlug' => $leagueSlug]);
        if (str_starts_with($item->viewBag['anchor'] ?? '', '#')) {
            $itemUrl .= $item->viewBag['anchor'];
        }
        return [
            'isActive' => $isTemplate ? $itemUrl == $url : str_ends_with($url, "$leagueSlug/$slug"),
            'url' => $itemUrl
        ];
    }
}