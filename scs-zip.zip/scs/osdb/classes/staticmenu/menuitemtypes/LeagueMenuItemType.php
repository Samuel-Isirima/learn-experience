<?php

namespace SCS\Osdb\Classes\StaticMenu\MenuItemTypes;

use Cms\Classes\Controller;
use Cms\Classes\Page as CmsPage;
use Cms\Classes\Theme;
use RainLab\Builder\Components\RecordDetails;
use SCS\Osdb\Models\League;
use SCS\Osdb\Models\Team;

class LeagueMenuItemType extends SlugBasedMenuItemType implements IMenuItemType
{
    function getId()
    {
        return 'osdb-league';
    }

    function getName()
    {
        return 'OSDB League';
    }

    function getTypeInfo()
    {
        return [
            'dynamicItems' => 0,
            'nesting' => 0,
            'references' => collect([':slug' => 'Current League'])->merge(
                League::all()->mapWithKeys(function ($it) {
                    return [$it->slug => $it->name];
                }))->all(),
            'cmsPages' => [
                CmsPage::load(Theme::getActiveTheme(), 'league'),
                CmsPage::load(Theme::getActiveTheme(), 'league/league-scores'),
                CmsPage::load(Theme::getActiveTheme(), 'league/league-schedule'),
                CmsPage::load(Theme::getActiveTheme(), 'league/league-standings'),
                CmsPage::load(Theme::getActiveTheme(), 'league/league-teams'),
                CmsPage::load(Theme::getActiveTheme(), 'league/league-stats'),
                CmsPage::load(Theme::getActiveTheme(), 'league/league-draft'),
            ]
        ];
    }

    function resolveItem($item, $url, $theme)
    {
        $resolved = parent::resolveItem($item, $url, $theme);
        if (!$resolved['isActive']) {
            try {
                $component = Controller::getController()->getPage()->components["builderDetails"];
                if (isset($component) && $component instanceof RecordDetails) {
                    $record = $component->record;
                    if (isset($record) && $record instanceof Team) {
                        $resolved['isActive'] = $record->league->slug === $item->reference;
                    }
                }
            } catch (\Exception $e) {
            }
        }
        return $resolved;
    }


}