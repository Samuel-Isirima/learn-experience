<?php

namespace SCS\Osdb\Classes\StaticMenu;

use Event;
use SCS\Osdb\Classes\StaticMenu\MenuItemTypes\LeagueMenuItemType;
use SCS\Osdb\Classes\StaticMenu\MenuItemTypes\PlayerMenuItemType;
use SCS\Osdb\Classes\StaticMenu\MenuItemTypes\TeamMenuItemType;

class StaticMenuExtensions
{
    static function initialize()
    {
        $menuItemTypes = [];
        foreach ([
                     new LeagueMenuItemType(),
                     new TeamMenuItemType(),
                     new PlayerMenuItemType(),
                 ]
                 as $type) {
            $menuItemTypes[$type->getId()] = $type;
        }
        Event::listen('pages.menuitem.listTypes', function () use ($menuItemTypes) {
            return array_map(function ($type) {
                return $type->getName();
            }, $menuItemTypes);
        });
        Event::listen('pages.menuitem.getTypeInfo', function ($type) use ($menuItemTypes) {
            if (array_key_exists($type, $menuItemTypes)) {
                return $menuItemTypes[$type]->getTypeInfo();
            }
        });
        Event::listen('pages.menuitem.resolveItem', function ($type, $item, $url, $theme) use ($menuItemTypes) {
            if (array_key_exists($type, $menuItemTypes)) {
                return $menuItemTypes[$type]->resolveItem($item, $url, $theme);
            }
        });
        Event::listen('backend.form.extendFields', function ($widget) {
            if (!$widget->getController() instanceof \RainLab\Pages\Controllers\Index ||
                !$widget->model instanceof \RainLab\Pages\Classes\MenuItem) {
                return;
            }
            $widget->addFields([
                'viewBag[anchor]' => [
                    'label' => 'Anchor',
                    'comment' => 'Start with # to append directly to the menu item url. No # means it will be processed by JS.',
                    'type' => 'text'
                ]
            ]);
        });
    }
}