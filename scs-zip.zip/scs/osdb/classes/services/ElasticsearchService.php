<?php namespace SCS\Osdb\Classes\Services;

use Aws\Credentials\CredentialProvider;
use Aws\Credentials\Credentials;
use Aws\Signature\SignatureV4;
use Elasticsearch\ClientBuilder;
use SCS\Osdb\Classes\ES\SearchResult;
use function Sodium\add;

class ElasticsearchService
{
    use \October\Rain\Support\Traits\Singleton;

    protected $region = null;
    protected $es_url = null;

    public function __construct()
    {
        $this->region = env('AWS_REGION');
        $this->es_url = env('AWS_ELASTICSEARCH_URL');
    }

    /**
     * Initialize this singleton.
     */
    protected function init()
    {
    }

    public function requestSignInHandler(array $request) /*use ($psr7Handler, $signer, $credentialProvider, $credentials) */
    {
        // Amazon ES listens on standard ports (443 for HTTPS, 80 for HTTP).
        //$request['headers']['Host'][0] = parse_url($request['headers']['Host'][0])['host'];
        // Pull credentials from the default provider chain
        $credentialProvider = CredentialProvider::defaultProvider();
        $credentials = call_user_func($credentialProvider)->wait();
        // Create a signer with the service's signing name and Region
        $signer = new SignatureV4('es', $this->region);
        $psr7Handler = \Aws\default_http_handler();
        // Create a PSR-7 request from the array passed to the handler
        $psr7Request = new \GuzzleHttp\Psr7\Request(
            $request['http_method'],
            (new \GuzzleHttp\Psr7\Uri($request['uri']))
                ->withScheme($request['scheme'])
                ->withHost($request['headers']['Host'][0]),
            $request['headers'],
            $request['body']
        );

        // Sign the PSR-7 request with credentials from the environment
        $signedRequest = $signer->signRequest(
            $psr7Request,
            $credentials
        );

        try {
            // Send the signed request to Amazon ES
            /** @var \Psr\Http\Message\ResponseInterface $response */
            $response = $psr7Handler($signedRequest)->wait();
        } catch (\Exception $e) {
            $msg = $e->getReason()['exception']->getMessage();
            $trace = $e->getTraceAsString();
            throw new \Exception($msg);
        } catch (\GuzzleHttp\Promise\RejectionException $e) {
            $msg = $e->getReason()['exception']->getMessage();
            $trace = $e->getTraceAsString();
            throw new \Exception($msg);
        } catch (\GuzzleHttp\Exception\ClientException  $e) {
            $response = $e->getResponse();
            $trace = $e->getTraceAsString();
            $msg = $response->getBody()->getContents();
            throw new \Exception($msg);
        } catch (\GuzzleHttp\Exception\ServerException  $e) {
            $response = $e->getResponse();
            $trace = $e->getTraceAsString();
            $msg = $response->getBody()->getContents();
            throw new \Exception($msg);
        } catch (\GuzzleHttp\Exception\BadResponseException  $e) {
            $response = $e->getResponse();
            $trace = $e->getTraceAsString();
            $msg = $response->getBody()->getContents();
            throw new \Exception($msg);
        }

        // Convert the PSR-7 response to a RingPHP response
        return new \GuzzleHttp\Ring\Future\CompletedFutureArray([
            'status' => $response->getStatusCode(),
            'headers' => $response->getHeaders(),
            'body' => $response->getBody()->detach(),
            'transfer_stats' => ['total_time' => 0],
            'effective_url' => (string) $psr7Request->getUri(),
        ]);
    }

    public function count($index)
    {
        $client = ClientBuilder::create()
            ->setHandler([$this, 'requestSignInHandler'])
            ->setHosts([$this->es_url])
            ->build();

        $params = [
            'index' => $index
        ];
        $response = $client->count($params);
        return $response["count"];
    }

    public function get($index, $id)
    {
        $body = [
            'query' => [
                'bool' => [
                    'filter' => [
                        'term' => [
                            'id' => $id
                        ]
                    ]
                ]
            ]
        ];

        $response = $this->search($index, $body, 1);
        $result = null;
        if (!empty($response->items)) {
            $result = $response->items[0];
        }
        return $result;
    }

    public function getByField($index, $field_id, $id)
    {
        $body = [
            'query' => [
                'bool' => [
                    'filter' => [
                        'term' => [
                            $field_id => $id
                        ]
                    ]
                ]
            ]
        ];

        $response = $this->search($index, $body, 1);
        $result = null;
        if (count($response->items) > 0) {
            $result = $response->items[0];
        }
        return $result;
    }

    public function all($index, $limit = null, $fields = null)
    {
        try {
            $body = [
                    'query' => [
                        'match_all' => [
                            "boost" => 1.0
                        ]
                    ]
            ];
            $_search = $this->search($index, $body, $limit, $fields);
            return $_search->items;
        }
        catch (\Exception $ex) {
            \Log::error('~~ Error on ES Service->all.'. $ex->getMessage(). " [".$ex->getTraceAsString()."]");
        }
    }

    public function queryCount($index, $body)
    {
        try{
            $client = ClientBuilder::create()
                ->setHandler([$this, 'requestSignInHandler'])
                ->setHosts([$this->es_url])
                ->build();

            $params = [
                'index' => $index,
                'body'  => $body,
                'size'  => 1,
                'scroll' => '1s'
            ];
            $response = $client->search($params);
            if ($response['hits']) {
                return $response['hits']['total']['value'];
            }
            return null;
        }
        catch (\Exception $ex) {
            \Log::error('~~ Error on ES Service->queryCount.'. $ex->getMessage(). " [".$ex->getTraceAsString()."]");
        }
    }

    public function search($index, $body, $limit = null, $fields = null)
    {
        $request = function ($attempts = 3) use (&$request, $index, $body, $limit, $fields)
        {
            try {
                $client = ClientBuilder::create()
                    ->setHandler([$this, 'requestSignInHandler'])
                    ->setHosts([$this->es_url])
                    ->build();

                $params = [
                    'index' => $index,
                    'body' => $body
                ];
                if ($fields != null) {
                    $params['body']['_source'] = $fields;
                }

                $items = [];
                $total = null;

                if (isset($limit)) {
                    $params['from'] = 0;
                    $params['size'] = $limit;
                    $total = $this->searchIteration($client, $params, $items);
                } else {
                    $size = 1000;
                    $from = 0;
                    $total = 0;
                    $params['scroll'] = '1m';
                    $scrollId = 0;
                    do {
                        $params['from'] = $from;
                        $params['size'] = $size;
                        $count = $this->searchIteration($client, $params, $items, $scrollId);
                        $total += $count;
                        $from += $size;
                    } while($count == $size);
                }
                $result = new SearchResult();
                $result->total = $total;
                $result->items = $items;
                return $result;
            } catch (\Exception $ex) {
                \Log::error('~~ Error on ES Service->search.' . $ex->getMessage(). " [".$ex->getTraceAsString()."]");
                $attempts--;
                if ($attempts > 0) {
                    return $request($attempts);
                }
            }
            $result = new SearchResult();
            $result->total = 0;
            $result->items = [];
            return $result;
        };
        return $request();
    }

    private function searchIteration($client, $params, &$result, &$scrollId = NULL)
    {
        $count = 0;
        try {
            if (!empty($scrollId)) {
                // use "scroll" query
                $params = ["scroll" => $params["scroll"], "scroll_id" => $scrollId];
                $response = $client->scroll($params);
            } else {
                // use "search" query
                $response = $client->search($params);
            }

            if ($response['hits']) {
                if ($response['hits']['hits']) {
                    foreach ($response['hits']['hits'] as $item) {
                        $result[] = $item['_source'];
                        $count++;
                    }
                }
            }
            if (isset($scrollId) && array_key_exists('_scroll_id', $response)) {
                $scrollId = $response['_scroll_id'];
            }
        } catch (\Exception $ex) {
            // TODO: ERROR LOGGING
            throw $ex;
        }
        return $count;
    }

    public function aggregation($index, $body, $field)
    {
        $request = function ($attempts = 3) use (&$request, $index, $body, $field)
        {
            try {
                $client = ClientBuilder::create()
                    ->setHandler([$this, 'requestSignInHandler'])
                    ->setHosts([$this->es_url])
                    ->build();
                $body['aggs'] = [
                    'items' => [
                        'terms' => [
                            'field' => $field,
                            'size' => 10000,
                            'order' => ["_term" => "desc"]
                        ]
                    ]
                ];
                $params = [
                    'index' => $index,
                    'body' => $body
                ];

                $response = $client->search($params);
                $result = array_get($response, 'aggregations.items.buckets');
                return isset($result) ? $result : [];
            } catch (\Exception $ex) {
                \Log::error('~~ Error on ES Service->aggregation.' . $ex->getMessage(). " [".$ex->getTraceAsString()."]");
                $attempts--;
                if ($attempts > 0) {
                    return $request($attempts);
                }
            }
            $result = [];
            return $result;
        };
        return $request();
    }

    public function max($index, $body, $field)
    {
        $request = function ($attempts = 3) use (&$request, $index, $body, $field)
        {
            try {
                $client = ClientBuilder::create()
                    ->setHandler([$this, 'requestSignInHandler'])
                    ->setHosts([$this->es_url])
                    ->build();
                $body['aggs'] = [
                    'item' => [
                        'max' => [
                            'field' => $field
                        ]
                    ]
                ];
                $params = [
                    'index' => $index,
                    'body' => $body
                ];

                $response = $client->search($params);
                $result = array_get($response, 'aggregations.item.value');
                return $result;
            } catch (\Exception $ex) {
                \Log::error('~~ Error on ES Service->max.' . $ex->getMessage(). " [".$ex->getTraceAsString()."]");
                $attempts--;
                if ($attempts > 0) {
                    return $request($attempts);
                }
            }
            $result = [];
            return $result;
        };
        return $request();
    }

    /// Matching based on a collection of filters
    public function filterCollection($index, $filterArray, $limit = null, $fields = null, $fieldsExists = null)
    {
        $filter= [];
        //round about process, creating the Json string of the filters than casting it to the Array params
        //        $query_must = array();
        //        $query_json = "[";
        //
        foreach ($filterArray as $key => $value) {
            //$query_json = "{'$filterType': {'$key': '$value'} },";
            if (is_array($value)) {
                $filter[] = ["terms" => [$key => $value]];
            } else {
                $filter[] = ["term" => [$key => $value]];
            }
        }

        if ($fieldsExists) {
            foreach ($fieldsExists as $value) {
                $filter[] = ["exists" => ["field" => $value]];
            }
        }
        //
        //        $query_json = rtrim($query_json, ',');
        //        $query_json .= "]";
        //
        //        $query_must = json_decode($query_json);

        $body = [
            'query' => [
                'bool' => [
                    'filter' => $filter
                ]
            ]
        ];
        if ($fields != null) {
            $body['_source'] = $fields;
        }
        $response = $this->search($index, $body, $limit);
        return $response->items;
    }

    public function update($index, $id, $fieldList)
    {
        // TODO: too many duplicates, should be refactored
        $client = \Elasticsearch\ClientBuilder::create()
            ->setHandler([$this, 'requestSignInHandler'])
            ->setHosts([$this->es_url])
            ->build();

        $params = [
            'index' => $index,
            'id'    => $id,
            'body'  => [
                'doc' => $fieldList
            ]
        ];
        $response = $client->update($params);
        return $response;
    }
}
