<?php namespace SCS\Osdb\Classes\Services;

use Aws\Credentials\CredentialProvider;
use Aws\Credentials\Credentials;
use Aws\Signature\SignatureV4;
use Elasticsearch\ClientBuilder;
use SCS\Osdb\Classes\ES\SearchResult;
use function Sodium\add;
use Cookie;
use Request;

class MisoSearchService
{
    use \October\Rain\Support\Traits\Singleton;

    protected $misoEnabled;
    protected $secretKey;
    protected $misoDataUrl;
    protected $misoSearchUrl;

    public function __construct()
    {
        $this->misoEnabled = env('MISO_ENABLED', false);
        $this->secretKey = env('MISO_SECRET_KEY');
        $this->misoDataUrl = env('MISO_DATA_URL');
        $this->misoSearchUrl = env('MISO_SEARCH_URL');
    }

    public function search($query, $type, $limit)
    {

        try {
            $anonymous_id = Cookie::get('miso_search_anonymous_id');
            $data = [
                "q" => $query,
                "rows" => 10, //$limit,
                "type" => $type,
                "anonymous_id" => $anonymous_id,
                
                "completion_fields" => [ "title" ],
                
                // "spellcheck"=> [ "enable_auto_spelling_correction" => true ],
                // "enable_partial_match_threshold" => 7,
                // "facets" => [ "custom_attributes.sport", "custom_attributes.league" ],

                // "boost_fq" => "custom_attributes.position:\"QB\"",
                // "boost_positions" => [0,2]
            ];
            // $result = $this->misoApiCall($this->misoSearchUrl, 'search/search', $data);
            $result = $this->misoApiCall($this->misoSearchUrl, 'search/autocomplete', $data);

            $jsonResult = json_encode($result, JSON_PRETTY_PRINT);
            $jsonRequest = json_encode($data, JSON_PRETTY_PRINT);
            \Log::info("~~ MisoSearchService->search: url($this->misoSearchUrl), request($jsonRequest), result($jsonResult");

            if (!isset($result) || !isset($result->data)) {
                \Log::error('~~ MisoSearchService->search - result is not set');
            } else if ($result->message != "success") {
                $errors = true;
                $jsonString = json_encode($result, JSON_PRETTY_PRINT);
                \Log::error('~~ MisoSearchService->search - error:'. " [".$jsonString."]");
            } else {
                return $result->data;
            }
            return null;
        } catch (\Exception $ex) {
            \Log::error('~~ Error: MisoSearchService->search - exception:'. " [".$ex->getTraceAsString()."]");
        }
    }

    public function sendSearchToMiso($query, $misoId)
    {
        if (!$this->misoEnabled) return true;

        try {
            $url = Request::url();
            $anonymous_id = Cookie::get('miso_search_anonymous_id');
            $referrer = request()->header('referer');
            $item = [
                "type" => "search",
                "anonymous_id" => "$anonymous_id",
                "timestamp" => gmdate("Y-m-d\TH:i:s\Z"),
                "search" => [
                    "keywords" => $query
                ],
                "miso_id" => $misoId,
                "context" => [
                    "page" => [
                        "url" => "$url",
                        "referrer" => "$referrer"
                    ]
                ]
            ];
            $errors = $this->upload("interactions", [$item]);

            if ($errors) {
                \Log::warning('~~ MisoSearchService->sendSearchToMiso - errors', ['errors' => $errors]);
            }
        } catch (\Exception $ex) {
            \Log::error('~~ Error: MisoSearchService->sendSearchToMiso - exception:'. " [".$ex->getTraceAsString()."]");
        }
    }

    // api - 'products', 'interactions', ..
    public function upload($api, $items)
    {
        if (!$this->misoEnabled) return true;

        $chunks = array_chunk($items, 100);
        $errors = false;
        foreach ($chunks as $chunk) {
            $data = ["data" => $chunk];
            $result = $this->misoApiCall($this->misoDataUrl, $api, $data);
            if (!isset($result)) {
                \Log::error('~~ MisoSearchService->uploadToMisoSearch - result is not set');
                continue;
            }
            if ($result->message != "success") {
                $errors = true;
                $jsonString = json_encode($result, JSON_PRETTY_PRINT);
                \Log::error('~~ MisoSearchService->uploadToMisoSearch - error:'. " [".$jsonString."]");
            }
        }
        return $errors;
    }

    private function misoApiCall($misoUrl, $api, $data)
    {
        try {
            $curl = curl_init();

            curl_setopt($curl, CURLOPT_URL, $misoUrl.$api.'?api_key='.$this->secretKey);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

            if (isset($data)) {

                $jsonData = json_encode($data);
                curl_setopt($curl, CURLOPT_POSTFIELDS, $jsonData);
                curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/json',
                        'Content-Length: ' . strlen($jsonData))
                );
            }

            // this function is called by curl for each header received
            $headers = [];
            curl_setopt($curl, CURLOPT_HEADERFUNCTION,
                function($curl, $header) use (&$headers)
                {
                    $len = strlen($header);
                    $header = explode(':', $header, 2);
                    if (count($header) < 2) // ignore invalid headers
                        return $len;

                    $name = strtolower(trim($header[0]));
                    if (!array_key_exists($name, $headers))
                        $headers[$name] = [trim($header[1])];
                    else
                        $headers[$name][] = trim($header[1]);

                    return $len;
                }
            );

            $response = curl_exec($curl);
            $result = json_decode($response, false, 512, JSON_BIGINT_AS_STRING);
            $jsonString = json_encode($result, JSON_PRETTY_PRINT);
            $err = curl_error($curl);
            $errmsg = curl_error($curl);
            $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

            if ($httpcode != 200) {
                $tmp = 1;
            }

            curl_close($curl);
            return $result;
        } catch (\Exception $ex) {
            // TODO: ERROR LOGGING
            throw $ex;
        }
    }
}