<?php
namespace SCS\Osdb\Classes\Util;

use SCS\Osdb\Models\Player;
use Illuminate\Support\Str;



class SlugUtil
{
    /**
     * Generate a unique slug based on the provided name.
     *
     * @param string $name
     * @return string
     */
    public static function generatePlayerSlug($name)
    {
        // Remove all non-alphanumeric characters (excluding spaces)
        $cleanName = preg_replace('/[^A-Za-z0-9\s]/', '', $name);

        $baseSlug = Str::slug(strtolower($cleanName));
        $slug = $baseSlug;

        // Check if slug already exists
        if (!Player::where('slug', $slug)->exists()) {
            return $slug;
        }

        // If slug already exists, append numerical suffix
        $suffix = 2;
        $slug = $baseSlug . '-' . $suffix;
        while (Player::where('slug', $slug)->exists()) {
            $slug = $baseSlug . '-' . $suffix;
            $suffix++;
        }

        return $slug;
    }
}