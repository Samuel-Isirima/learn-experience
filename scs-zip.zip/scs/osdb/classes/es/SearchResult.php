<?php namespace SCS\Osdb\Classes\ES;

use SCS\Osdb\Classes\Services\ElasticsearchService;

class SearchResult
{
    public $total;
    public $items;
}
