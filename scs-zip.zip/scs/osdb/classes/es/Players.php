<?php namespace SCS\Osdb\Classes\ES;

use DateTime;
use OFFLINE\SiteSearch\Models\Settings;
use SCS\Osdb\Classes\Services\ElasticsearchService;
use SCS\Osdb\Classes\Services\MisoSearchService;
use SCS\Osdb\Models\Player as PlayerModel;

class Players extends ESModel
{
    public static $index = 'players';

    public static function getById($id)
    {
        $result = ElasticsearchService::instance()->get(static::$index, $id);

        return self::addSlugToPlayerItem($result);
    }

    public static function bornToday()
    {
        $estDate = (new DateTime('America/New_York'));
        $month = $estDate->format("m");
        $day = $estDate->format("d");

        $jsonQuery = [
            "sort" => [
                [
                    "day_born" => "asc"
                ]
            ],
            "query" => [
                "bool" => []
            ]
        ];

        $jsonQuery["query"]["bool"] = ["filter" => [
            ["term" => ["month_born" => $month]],
            ["term" => ["day_born" => $day]],
            ["exists" => ["field" => "headshot.high_res"]],
            ["exists" => ["field" => "team.name"]],
            ["exists" => ["field" => "birthdate"]],
        ]];

        $result = ElasticsearchService::instance()->search(static::$index, $jsonQuery, null); // we shouldn't limit this query
        return isset($result) ? self::addSlugToSearchItems($result->items) : null;
    }

    public static function playersNextWeek()
    {
        $dateStr = date("Y-m-d");
        $date = strtotime("+7 day", strtotime($dateStr));
        return self::bornInWeek(date("Y-m-d", $date));
    }

    ///out: [Players: {guid(id), full_name, birthdate, age, Headshot_path} ]
    ///in: can overwrite the built in control by passing a week to view
    public static function bornThisWeek()
    {
        $dateStr = date("Y-m-d");
        return self::bornInWeek($dateStr);
    }

    public static function bornInWeek($dateStr)
    {
        $startDate = date("w", strtotime($dateStr)) == 0 ? strtotime($dateStr) : strtotime('last sunday '.$dateStr);
        $endDate = date("w", strtotime($dateStr)) == 6 ? strtotime($dateStr) : strtotime("next saturday ".$dateStr);
        return self::bornBetween($startDate, $endDate);
    }

    public static function bornBetween($startDate, $endDate)
    {
        $startMonth = date("m", $startDate);
        $startDay = date("d", $startDate);
        $endMonth = date("m", $endDate);
        $endDay = date("d", $endDate);

        $jsonQuery = [
            "sort" => [
                [ "month_born" => "asc",
                   "day_born" => "asc"
                ]
            ],
            "query" => [
                "bool" => []
            ]
        ];

        if ($startMonth == $endMonth) {
            $jsonQuery["query"]["bool"] = ["filter" => [
                ["term" => ["month_born" => $startMonth]],
                ["exists" => ["field" => "headshot.high_res"]],
                ["exists" => ["field" => "birthdate"]],
                ["exists" => ["field" => "team.name"]],
                ["range" => [
                    "day_born" => [
                        "gte" => $startDay,
                        "lte" => $endDay
                    ]
                ]]
            ]];
        } else {
            $jsonQuery["query"]["bool"] = ["should" => [
                ["bool" => ["must" => [
                    ["term" => ["month_born" => $startMonth]],
                    ["exists" => ["field" => "headshot.high_res"]],
                    ["exists" => ["field" => "birthdate"]],
                    ["exists" => ["field" => "team.name"]],
                    ["range" => [
                        "day_born" => [
                            "gte" => $startDay
                        ]
                    ]]
                ]]],
                ["bool" => ["must" => [
                    ["term" => ["month_born" => $endMonth]],
                    ["exists" => ["field" => "headshot.high_res"]],
                    ["exists" => ["field" => "birthdate"]],
                    ["range" => [
                        "day_born" => [
                            "lte" => $endDay
                        ]
                    ]]
                ]]]
            ]];
        }
        $result = ElasticsearchService::instance()->search(static::$index, $jsonQuery, null); // we shouldn't limit this query
        return isset($result) ? self::addSlugToSearchItems($result->items) : null;
    }

    public static function search($searchString, $limit)
    {
        $misoId = null;
        $misoEnabled = Settings::get('miso_enabled', false);

        if ($misoEnabled)
            $result = self::searchMiso($searchString, $limit, $misoId);
        else
            $result = self::searchByFullName($searchString, $limit);

        // expend with custom_headshot_url
        $result->items = self::addCustomHeadshotAndSlugToSearchItems($result->items);

        MisoSearchService::instance()->sendSearchToMiso($searchString, $misoId);
        return $result;
    }

    private static function addCustomHeadshotAndSlugToSearchItems(array $items)
    {
        if (count($items) == 0) {
            return $items;
        }

        $dbPlayers = PlayerModel::whereIn('guid', array_column($items, 'id'))->select('guid', 'custom_headshot', 'slug')->get()->all();
        return Leagues::addCustomHeadshotUrl($items, $dbPlayers);
    }

    // TODO: this function will be removed when search data returns slug
    private static function addSlugToSearchItems(?array $items)
    {
        return self::addCustomHeadshotAndSlugToSearchItems($items);
    }

    private static function addSlugToPlayerItem(?array $item)
    {
        if (!$item) {
            return $item;
        }

        $dbPlayer = PlayerModel::find($item['id'], ['guid', 'slug']);
        $item['slug'] = ($dbPlayer != null) ? $dbPlayer->slug : $item['id'];
        return $item;
    }

    public static function searchMiso($searchString, $limit, &$misoId)
    {
        $misoResult = MisoSearchService::instance()->search($searchString, "players", $limit);
        if (null === $misoResult || empty($misoResult->miso_id)) {
            return [];
        }
        $misoId = $misoResult->miso_id;
        $ids = [];

        // split on autocomplete and search results
        if (property_exists($misoResult, 'products') && count($misoResult->products) > 0) {
            foreach ($misoResult->products as $item) {
                $ids[] = $item->product_id;
            }
        } else if (property_exists($misoResult, 'completions') && count($misoResult->completions->title) > 0) {
            foreach ($misoResult->completions->title as $item) {
                $ids[] = $item->product->product_id;
            }
        }
        $result = self::listByIds($ids, ["excludes" => ["seasons"]]);
        return $result;
    }

    public static function searchByFullName($searchString, $limit = null)
    {
        $jsonQuery = [
            "query" => [
                "match" => [
                    "full_name" => "$searchString"
                ]
            ],
            "_source" => [
                "excludes" => ["seasons"]
            ]
        ];
        $result = ElasticsearchService::instance()->search(static::$index, $jsonQuery, $limit);
        // \Log::info("~~ searchByFullName($searchString) - query: ".print_r($jsonQuery, true));
        $names = [];
        foreach ($result->items as $item) {
            $names[] = $item['full_name'];
        }
        // \Log::info("~~ searchByFullName($searchString) - result[$result->total]: ".print_r($names, true));
        return $result;
    }

    public static function getPlayerByWidgetPlayerId($id)
    {

        if (str_starts_with($id, 'sd:player:')) {
            // if NFL
            $id = str_replace('sd:player:', '', $id);

            $jsonQuery = [
                "query" => [
                    "match" => [
                        "id" => $id
                    ]
                ]
            ];
            $result = ElasticsearchService::instance()->search(static::$index, $jsonQuery, 1);
        } else {
            // if MLB, NBA
            $jsonQuery =   '{ "query": {
                "bool": { "filter": { "term":{"player_id":'. $id .'} }}
            }}';
            $result = ElasticsearchService::instance()->search(static::$index, json_decode($jsonQuery), 1);
        }

        if ($result->items && count($result->items) > 0) {
            // add the players slug
            return self::addSlugToPlayerItem($result->items[0]);
        }

        return null;
    }

    public static function getPlayerLeague($id)
    {
        $jsonQuery =   '{ "query": {
                "bool": { "filter": { "term":{"id":'. $id .'} }}
            }}';
        $result = ElasticsearchService::instance()->search(static::$index, json_decode($jsonQuery), 1, ['league.id']);

        if ($result->items && count($result->items) > 0) return $result->items[0]['league']['id'];
        return null;
    }

    public static function noHeadshotsQuery()
    {
        $jsonQuery = [
            "query" => [
                "bool" => [
                    "must_not" => [
                        "exists" => [
                            "field" => "headshot"
                        ]
                    ]
                ]
            ]
        ];
        return $jsonQuery;
    }

    public static function noHeadshotsQueryWithLeague($league)
    {
        $jsonQuery = [
            "query" => [
                "bool" => [
                    "filter" => [
                        ["bool" => [
                            "must_not" => [
                                "exists" => [
                                    "field" => "headshot"
                                ]
                            ]
                        ]],
                        ["term" => [
                            "league.id" => "$league"
                        ]]
                    ]
                ]
            ]
        ];
        return $jsonQuery;
    }

    public static function noHeadshotsCount()
    {
        $jsonQuery = self::noHeadshotsQuery();

        $result = ElasticsearchService::instance()->queryCount(static::$index, $jsonQuery);
        return $result;
    }

    public static function noHeadshots($league = null)
    {
        $jsonQuery = $league ? self::noHeadshotsQueryWithLeague($league) : self::noHeadshotsQuery();

        $result = ElasticsearchService::instance()->search(static::$index, $jsonQuery, null, ["id", "full_name", "league", "team"]);
        return isset($result) ? self::addSlugToSearchItems($result->items) : null;
    }

    public static function getStatisticsList($filterByLeague = null, $filterByPosition = null)
    {
        $body = [
            'query' => []
        ];
        if (!empty($filterByLeague)) ESModel::addAndTerm($body, 'league.alias', strtoupper($filterByLeague));
        if (!empty($filterByPosition)) ESModel::addAndTerm($body, 'position', strtoupper($filterByPosition));
        $result = ElasticsearchService::instance()->search(static::$index, $body, null, "seasons");
        return isset($result) ? self::addSlugToSearchItems($result->items) : null;
    }

    public static function getPositionsList($filterByLeague = null)
    {
        $body = [
            'query' => []
        ];
        if (!empty($filterByLeague)) ESModel::addAndTerm($body, 'league.alias', strtoupper($filterByLeague));
        $response = ElasticsearchService::instance()->aggregation(static::$index, $body, 'position');
        $result = [];
        foreach ($response as $item) {
            $result[] = $item['key'];
        }
        return $result;
    }

    public static function getLastDraftYear($filterByLeague)
    {
        $body = [
            'query' => []
        ];
        ESModel::addAndTerm($body, 'league.alias', strtoupper($filterByLeague));

        $result = ElasticsearchService::instance()->max(static::$index, $body, 'draft.year');
        return $result != null ? (int)ceil($result) : null;
    }

    public static function getDraftYears($filterByLeague, $limit = null)
    {
        $body = [
            'query' => [],
            'sort' => [
                'draft.year' => [
                    'order' => 'desc'
                ]
            ]
        ];
        ESModel::addAndTerm($body, 'league.alias', strtoupper($filterByLeague));
        $response = ElasticsearchService::instance()->aggregation(static::$index, $body, 'draft.year');
        $result = [];
        foreach ($response as $item){
            $result[] = $item['key'];
            if (isset($limit) && count($result) == $limit) break;
        }
        return $result;
    }

    public static function getDraftPlayersByYearAndTeam($filterByLeague, $filterByYear, $filterByTeam = null)
    {
        $body = [
            'query' => [],
            'sort' => [
                'draft.round' => [
                    'order' => 'asc'
                ],
                'draft.pick' => [
                    'order' => 'asc'
                ],
                'draft.number' => [
                    'order' => 'asc'
                ]
            ]
        ];
        ESModel::addAndTerm($body, 'league.alias', strtoupper($filterByLeague));
        ESModel::addAndTerm($body, 'draft.year', $filterByYear);
        if (!empty($filterByTeam)) ESModel::addAndTerm($body, 'draft.team_id', $filterByTeam);
        $response = ElasticsearchService::instance()->search(static::$index, $body, null,
            ['excludes' => ['seasons']]);
        $result = [];
        // TODO MLB is broken above this line somewhere, only 1 $response is returned
        if ($response->total > 0) {

            $response->items = self::addSlugToSearchItems($response->items);

            foreach ($response->items as $key=>$item) {
                $round = array_get($item, 'draft.round');
                $pick = array_get($item, 'draft.pick');
                if (!isset($round) || !isset($pick)) continue;
                if (!isset($result[$round])) {
                    $result[$round] = [];
                }
                $result[$round][$pick] = $item;
            }
        }
        return $result;
    }
}
