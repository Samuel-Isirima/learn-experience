<?php namespace SCS\Osdb\classes\ES;

use SCS\Osdb\Classes\Services\ElasticsearchService;

class Games
{
    protected static $index = 'games';
    protected static $indexGamePlayerStats = 'gameplayerstats';

    public static function getById($id)
    {
        $result = ElasticsearchService::instance()->get(static::$index, $id);

        return $result;
    }

    public static function getGamesInSeries($league, $seriesId)
    {
        $body = [
            'sort' => [
                'scheduled' => "asc"
            ],
            'query' => [
                "bool" => [
                    "filter" => [
                        ["term" => ["league.alias" => strtoupper($league)]],
                        ["term" => ["series_id" => $seriesId]]
                    ]
                ]
            ]
        ];
        $result = ElasticsearchService::instance()->search(static::$index, $body);
        return isset($result) ? $result->items : null;
    }

    public static function getGameTopPerformers($league, $gameId, $filter_states, $limit)
    {
        $body = [
            'sort' => [
                $filter_states => [
                    'order' => 'desc',
                    'missing' => '_last',
                    'mode' => 'max',
                    'unmapped_type' => 'long'
                ]
            ],
            'query' => [
                'bool' => [
                    'filter' => [
                        ["term" => ["league.alias" => strtoupper($league)]],
                        ["term" => ["game_id" => $gameId]],
                        ["exists" => ["field" => $filter_states]]
                    ]
                ]
            ],
            "_source" => "player"
        ];

        $response = ElasticsearchService::instance()->search(static::$indexGamePlayerStats, $body, $limit);
        $result = [];
        if ($response->items) {
            foreach ($response as $item){
                $result[] = $item['player'];
            }
        }
        return $result;
    }

    public static function getGameList($league, $team, $gteExpression, $limit)
    {
        // TODO: not only closed games
        $body = [
            'sort' => [
                'scheduled' => "desc"
            ],
            'query' => [
                "bool" => [
                    "filter" => [
                            [
                                "term" => [
                                "status" => "closed"
                            ]
                        ]
                    ]
                ]
            ]
        ];

        if ($league)
        {
            $body['query']['bool']['filter'][] = ['term' => ['league.alias' => strtoupper($league)]];
        }

        if($team)
        {
            $body['query']['bool']['filter'][] = [
                "bool" => [
                    "should" => [
                        ["term" => ["home.slug" => $team]],
                        ["term" => ["away.slug" => $team]]
                    ]
                ]
            ];
        }

        if (isset($gteExpression)) {
            $body['query']['bool']['filter'][] = [
                "range" => ["scheduled" => ["gte" => "$gteExpression"]]
            ];
        }

        $result = ElasticsearchService::instance()->search(static::$index, $body, $limit);
        return isset($result) ? $result->items : null;
    }

    public static function getLastGames($teamSlug, $limit = 3)
    {

        $jsonQuery =   '{"sort" : [{"scheduled": "desc"}],
                        "query":
                        {
                          "bool":
                          {
                          "must":[
                              {
                                "term":{"status":"closed"}
                              },
                              {
                                "bool":{
                                "should":[{"term":{"home.slug":"'. $teamSlug .'"}},
                                          {"term":{"away.slug":"'. $teamSlug .'"}}]
                                }
                              }
                            ]
                          }
                        }}';

       //echo($jsonQuery);

        $result = ElasticsearchService::instance()->search(static::$index, json_decode($jsonQuery), $limit);
        return isset($result) ? $result->items : null;
    }

    public static function getNextGames($teamSlug, $limit = 3)
    {

        $jsonQuery =   '{"sort" : [{"scheduled": "desc"}],
                        "query":
                        {
                          "bool":
                          {
                          "must":[
                              {
                                "range":{"scheduled":
                                          {"gte":"now"}
                                }
                              },
                              {
                                "bool":{
                                "should":[{"term":{"home.slug":"'. $teamSlug .'"}},
                                          {"term":{"away.slug":"'. $teamSlug .'"}}]
                                }
                              }
                            ]
                          }
                        }}';

       //echo($jsonQuery);

        $result = ElasticsearchService::instance()->search(static::$index, json_decode($jsonQuery), $limit);
        return isset($result) ? $result->items : null;
    }
}
