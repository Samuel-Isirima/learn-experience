<?php namespace SCS\Osdb\Classes\ES;

use Config;
use SCS\Osdb\Classes\Services\ElasticsearchService;

class Leagues extends ESModel
{
    protected static $index = 'leagues';
    protected static $playerindex = 'players';

    public static function get($alias)
    {
        $result = null;
        $response = ElasticsearchService::instance()->filterCollection(static::$index, ['alias' => strtoupper($alias)]);
        if (count($response) > 0) {
            $result = $response[0];
        }
        return $result;
    }

    public static function getLeagues()
    {
        $result = ElasticsearchService::instance()->all(static::$index);
        return $result;
    }

    //
    //#TODO: Add in logic to include Ranking of the ALL case, to make sure it isn't grouped by Leagues, but another useful criteria (i.e. last game played)
    //
    ///Out: [Teams:{Guid, name, conference_rank, conference_wins, conference_loses}]
    public static function getTeams($filterByLeague = null, $limit = 7)
    {
        if (empty($filterByLeague)){
            $result = ElasticsearchService::instance()->all('teams', $limit);
        } else {
            $result = ElasticsearchService::instance()->filterCollection('teams', ['league.alias' => $filterByLeague], $limit);
        }
        return $result;
    }

    // redefined to add slug
    // public static function addCustomHeadshotUrl(&$players, $dbPlayers)
    // {
    //     $customHeadshots = collect($dbPlayers)->mapWithKeys(function ($item) {
    //         return [$item['guid'] => $item['custom_headshot'] ? url(Config::get('cms.storage.media.path')).$item['custom_headshot'] : null];
    //     })->toArray();
    //     foreach ($players as $index => &$player){
    //         if (key_exists($player['id'], $customHeadshots)){
    //             $player['custom_headshot_url'] = $customHeadshots[$player['id']];
    //         } else {
    //             unset($players[$index]);
    //         }
    //     }
    //     return $players;
    // }

    // redefined to add slug

    public static function addCustomHeadshotUrl(&$players, $dbPlayers)
    {
        $customHeadshots = collect($dbPlayers)->mapWithKeys(function ($item) {
            return [
                $item['guid'] => [
                    'custom_headshot' => $item['custom_headshot'] ? url(Config::get('cms.storage.media.path')) . $item['custom_headshot'] : null,
                    'slug' => $item['slug'] ?? $item['guid'],
                ]
            ];
        })->toArray();


        foreach ($players as $index => &$player) {
            if (key_exists($player['id'], $customHeadshots)) {
                $player['custom_headshot_url'] = $customHeadshots[$player['id']]['custom_headshot'];
                $player['slug'] = $customHeadshots[$player['id']]['slug'];
            } else {
                unset($players[$index]);
            }
        }
        return $players;
    }

    ///Out: [Players:{Guid, full_name, {stats*}, headshot_path}]
    public static function getPlayers($filterByLeague = null, $filterByTeam = null, $playerIds = [], $limit = null, $havingHeadshots = false)
    {
        $filters = array();
        if (!empty($filterByLeague)) {
            $filters["league.alias"] =  strtoupper($filterByLeague);
        }
        if (!empty($filterByTeam)) {
            $filters["team.slug"] = $filterByTeam;
        }
        if (!empty($playerIds)) {
            $filters["id"] = $playerIds;
        }
        $exists = $havingHeadshots ? ["headshot.high_res"] : null;

        $result = ElasticsearchService::instance()->filterCollection(static::$playerindex, $filters, $limit, null, $exists);

        return $result;
    }

    public static function getLeaders($league, $season_year, $filter_path, $limit = 5)
    {
###NOTE: Query has issues filtering down against YEAR - it appears to be NOT properly ordering against the year.                
       $jsonQuery =   '{"query" : {
                            "bool":{
                                "filter":[
                                  {"term":{"league.alias": "'. strtoupper($league) .'"}
                                  },
                                  {
                                     "nested":{
                                      "path" : "seasons",
                                      "query":{
                                        "bool": { "filter": { "term" :{"seasons.year" : "'. $season_year .'"} }}
                                      }       
                                     }
                                  }
                                ]
                             }
                          },
                          "sort": [
                            {
                              "'. $filter_path .'": {
                                    "order": "desc",
                                    "missing":"_last",
                                    "mode" :"max",
                                    "unmapped_type":"long",
                                     "nested":{
                                        "path" : "seasons",
                                        "filter":{
                                          "term" :{"seasons.year" : "'. $season_year .'"}
                                                  },
                                        "nested":{
                                          "path" : "seasons.teams",
                                          "filter":{
                                            "exists" : {"field" : "'. $filter_path .'"}
                                          }
                                        }
                                       }
                              }
                            }
                          ]
                        }';

        $result = ElasticsearchService::instance()->search(static::$playerindex, json_decode($jsonQuery), $limit);
        return isset($result) ? $result->items : null;
    }
}
