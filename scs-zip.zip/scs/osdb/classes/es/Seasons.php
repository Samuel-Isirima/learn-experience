<?php namespace SCS\Osdb\Classes\ES;

use SCS\Osdb\Classes\Services\ElasticsearchService;

class Seasons extends ESModel
{
    protected static $index = 'seasons';

    public static function getSeasons($leagueAlias = null)
    {
        /*
          SELECT * FROM seasons
            WHERE league.alias = MATCH_QUERY('MLB')
            ORDER BY start_date DESC
        */
        $body = [
            'query' => [],
            'sort' => [
                'start_date' => 'desc'
            ]
        ];
        if ($leagueAlias) {
            ESModel::addAndTerm($body, 'league.alias', strtoupper($leagueAlias));
        }
        $result = ElasticsearchService::instance()->get(static::$index, $body, null, ['year', 'start_date', 'end_date', 'status']);
        return $result;
    }
}
