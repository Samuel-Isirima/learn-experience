<?php namespace SCS\Osdb\Classes\ES;

use SCS\Osdb\Classes\Services\ElasticsearchService;
use SCS\Osdb\Classes\ES\Seasons;
use SCS\Osdb\Models\Season as SeasonModel;
use SCS\Osdb\Models\League as LeagueModel;

class TeamSeasons extends ESModel
{
    protected static $index = 'teamseasons';

    public static function getList($filterByLeague = null, $filterBySeasonYear, $filterBySeasonType, $teamIds = [], $limit = 7)
    {
        $body = [
            'query' => [],
            'sort' => [
                'win_percent' => 'desc'
            ]
        ];
        ESModel::addAndTerm($body, 'season.year', $filterBySeasonYear);
        ESModel::addAndTerm($body, 'season.type', $filterBySeasonType);
        ESModel::addAndTerm($body, 'league.alias', strtoupper($filterByLeague));
        ESModel::addAndTerm($body, 'team.id', $teamIds);
        $result = ElasticsearchService::instance()->search(static::$index, $body, $limit, ['team', 'league']);
        return isset($result) ? $result->items : null;
    }

    public static function getTeamSeasonRankingList($filterByLeague = null, $teamIds = [], $limit = 7)
    {
        $body = [
            'query' => [],
            'sort' => [
                'win_percent' => 'desc'
            ]
        ];

        $league = LeagueModel::where('slug', $filterByLeague)->first();

        $season = date("Y");
        if ($league) {
            // $seasons = Seasons::getSeasons($filterByLeague);
            $season = SeasonModel::where('league_guid',$league['guid'])->where('is_current',1)->first();

            if ($season) {
                ESModel::addAndTerm($body, 'season.year', $season['year']);
                ESModel::addAndTerm($body, 'season.type', $season['type']);
            }
        }
        ESModel::addAndTerm($body, 'league.alias', strtoupper($filterByLeague));
        ESModel::addAndTerm($body, 'team.id', $teamIds);
        $result = ElasticsearchService::instance()->search(static::$index, $body, $limit, ['team', 'league', 'season', 'division', 'conference', 'rank', 'win', 'loss']);
        return isset($result) ? $result->items : null;
    }
}
