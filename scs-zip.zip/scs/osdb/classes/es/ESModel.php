<?php namespace SCS\Osdb\Classes\ES;

use SCS\Osdb\Classes\Services\ElasticsearchService;
use SCS\Osdb\Classes\Services\MisoSearchService;

class ESModel
{
    public static function listByIds($ids, $source = null)
    {
        $body = [
            "query" => [
                "ids" => [
                    "type" => "_doc",
                    "values" => $ids
                ]
            ]
        ];
        if ($source) {
            $body["_source"] = $source;
        }

        $result = ElasticsearchService::instance()->search(static::$index, $body, null);
        usort($result->items, function($a, $b) use ($ids) {
            $indexA = array_search($a['id'], $ids);
            $indexB = array_search($b['id'], $ids);
            if ($indexA == $indexB) return 0;
            return ($indexA < $indexB) ? -1 : 1;
        });
        return $result;
    }

    public static function list($limit = null, $fields = null)
    {
        $result = ElasticsearchService::instance()->all(static::$index, $limit, $fields);
        // \Log::info('~~ ES->list - result count: '.count($result), ['count#'=>count($result)]);
        return $result;
    }

    public static function count()
    {
        $result = ElasticsearchService::instance()->count(static::$index);
        return $result;
    }

    public static function addAndTerm(&$body, $fieldName, $fieldValue)
    {
        if (!empty($fieldValue))
        {
            if(empty($body['query']['bool'])) $body['query']['bool'] = ['filter' => []];
            $body['query']['bool']['filter'][] = [(is_array($fieldValue) ? 'terms' : 'term') => [$fieldName => $fieldValue]];
        }
    }

    public static function getById($id)
    {
        $result = ElasticsearchService::instance()->get(static::$index, $id);
        return $result;
    }
}
