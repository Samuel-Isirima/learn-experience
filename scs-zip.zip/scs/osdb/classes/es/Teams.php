<?php namespace SCS\Osdb\Classes\ES;

use OFFLINE\SiteSearch\Models\Settings;
use SCS\Osdb\Classes\Services\ElasticsearchService;
use SCS\Osdb\Classes\Services\MisoSearchService;

class Teams extends ESModel
{
    public static $index = 'teams';
    protected static $indexTeamSeasons = 'teamseasons';
    protected static $indexPlayers = 'players';

    public static function leagueTeams($leagueAlias, $fields)
    {
        $result = ElasticsearchService::instance()->filterCollection(static::$index,
            ['league.alias' => strtoupper($leagueAlias)], null, $fields);
        return $result;
    }

    public static function get($alias)
    {
        $result = null;
        $response = ElasticsearchService::instance()->filterCollection(static::$index, ['alias' => $alias]);
        if ($response && count($response) > 0) {
            $result = $response[0];
        }
        return $result;
    }

    public static function getById($id)
    {
        $result = ElasticsearchService::instance()->get(static::$index, $id);
        return $result;
    }

    public static function getConferenceTeamsRanked($seasonYear, $seasonType, $league, $conference, $fields)
    {
        $body = [
            "query" => [
                "bool" => [
                    "filter" => [
                        ["term" => ["season.year" => "$seasonYear"]],
                        ["term" => ["season.type" => strtoupper($seasonType)]],
                        ["term" => ["league.alias" => strtoupper($league)]],
                        ["term" => ["conference.id" => $conference]],
                        ["exists" => ["field" => "rank.division" ]]
                    ]
                ]
            ],
            "sort" => [
                "rank.division" => [
                    "order" => "asc",
                    "missing" => "_last",
                    "mode" => "max",
                    "unmapped_type" => "long"
                ]
            ]
        ];
        $result = ElasticsearchService::instance()->search(static::$indexTeamSeasons, $body, null, $fields);
        return isset($result) ? $result->items : null;
    }

    public static function getConferenceTeams($conference, $fields)
    {
        $body = [
            "query" => [
                "bool" => [
                    "filter" => [
                        ["term" => ["conference.id" => $conference]]
                    ]
                ]
            ]
        ];
        $result = ElasticsearchService::instance()->search(static::$index, $body, null, $fields);
        return isset($result) ? $result->items : null;
    }

    public static function search($searchString, $limit)
    {
        $misoId = null;
        $misoEnabled = Settings::get('miso_enabled', false);
        if ($misoEnabled)
            $result = self::searchMiso($searchString, $limit, $misoId);
        else
            $result = self::searchByFullName($searchString, $limit);
        MisoSearchService::instance()->sendSearchToMiso($searchString, $misoId);
        return $result;
    }

    public static function searchMiso($searchString, $limit, &$misoId)
    {
        $misoResult = MisoSearchService::instance()->search($searchString, "teams", $limit);
        if (null === $misoResult || empty($misoResult->miso_id)) {
            return [];
        }
        $misoId = $misoResult->miso_id;
        $ids = [];

        // split on autocomplete and search results
        if (property_exists($misoResult, 'products') && count($misoResult->products) > 0) {
            foreach ($misoResult->products as $item) {
                $ids[] = $item->product_id;
            }
        } else if (property_exists($misoResult, 'completions') && count($misoResult->completions->title) > 0) {
            foreach ($misoResult->completions->title as $item) {
                $ids[] = $item->product->product_id;
            }
        }

        $result = self::listByIds($ids, ["excludes" => ["players"]]);
        return $result;
    }

    public static function searchByFullName($searchString, $limit = null)
    {
        $jsonQuery = [
            "query" => [
                "match" => [
                    "full_name" => "$searchString"
                ]
            ],
            "_source" => [
                "excludes" => ["players"]
            ]
        ];
        $result = ElasticsearchService::instance()->search(static::$index, $jsonQuery, $limit);
        return $result;
    }

    public static function getBySlug($slug, $limit = null)
    {
        $jsonQuery = [
            "query" => [
                "bool" => [
                    "filter" => [
                        ["term" => ["slug" => "$slug"]],
                    ]
                ]
            ]
        ];
        $result = ElasticsearchService::instance()->search(static::$index, $jsonQuery, $limit);
        if ($result->items && count($result->items) > 0) return $result->items[0];
        return null;
    }

    public static function getTeamByWidgetTeamId($id)
    {

        if (str_starts_with($id, 'sd:team:')) {
            // if NFL
            $id = str_replace('sd:team:', '', $id);
            
            $jsonQuery = [
                "query" => [
                    "match" => [
                        "id" => $id
                    ]
                ]
            ];
            $result = ElasticsearchService::instance()->search(static::$index, $jsonQuery, 1);

        } else {
            
            $jsonQuery =   '{ "query": {
                "bool": { "filter": { "term":{"team_id":'. $id .'} }}
            }}';
            $result = ElasticsearchService::instance()->search(static::$index, json_decode($jsonQuery), 1);
        }

        if ($result->items && count($result->items) > 0) return $result->items[0];
        return null;
    }

    public static function getDraftTeamsByYear($filterByLeague, $filterByYear)
    {
        $body = [
            'query' => []
        ];
        ESModel::addAndTerm($body, 'league.alias', strtoupper($filterByLeague));
        ESModel::addAndTerm($body, 'draft.year', $filterByYear);
        $response = ElasticsearchService::instance()->aggregation(static::$indexPlayers, $body, 'draft.team_id');
        $result = [];
        $teams = self::leagueTeams($filterByLeague, ['id', 'name', 'market', 'alias', 'full_name', 'slug']);
        foreach ($response as $item) {
            $id = $item['key'];
            $i = array_search($id, array_column($teams, 'id'));
            $team = ($i !== false ? $teams[$i] : null);
            if (isset($team)) $result[] = $team;
        }

        return $result;
    }
}
