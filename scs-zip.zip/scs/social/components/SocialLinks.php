<?php namespace SCS\Social\Components;

use Cms\Classes\ComponentBase;
use SCS\Osdb\Models\Player;
use SCS\Osdb\Models\Team;

class SocialLinks extends ComponentBase
{
    public $type;
    public $slug;
    public $displaymode;
    
    public $social_links = [];

    public $youtube_link;
    public $twitter_link;
    public $facebook_link;
    public $instagram_link;
    public $cameo_link;
    public $twitch_link;
    public $tiktok_link;


    public function componentDetails()
    {
        return [
            'name' => 'Social Links Component',
            'description' => 'Links for given social accounts.'
        ];
    }

    public function defineProperties()
    {
        return [
            'type' => [
                'title' => 'league, team or player',
                'description' => '',
                'type' => 'string'
            ],
            'slug' => [
                'title' => 'League, team or player slug',
                'description' => '',
                'type' => 'string'
            ],
        ];
    }

    public function onRender()
    {

        $this->type = $this->property('type');
        $this->slug = $this->property('slug');
        $this->displaymode = $this->property('displaymode');

        // pdrinnan - Aug 26 2021 
        // this is a hack until we get the social links tab in the league editor page
        $leagueSlugs = ['mlb', 'mls', 'nba', 'nfl', 'nhl'];
        $leagues = [];
        foreach ($leagueSlugs as $leagueSlug) {
            $leagues[$leagueSlug] = new \stdClass();
            $leagues[$leagueSlug]->social_links['facebook'] = $leagueSlug;
            $leagues[$leagueSlug]->social_links['instagram'] = $leagueSlug;
            $leagues[$leagueSlug]->social_links['twitter'] = $leagueSlug;
            $leagues[$leagueSlug]->social_links['youtube'] = $leagueSlug;
        }

        switch ($this->type) {
        case 'league':
            $this->setSocialLinks($leagues[$this->slug]);
            break;
        case 'team':
            $team = $this->page['record'] ?? Team::where('slug', $this->slug)->first();
            $this->setSocialLinks($team);
            break;
        case 'player':
            $player = $this->page['record'] ?? Player::where('guid', $this->slug)->first();
            $this->setSocialLinks($player);
            break;
        }
    }

    private function setSocialLinks($object)
    {
        foreach ([
                'twitter_link' => 'twitter',
                'facebook_link' => 'facebook',
                'instagram_link' => 'instagram',
                'youtube_link' => 'youtube',
                'cameo_link' => 'cameo',
                'twitch_link' => 'twitch',
                'tiktok_link' => 'tiktok',
        ] as $key => $value) {
            if (is_string($object) && !empty($object)) {
                $this->social_links[$value] = $this->{$key} = $object;
            } else {
                try {
                    if (!empty($object->social_links[$value])) {
                        $this->social_links[$value] = $this->{$key} = $object->social_links[$value];
                    }
                } catch (\Exception $e) {
                }
            }
        }
    }
}
