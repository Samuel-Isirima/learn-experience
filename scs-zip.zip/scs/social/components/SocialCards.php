<?php namespace SCS\Social\Components;

use Cms\Classes\ComponentBase;
use SCS\Osdb\Models\League;
use SCS\Osdb\Models\Player;
use SCS\Osdb\Models\Team;
use SCS\Social\Classes\TwitterAPI;

class SocialCards extends ComponentBase
{
    public $type;
    public $slug;
    public $object;
    public $tweets;
    public $user;

    public function componentDetails()
    {
        return [
            'name' => 'Social Cards Component',
            'description' => 'shows Twitter feed for provided handle'
        ];
    }

    public function defineProperties()
    {
        return [
            'type' => [
                'title' => 'league, team, player or user',
                'description' => '',
                'type' => 'string'
            ],
            'slug' => [
                'title' => 'League, team or player slug',
                'description' => '',
                'type' => 'string'
            ],
        ];
    }

    public function onRender()
    {
        $username = null;
        $this->type = $this->property('type');
        $this->slug = $this->property('slug');
        switch ($this->type) {
            case 'league':
                $this->object = $this->page['record'] ?? League::where('slug', $this->slug)->first();
                try {
                    $username = $this->object->slug;
                } catch (\Exception $e) {
                }
                break;
            case 'team':
                $this->object = $this->page['record'] ?? Team::where('slug', $this->slug)->first();
                try {
                    $username = $this->object->social_links['twitter'];
                } catch (\Exception $e) {
                }
                break;
            case 'player':
                if (isset($this->page['record'])) {
                    $this->object = $this->page['record'];
                } else {
                    $this->object = Player::where('guid', $this->slug)->first();
                    if (isset($this->object)) {
                        $this->object->extendWithESData();
                    }
                }
                try {
                    $username = $this->object->social_links['twitter'];
                } catch (\Exception $e) {
                }
                break;
            default:
                $username = $this->slug;
        }
        if (!empty($username)) {
            $tweets = (new TwitterAPI())->getTweets($username);
            if (!empty($tweets)) {
                $tweets = json_decode($tweets);
                if (!empty($tweets->data)) {
                    $this->tweets = [];
                    $max = 6;
                    $data = array_slice($tweets->data, 0, $max);
                    $utcNow = date_create(gmdate("Y-m-d H:i:s"));
                    foreach ($data as $tweet) {
                        $text = $tweet->text;
                        $link = "https://twitter.com/$username/status/$tweet->id";
                        $age = date_diff(date_create($tweet->created_at), $utcNow);
                        $this->tweets[] = [
                            'text' => $text,
                            'link' => $link,
                            'age' => $age
                        ];
                    }
                    $this->user = $tweets->includes->users[0];
                    $this->user->url = "http://twitter.com/$username";
                }
            }
        }
    }
}
