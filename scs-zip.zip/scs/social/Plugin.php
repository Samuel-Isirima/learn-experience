<?php namespace SCS\Social;

use Backend;
use System\Classes\PluginBase;

class Plugin extends PluginBase
{

    /*

    TODO:
        - register API keys
        - possible override on account passed in
        - implement into site fully

    */
    public function pluginDetails()
    {
        return [
            'name'        => 'Social',
            'description' => 'Shows social feeds',
            'author'      => 'SCS',
            'icon'        => 'icon-comment-o'
        ];
    }

    public function register() {}

    public function boot() {}

    public function registerComponents()
    {
        return [
            'SCS\Social\Components\SocialCards' => 'socialCards',
            'SCS\Social\Components\SocialLinks' => 'socialLinks',
        ];
    }

    public function registerPermissions()
    {
        return [];
    }

    public function registerNavigation()
    {
        return [];
    }
}
