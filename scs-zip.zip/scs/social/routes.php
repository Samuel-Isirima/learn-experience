<?php

use Illuminate\Support\Facades\App;
use SCS\Social\Classes\TwitterAPI;

Route::get('api/get-tweets', function () {
    $user = $_REQUEST['user'];
    $tweets = (new TwitterAPI())->getTweets($user);
    if ($tweets === false) {
        App::abort(500, 'Twitter API error');
    }
    return $tweets;
});