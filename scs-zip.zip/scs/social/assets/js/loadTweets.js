window.SCS_Social = window.SCS_Social || {};

/*
    see: https://www.tweetjs.com
*/

SCS_Social = {
    handle: "",
	loadTweets: function (handle, selector) {
        TweetJs.ListTweetsOnUserTimeline(handle, (data) => {this.parseTweets(data,selector)});
    },
    parseTweets: function (data,selector) {
        tweetcards = document.querySelectorAll(selector);
        tweetcards.forEach((card,i) => {
            // console.log(data[i]);
            card.querySelector('.social-img img').src = data[i].user.profile_image_url_https;
            card.querySelector('.social-acct-name').innerHTML = data[i].user.name;
            card.querySelector('.social-acct-handle').innerHTML = '@'+data[i].user.screen_name;
            card.querySelector('.social-timestamp').innerHTML = data[i].created_at; //TODO: does this need to have an extra calc applied to create time offest?
            card.querySelector('.social-text').innerHTML = data[i].text;
        });
    }
};

document.addEventListener('DOMContentLoaded', function() {
    // console.debug('SCS_Social loaded');
    SCS_Social.handle = document.querySelector('[data-twitter-handle]').dataset.twitterHandle;

    if (SCS_Social.handle) {
        SCS_Social.loadTweets(SCS_Social.handle, '.social-tweetcard');
    }
}, false);
