<?php namespace SCS\Social\Classes;

use GuzzleHttp\Client;

class TwitterAPI
{
    private $apiKey = 'lwKywQ6IduQkcnHoT5bIRhKyz';
    private $secretKey = 'NfcGvdUI6AxE8ZC1SPrQnK4tUrgjkXpTZ9MBcXbzDl49NJI5TT';
    private $bearerToken = 'AAAAAAAAAAAAAAAAAAAAAJC%2BMgEAAAAAYzc5r8BSWBcYtdq4AYdKKhfX828%3DIzig8JXzPLemmmMFMqlWtoy8uUdkR0opapfo1FbGKfkqgZ4QYs';

    public function getTweets($user, $limit = 10)
    {
        // TODO: re-enable after fixing 403 from this request
        return false;
//        $client = new Client();
//        try {
//            $response = $client->request('GET', 'https://api.twitter.com/2/tweets/search/recent', [
//                'query' => [
//                    'query' => "from:$user -is:reply",
//                    'max_results' => $limit,
//                    'tweet.fields' => 'id,text,created_at',
//                    'expansions' => 'author_id',
//                    'user.fields' => 'url,username'
//                ],
//                'headers' => ['Authorization' => "Bearer $this->bearerToken"]
//            ]);
//        } catch (\Exception $e) {
//            \Log::error('Twitter API error: ' . $e->getMessage(). " [".$e->getTraceAsString()."]");
//            return false;
//        }
//        return $response->getBody()->getContents();
    }
}
