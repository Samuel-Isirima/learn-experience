<?php

namespace SCS\NewsAPI;

use Backend;
use Event;
use SCS\NewsAPI\Classes\StaticMenu\StaticMenuExtensions;
use System\Classes\PluginBase;
use System\Classes\PluginManager;
use RainLab\Blog\Models\Post;
use SCS\NewsAPI\Models\Article;
use RainLab\Blog\Controllers\Posts as PostsController;

class Plugin extends PluginBase
{
    public $require = ['RainLab.Blog'];

    public function pluginDetails()
    {
        return [
            'name'        => 'NewsAPI',
            'description' => 'News API',
            'author'      => 'SCS',
            'icon'        => 'icon-newspaper-o'
        ];
    }

    public function boot()
    {

        /*
        \GinoPane\BlogTaxonomy\Models\Series::extend(function ($model) {
            // $model->hasMany['article_seriesx'] = ['SCS\NewsAPI\Models\ArticleSeries', 'key'=>'ginopane_blogtaxonomy_series_id'];
            // $model->belongsToMany = [ 'article_seriesx' => ['SCS\NewsAPI\Models\ArticleSeries'] ];
        });
        */

        // Check for Rainlab.Blog plugin
        $pluginManager = PluginManager::instance()->findByIdentifier('Rainlab.Blog');

        if (class_exists('\RainLab\Blog\Models\Post')) {

            \RainLab\Blog\Models\Post::extend(function ($model) {
                $model->hasOne['article'] = [
                    'SCS\NewsAPI\Models\Article',
                    'delete' => 'true', // also delete the record for the article
                    'key' => 'post_id', 'otherKey' => 'id' // relate article->post_id to post->id
                ];

                /*
                    this adds the Article fields to the Post's form widget at render,
                    this is instead of using the `extendFormFields` on the Posts
                    controller (see below) -RWC
                */
                Event::listen('backend.form.extendFields', function ($widget) {
                    // if not the Posts controller then exit
                    if (!$widget->getController() instanceof \RainLab\Blog\Controllers\Posts) {
                        return;
                    }
                    // if not a Post model then exit
                    if (!$widget->model instanceof \RainLab\Blog\Models\Post) {
                        return;
                    }
                    // if model does not exist then exit
                    if (!$widget->model->exists) {
                        return;
                    }

                    $widget->addFields([
                        'toolbar' => [
                            'type' => 'partial',
                            'path' => '$/scs/newsapi/partials/_post_toolbar.htm', // << updated tool bar - include preview always
                            'cssClass' => 'collapse-visible'
                        ],

                    ]);

                    $widget->addSecondaryTabFields([

                        'content' => [
                            'tab' => 'rainlab.blog::lang.post.tab_edit',
                            'type' => 'richeditor', // << was 'RainLab\Blog\FormWidgets\BlogMarkdown',
                            'toolbarButtons' => 'undo,redo,clearFormatting,selectAll,|,insertLink,insertImage,insertVideo,insertAudio,insertFile,insertTable,html,-,paragraphFormat,bold,italic,underline,|,align,formatOL,formatUL,|,quote,insertHR,fullscreen',
                            // excluded:strikeThrough,subscript,superscript,fontFamily,fontSize,color,inlineStyle,paragraphStyle,outdent,indent,emoticons
                            'stretch' => 'true',
                            'mode' => 'split',
                        ],
                        'featured_images' => [
                            'tab' => 'rainlab.blog::lang.post.tab_manage',
                            'label' => 'rainlab.blog::lang.post.featured_images',
                            'type' => 'fileupload',
                            'mode' => 'image', 'fileTypes' => 'jpg,jpeg,png,gif,svg', 'useCaption' => 'true',
                            'maxFilesize' => '2', 'attachOnUpload' => 'true',
                            'trigger' => [
                                'action' => 'hide',
                                'field' => 'article[use_image]',
                                'condition' => 'checked',
                            ]
                        ],
                        'published_at' => [
                            'tab' => 'rainlab.blog::lang.post.tab_manage',
                            'label' => 'rainlab.blog::lang.post.published_on',
                            'span' => 'left',
                            'cssClass' => 'checkbox-align',
                            'type' => 'datepicker',
                            'mode' => 'datetime',
                            'ignoreTimezone' => true,
                            'trigger' => [
                                'action' => 'enable',
                                'field' => 'published',
                                'condition' => 'checked',
                            ]
                        ],
                        'user' => [
                            'tab' => 'rainlab.blog::lang.post.tab_manage',
                            //'label'=> 'Admin User', //'rainlab.blog::lang.post.published_by',
                            'comment' => '(admin user editing this post, use Author field instead)',
                            'span' => 'right',
                            'type' => 'relation',
                            'nameFrom' => 'login',
                            'readOnly' => 'true',
                            'default' => 'rainlab.blog::lang.post.current_user',
                            'emptyOption' => 'rainlab.blog::lang.post.current_user'
                        ],


                        'article[author]' => [
                            'tab' => 'rainlab.blog::lang.post.tab_manage',
                            'label' => 'Author',
                            'span' => 'left',
                            'type' => 'text',
                        ],
                        'article[url]' => [
                            'tab' => 'rainlab.blog::lang.post.tab_manage',
                            'label' => 'Link to full article',
                            'span' => 'auto',
                            'type' => 'text',
                            //'disabled'=>'1',
                            'readOnly' => 'true'
                        ],

                        'article[image_anchor_vert]' => [

                            'label' => 'Hero image: vertical image anchor',
                            'tab' => 'rainlab.blog::lang.post.tab_manage',
                            'span' => 'left',
                            'type' => 'dropdown',
                            'default' => 'center',
                            'options' => [

                                'center' => 'center',
                                'top' => 'top',
                                'bottom' => 'bottom',
                            ],
                        ],
                        'article[image_anchor_horiz]' => [

                            'label' => 'Hero image: horizontal image anchor',
                            'tab' => 'rainlab.blog::lang.post.tab_manage',
                            'span' => 'right',
                            'type' => 'dropdown',
                            'default' => 'center',
                            'options' => [

                                'center' => 'center',
                                'right' => 'right',
                                'left' => 'left',
                            ],
                        ],

                        'article[image_url]' => [
                            'tab' => 'rainlab.blog::lang.post.tab_manage',
                            'label' => 'External Image',
                            'commentAbove' => '(image from the NewsAPI article)',
                            'span' => 'auto',
                            'type' => 'partial',
                            'path' => '$/scs/newsapi/models/article/external_image.htm',
                        ],
                        'article[use_image]' => [
                            'tab' => 'rainlab.blog::lang.post.tab_manage',
                            'label' => 'Use external image',
                            'span' => 'auto',
                            'type' => 'switch'
                        ],
                        'article[id]' => [
                            'tab' => 'rainlab.blog::lang.post.tab_manage',
                            'label' => 'Related article',
                            'commentAbove' => '(click to edit the NewsAPI article)',
                            'span' => 'auto',
                            'type' => 'partial',
                            'path' => '$/scs/newsapi/models/article/edit_article.php',
                        ],

                        /*
                            I am super tired and this doesn't work - it will need to wait until later to get fixed...

                            'article[hm_article_series]' => [
                                'label'=> 'ginopane.blogtaxonomy::lang.form.fields.related_series',
                                // 'type'=> 'relation',
                                'type'=> 'checkboxlist',
                                // 'type'=> 'partial',
                                // 'path'=> '$/scs/newsapi/partials/relatedseries/default.php',
                                'tab'=> 'ginopane.blogtaxonomy::lang.navigation.taxonomy',
                            ],
                        */
                    ]);

                    // $widget->removeField('series');
                    // $widget->addSecondaryTabFields([
                    //     'series' => [
                    //         'label' => 'ginopane.blogtaxonomy::form.series.label' . '***',
                    //         'tab' => 'Taxonomy',
                    //         'type' => 'relation',
                    //         'nameFrom' => 'title',
                    //         'comment' => 'ginopane.blogtaxonomy::form.series.comment' . '***',
                    //         // October CMS has a bug with displaying of placeholders without an explicit empty option
                    //         // https://github.com/octobercms/october/pull/4060
                    //         'placeholder' => 'ginopane.blogtaxonomy::placeholders.series' . '***',
                    //         'emptyOption' => 'ginopane.blogtaxonomy::placeholders.series' . '***'
                    //     ],
                    // ]);

                });

                Event::listen('backend.list.extendColumns', function ($widget) {
                    // if not the Posts controller then exit
                    if (!$widget->getController() instanceof \RainLab\Blog\Controllers\Posts) {
                        return;
                    }
                    // if not a Post model then exit
                    if (!$widget->model instanceof \RainLab\Blog\Models\Post) {
                        return;
                    }

                    $widget->addColumns([
                        'published' => [
                            'label' => 'Published?',
                            'type' => 'switch',
                        ],
                        'series' => [
                            'label' => 'Main Series',
                            'relation' => 'series',
                            'path' => '$/scs/newsapi/models/articleseries/main_series.php',
                            'type' => 'partial',
                            'sortable' => true
                        ],
                        'id' => [
                            'label' => 'id',
                            'type' => 'number',
                            'sortable' => true
                        ],
                        'article[id]' => [
                            'label' => 'article_id',
                            'type' => 'number',
                            'sortable' => true
                        ],
                        'article[source]' => [
                            'label' => 'source',
                            'type' => 'text',
                        ],
                        'article[author]' => [
                            'label' => 'author',
                            'type' => 'text',
                        ],
                        'article[image_url]' => [
                            'label' => 'Image',
                            'type' => 'partial',
                            'path' => '$/scs/newsapi/models/article/preview_image.php',
                            'sortable' => 'false',
                            'searchable' => 'false',
                            'width' => '150px'
                        ]
                    ]);
                });

                /*
                    on save of the Post model we check if there is a related
                    Article model, if not add it, then we fill the post_id to
                    match the new Post - RWC
                */
                $model->bindEvent('model.afterSave', function () use ($model) {
                    if (!$model->article) {
                        $sessionKey = uniqid('session_key', true);
                        $article = new Article;
                        $model->article = $article;
                    }
                    $model->article->post_id = $model->id;
                    $model->article->save();
                });
            });

            // PostsController::extendFormFields(function ($form, $model) {
            //     if ($form->arrayName !== "Post") {
            //         return;
            //     } else {
            //     }
            // });
        }
    }

    public function registerReportWidgets()
    {
        return [];
    }

    public function registerComponents()
    {
        return [];
    }

    public function registerPermissions()
    {
        return [
            'scs.newsapi.access' => [
                'label' => 'Access and Search using NewsAPI.',
                'tab' => 'News API',
                'roles' => ['developer','publisher']
            ],
            'scs.newsapi.domains' => [
                'label' => 'Control the search domains for NewsAPI.',
                'tab' => 'News API',
                'roles' => ['developer']
            ],
        ];
    }

    public function registerNavigation()
    {
        return [
            'main-menu-newsapi' => [
                'label'       => 'News API',
                'url'         => Backend::url('scs/newsapi/article'),
                'icon'        => 'icon-rss',
                'permissions' => ['scs.newsapi.*'],
                'order'       => 301,
                'sideMenu' => [
                    'side-menu-sources' => [
                        'label' => 'News API Sources',
                        'icon'        => 'icon-list-ul',
                        'url'         => Backend::url('scs/newsapi/domain'),
                        'permissions' => ['scs.newsapi.domains'],
                    ],
                    'side-menu-article' => [
                        'label' => 'News API Articles Import',
                        'icon'        => 'icon-rss',
                        'url'         => Backend::url('scs/newsapi/article'),
                    ],
                ]
            ],
        ];
    }
}
