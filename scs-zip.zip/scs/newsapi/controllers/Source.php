<?php namespace SCS\NewsAPI\Controllers;

use Backend\Classes\Controller;
use BackendMenu;

class Source extends Controller
{

    public $requiredPermissions = ['scs.newsapi.domains'];

    public $implement = [        'Backend\Behaviors\ListController',        'Backend\Behaviors\FormController'    ];

    public $listConfig = 'config_list.yaml';
    public $formConfig = 'config_form.yaml';

    public function __construct()
    {
        parent::__construct();
        BackendMenu::setContext('SCS.NewsAPI', 'main-menu-newsapi', 'side-menu-sources');
    }
}
