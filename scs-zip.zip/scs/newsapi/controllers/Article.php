<?php namespace SCS\NewsAPI\Controllers;

use BackendMenu;
use Input;
use Backend;
use Backend\Classes\Controller;
use SCS\NewsAPI\Models\Article as ArticleModel;
use SCS\NewsAPI\Widgets\NewsList;

class Article extends Controller
{
    public $formConfig = 'config_form.yaml';
    public $listConfig = 'config_list.yaml';

    public $implement = [
        'Backend.Behaviors.FormController',
        'Backend.Behaviors.ListController',
    ];

    public function __construct()
    {
        parent::__construct();
        $this->addJs('/modules/backend/widgets/form/assets/js/october.form.js');
        BackendMenu::setContext('SCS.NewsAPI', 'main-menu-newsapi', 'side-menu-article');

        $newsList = new NewsList($this);
        $newsList->alias = 'newsList';
        $newsList->bindToController();
    }

    public function index()
    {
        $this->bodyClass = 'container-fluid';
        $this->makeLists();
    }

    // public function update($recordId, $context = null)
    // {
    //     // $model = $this->formFindModelObject($recordId);
    //     $model = ArticleModel::where('id',$recordId)->first();
    //     $this->pageTitle = "article: " . $recordId .  " post_id: " . $model->post_id;
    //     $this->initForm($model);
    // }

}
