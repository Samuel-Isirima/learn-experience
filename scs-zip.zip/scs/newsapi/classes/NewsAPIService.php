<?php namespace SCS\NewsAPI\Classes;

class NewsAPIService
{
    public static function getNewsList($query, $domains, $from, $to, $limit = false)
    {
        $url = "https://newsapi.org/v2/everything";
        // TODO: move to settings
        $headers = ["X-Api-Key" => "1cb85921b065405bb3438f36d8a7de65"];
        $data = [
            "language" => 'en',
            "q" => urlencode($query)
        ];
        if ($domains) $data['domains'] = $domains;
        if ($from) $data['from'] = $from;
        if ($to) $data['to'] = $to;

        $result = [];
        if ($limit && $limit <= 100) {
            $data['pageSize'] = $limit;
            $response = self::callAPI("GET", $url, $headers, $data);
            if ($response->status == 'ok') return $response->articles;
            return null;
        } else {
            $total = null;
            $size = 50;
            $page = 1;
            $fetched = 0;
            while ($total === null || $fetched <= $total){
                $data['pageSize'] = $size;
                $data['page'] = $page;
                $response = self::callAPI("GET", $url, $headers, $data);
                if ($response->status == 'ok') {
                    if ($total - $fetched < $size && count($result) < $total - $fetched) {
                        $result = array_slice($result, 0, $total - $fetched);
                    }
                    $result = array_merge($result, $response->articles);
                } else return null;
                $total = $response->totalResults;
                if ($limit) $total = min($limit, $total);
                $page++;
                $fetched += $size;
            }
        }


        return $result;
    }

    static function callAPI($method, $url, $headers = false, $data = false)
    {
        $curl = curl_init();

        switch ($method)
        {
            case "POST":
                curl_setopt($curl, CURLOPT_POST, 1);

                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            case "PUT":
                curl_setopt($curl, CURLOPT_PUT, 1);
                break;
            default:
                if ($data)
                    $url = sprintf("%s?%s", $url, http_build_query($data));
        }

        if ($headers){
            $header = [];
            foreach ($headers as $key => $value) {
                $header[] = "{$key}: {$value}";
            }
            curl_setopt($curl,CURLOPT_HTTPHEADER, $header);
        }

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

        $response = curl_exec($curl);

        curl_close($curl);

        $result = json_decode($response);

        return $result;
    }
}
