<?php namespace SCS\NewsAPI\Classes\StaticMenu;

use Event;
use SCS\NewsAPI\Classes\StaticMenu\MenuItemTypes\ArticleMenuItemType;
use SCS\NewsAPI\Classes\StaticMenu\MenuItemTypes\DomainMenuItemType;

class StaticMenuExtensions
{
    static function initialize()
    {
        $menuItemTypes = [];
        foreach ([
                     new ArticleMenuItemType(),
                     new DomainMenuItemType(),
                 ]
                 as $type) {
            $menuItemTypes[$type->getId()] = $type;
        }
        Event::listen('pages.menuitem.listTypes', function () use ($menuItemTypes) {
            return array_map(function ($type) {
                return $type->getName();
            }, $menuItemTypes);
        });
        Event::listen('pages.menuitem.getTypeInfo', function ($type) use ($menuItemTypes) {
            if (array_key_exists($type, $menuItemTypes)) {
                return $menuItemTypes[$type]->getTypeInfo();
            }
        });
        Event::listen('pages.menuitem.resolveItem', function ($type, $item, $url, $theme) use ($menuItemTypes) {
            if (array_key_exists($type, $menuItemTypes)) {
                return $menuItemTypes[$type]->resolveItem($item, $url, $theme);
            }
        });
    }
}