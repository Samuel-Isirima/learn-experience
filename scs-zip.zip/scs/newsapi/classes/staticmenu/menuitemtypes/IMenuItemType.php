<?php namespace SCS\NewsAPI\Classes\StaticMenu\MenuItemTypes;

interface IMenuItemType
{
    function getId();

    function getName();

    function getTypeInfo();

    function resolveItem($item, $url, $theme);
}