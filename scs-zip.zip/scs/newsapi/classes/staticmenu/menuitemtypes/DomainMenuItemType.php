<?php namespace SCS\NewsAPI\Classes\StaticMenu\MenuItemTypes;

use Cms\Classes\Page as CmsPage;
use Cms\Classes\Theme;
use Illuminate\Support\Facades\URL;
use SCS\NewsAPI\Models\Domain;

class DomainMenuItemType implements IMenuItemType
{
    function getId()
    {
        return 'newsapi-domain';
    }

    function getName()
    {
        return 'NewsAPI Domain';
    }

    function getTypeInfo()
    {
        return [
            'dynamicItems' => 0,
            'nesting' => 0,
            'references' => Domain::all()->mapWithKeys(function ($it) {
                return [$it->id => $it->domain];
            }),
            'cmsPages' => [
                CmsPage::load(Theme::getActiveTheme(), 'domain')
            ]
        ];
    }

    function resolveItem($item, $url, $theme)
    {
        return ['isActive' => 0, 'url' => URL::to('domain/' . $item->reference)];
    }
}