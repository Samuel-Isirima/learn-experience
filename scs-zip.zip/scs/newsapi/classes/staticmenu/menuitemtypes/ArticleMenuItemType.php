<?php namespace SCS\NewsAPI\Classes\StaticMenu\MenuItemTypes;

use Cms\Classes\Page as CmsPage;
use Cms\Classes\Theme;
use Illuminate\Support\Facades\URL;
use SCS\NewsAPI\Models\Article;

class ArticleMenuItemType implements IMenuItemType
{
    function getId()
    {
        return 'newsapi-article';
    }

    function getName()
    {
        return 'NewsAPI Articles';
    }

    function getTypeInfo()
    {
        return [
            'dynamicItems' => 0,
            'nesting' => 0,
            'references' => Article::all()->mapWithKeys(function ($it) {
                return [$it->id => $it->name];
            }),
            'cmsPages' => [
                CmsPage::load(Theme::getActiveTheme(), 'article')
            ]
        ];
    }

    function resolveItem($item, $url, $theme)
    {
        return ['isActive' => 0, 'url' => URL::to('article/' . $item->reference)];
    }
}