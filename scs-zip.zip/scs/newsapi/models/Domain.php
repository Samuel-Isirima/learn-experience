<?php namespace SCS\NewsAPI\Models;

use Model;

/**
 * Model
 */
class Domain extends Model
{
    use \October\Rain\Database\Traits\Validation;

    public $table = 'scs_newsapi_domains';
    public $primaryKey = 'id';
    public $incrementing = true;

    /**
     * @var array Validation rules
     */
    public $rules = [];
}
