<?php namespace SCS\NewsAPI\Models;

use Model;
use ApplicationException;
use Exception;
use RainLab\Blog\Models\Post;

/**
 * Article Model
 */
class Article extends Model
{
    use \October\Rain\Database\Traits\Validation;

    /**
     * @var string The database table used by the model.
     */
    public $table = 'scs_newsapi_articles';

    /**
     * @var array Guarded fields
     */
    protected $guarded = ['*'];

    /**
     * @var array Fillable fields
     */
    protected $fillable = [];

    /**
     * @var array Validation rules for attributes
     */
    public $rules = [];

    /**
     * @var array Attributes to be cast to native types
     */
    protected $casts = [];

    /**
     * @var array Attributes to be cast to JSON
     */
    protected $jsonable = [];

    /**
     * @var array Attributes to be appended to the API representation of the model (ex. toArray())
     */
    protected $appends = [];

    /**
     * @var array Attributes to be removed from the API representation of the model (ex. toArray())
     */
    protected $hidden = [];

    /**
     * @var array Attributes to be cast to Argon (Carbon) instances
     */
    protected $dates = [
        'created_at',
        'updated_at'
    ];

    /**
     * @var array Relations
     */
    public $hasOne = [

    ];
    public $hasMany = [
        'hm_article_series' => ['SCS\NewsAPI\Models\ArticleSeries',
            'table' => 'scs_newsapi_article_series',
            'key' => 'article_id',
        ],
        'posts' => [
            RainLab\Blog\Models\Post::class,
            'key' => "post_id"
        ],

    ];
    public $belongsTo = [
        // relate article->post_id to post->id
        'post' => ['RainLab\Blog\Models\Post', 'key' => 'post_id', 'otherKey' => 'id'],
        'slug' => ['RainLab\Blog\Models\Post'],
        // todo: add other fields here? like "title"?


    ];
    public $belongsToMany = [
    ];

    public $hasManyThrough = [
        'series' => [
            'GinoPane\BlogTaxonomy\Models\Series', 'key' => 'id',
            'through' => 'SCS\NewsAPI\Models\ArticleSeries',
            'throughKey' => 'article_id',
            'otherKey' => 'series_id'
        ],
    ];

    public $morphTo = [];
    public $morphOne = [];
    public $morphMany = [

    ];
    public $attachOne = [];
    public $attachMany = [

    ];

    public function getForeignKey()
    {
        return 'post_id';
    }

    public function afterSave() {
        // save out the realted series
        /*
            it is 3 am and I am very tired, this may be some of the worst code I have ever written...
        */

        /* not working correctly - wil need to fix in future...

        $hasManyArticleSeries = $_POST['Post']['article']['hm_article_series'];
        if ($hasManyArticleSeries && count($hasManyArticleSeries) > 0) {
            foreach ($hasManyArticleSeries as $i => $series_id) {
                $_get_series = \GinoPane\BlogTaxonomy\Models\Series::where('id', $series_id)->first();
                $_findRecord = \SCS\NewsAPI\Models\ArticleSeries::where('article_id', '=', $this->id)->where('series_id', '=', $_get_series->id)->first();
                if (null === $_findRecord) {
                    \SCS\NewsAPI\Models\ArticleSeries::create([
                    'article_id' => $this->id,
                    'series_id' => $_get_series->id,
                    'series_slug' => $_get_series->slug
                ]);
                } else {
                    \SCS\NewsAPI\Models\ArticleSeries::where('article_id', '=', $this->id)->where('series_id', '=', $_get_series->id)->first()->update([
                    'article_id' => $this->id,
                    'series_id' => $_get_series->id,
                    'series_slug' => $_get_series->slug
                ]);
                }
            }
        }
        */
    }

    public static function getHmArticleSeriesOptions() {
        /*
            I am super tired and cannot seem to get model relations working for thie Article...doing a lookup and returning optins this way I guess...
        */
        $seriesList = \GinoPane\BlogTaxonomy\Models\Series::all();
        $seriesAsOptions = [];
        foreach ($seriesList as $i => $s) {
            $seriesAsOptions[$i+1] = $s->title;
        }
        return $seriesAsOptions;
    }

    /**
     * lookup the post related to this article, if no post
     *  found create Article and append it to the passed Post model
     *
     * @param Post $post
     * @return Article
     */
    public static function getBlogPost($post) {

        if ($post->article) {
            return $post->article;
        }

        // else
        $article = new Article;
        $article->post = $post;
        $article->save();

        $post->$article = $article;

        return $article;

    }

    public static function getCountOfArticlesBySlugAndDate($slug, $date)
    {
        $count = Article::join('rainlab_blog_posts', 'scs_newsapi_articles.post_id', '=', 'rainlab_blog_posts.id')
            ->where('rainlab_blog_posts.slug', '=', $slug)
            ->where('scs_newsapi_articles.published_at', '=', $date)
            ->count();
        return $count;
    }
}
