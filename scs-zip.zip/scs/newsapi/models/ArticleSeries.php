<?php namespace SCS\NewsAPI\Models;

use Model;

/**
 * Model
 */
class ArticleSeries extends Model
{
    use \October\Rain\Database\Traits\Validation;
    
    /*
     * Disable timestamps by default.
     * Remove this line if timestamps are defined in the database table.
     */
    public $timestamps = false;


    /**
     * @var string The database table used by the model.
     */
    public $table = 'scs_newsapi_article_series';

    /**
     * @var array Validation rules
     */
    public $rules = [
    ];
}
