<?php
if ($record->featured_images && count($record->featured_images) > 0) {
  $image_path = $record->featured_images[0]->getThumb(600,338);
} else if ($value) {
  // we have a value for external image
  $image_path = $value;
} else {
  // $image_path = strtolower("https://osdb-assets.s3.us-west-2.amazonaws.com/images/logo-osdb-2-white.svg");
  $image_path = strtolower("//dummyimage.com/600x338/4e1fcf/FFF.png&text=600x338+16:9");
}
?>
<img style="width:auto;max-width:95%;max-height:50px;" src="<?= $image_path ?>" />
