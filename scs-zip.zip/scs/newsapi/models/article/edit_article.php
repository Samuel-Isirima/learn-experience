<?php if (isset($value)): ?>
    <p style="">
    <a href="/backend/scs/newsapi/article/update/<?= $value ?>" target="_blank" class="btn btn-default">Edit Related Article</a>
    <span style="color:grey;font-size:smaller;">[ article id: <?= $value ?> ]</span>
    <span style="color:grey;font-size:smaller;">[ article source: <?= $model->article->source ? $model->article->source : '___' ?> ]</span>
    </p>
<?php endif ?>
