<?php
if ($value) {

echo("<p>".$value->title."</p>");

} else {

    echo("<p>"."-"."</p>");
}
?>
