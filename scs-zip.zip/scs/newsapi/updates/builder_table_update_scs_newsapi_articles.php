<?php namespace SCS\NewsAPI\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableUpdateScsNewsapiArticles extends Migration
{
    public function up()
    {
        Schema::table('scs_newsapi_articles', function($table)
        {
            $table->boolean('use_image')->default(0);
        });
    }
    
    public function down()
    {
        Schema::table('scs_newsapi_articles', function($table)
        {
            $table->dropColumn('use_image');
        });
    }
}
