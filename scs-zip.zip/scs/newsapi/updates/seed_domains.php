<?php namespace SCS\NewsAPI\Updates;

use Schema;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;
use SCS\NewsAPI\Models\Domain;

class SeedDomains extends Migration
{
    public function up()
    {
        Domain::create(['id' => 1, 'domain' => 'espn.com', 'name' => 'ESPN' ]);
        Domain::create(['id' => 2, 'domain' => 'usatoday.com', 'name' => 'USA Today' ]);
        Domain::create(['id' => 3, 'domain' => 'forbes.com', 'name' => 'Forbes' ]);
        Domain::create(['id' => 4, 'domain' => 'yahoo.com', 'name' => 'Yahoo' ]);
        Domain::create(['id' => 5, 'domain' => 'si.com', 'name' => 'Sports Illiustrated' ]);
        Domain::create(['id' => 6, 'domain' => 'cbssports.com', 'name' => 'CBS Sports' ]);
        Domain::create(['id' => 7, 'domain' => 'nbcsports.com', 'name' => 'NBC Sports' ]);
        Domain::create(['id' => 8, 'domain' => 'sportingnews.com', 'name' => 'Sporting News' ]);
        Domain::create(['id' => 9, 'domain' => 'skysports.com', 'name' => 'Sky Sports' ]);
        Domain::create(['id' => 10, 'domain' => 'sbnation.com', 'name' => 'SB Nation' ]);
        Domain::create(['id' => 11, 'domain' => 'mlb.com', 'name' => 'MLB' ]);
        Domain::create(['id' => 12, 'domain' => 'nba.com', 'name' => 'NBA' ]);
        Domain::create(['id' => 13, 'domain' => 'nfl.com', 'name' => 'NFL' ]);
        Domain::create(['id' => 14, 'domain' => 'ncaa.com', 'name' => 'NCAA' ]);
        Domain::create(['id' => 15, 'domain' => 'thebiglead.com', 'name' => 'The Big Lead' ]);
        Domain::create(['id' => 16, 'domain' => 'wnba.com', 'name' => 'WNBA' ]);
    }

    public function down()
    {
        for ($i = 1; $i <= 16; $i++) {
            Domain::destroy([$i]);
        }
    }
}
