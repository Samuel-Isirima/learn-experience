<?php namespace SCS\NewsAPI\Updates;

use Schema;
use DB;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;
use SCS\NewsAPI\Models\Article;

class AddPublishedAtArticlesTable extends Migration
{
    public function up()
    {
        Schema::table('scs_newsapi_articles', function($table)
        {
            $table->timestamp('published_at')->nullable();
        });
    }

    public function down()
    {
        Schema::table('scs_newsapi_articles', function($table)
        {
            $table->dropColumn('published_at');
        });
    }
}
