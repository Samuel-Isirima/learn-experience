<?php namespace SCS\NewsAPI\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class CreateScsNewsapiArticleSeries extends Migration
{
    public function up()
    {
        Schema::create('scs_newsapi_article_series', function($table)
        {
            $table->engine = 'InnoDB';
            $table->increments('id')->unsigned();
            $table->integer('article_id')->nullable(false)->default(0);
            $table->integer('series_id')->nullable(false)->default(0);
            $table->string('series_slug', 191)->nullable();
        });
    }

    public function down()
    {
        Schema::dropIfExists('scs_newsapi_article_series');
    }
}
