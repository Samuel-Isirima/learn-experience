<?php namespace WCU\Monitor\Updates;

use Schema;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;

class CreateArticlesTable extends Migration
{
    public function up()
    {
        Schema::create('scs_newsapi_articles', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->integer('post_id')->unsigned()->default(0)->index();
            $table->string('source')->nullable();
            $table->string('author')->nullable();
            $table->string('url')->nullable();
            $table->string('image_url')->nullable();
        });
    }

    public function down()
    {
        Schema::dropIfExists('scs_newsapi_articles');
    }
}
