<?php namespace SCS\NewsAPI\Updates;

use Schema;
use October\Rain\Database\Updates\Migration;

class BuilderTableUpdateScsNewsapiArticles2 extends Migration
{
    public function up()
    {
        Schema::table('scs_newsapi_articles', function($table)
        {
            $table->string('image_anchor_vert', 11)->nullable()->default('center');
            $table->string('image_anchor_horiz', 11)->nullable()->default('center');
        });
    }
    
    public function down()
    {
        Schema::table('scs_newsapi_articles', function($table)
        {
            $table->dropColumn('image_anchor_vert');
            $table->dropColumn('image_anchor_horiz');
        });
    }
}
