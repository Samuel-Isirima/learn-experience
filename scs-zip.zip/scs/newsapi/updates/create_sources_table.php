<?php namespace WCU\Monitor\Updates;

use Schema;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;

class CreateSourcesTable extends Migration
{
    public function up()
    {
        Schema::create('scs_newsapi_sources', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->string('id')->primary();
            $table->string('name')->nullable();
        });
    }

    public function down()
    {
        Schema::dropIfExists('scs_newsapi_sources');
    }
}
