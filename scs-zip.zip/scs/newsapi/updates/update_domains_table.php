<?php namespace SCS\NewsAPI\Updates;

use Schema;
use DB;
use October\Rain\Database\Schema\Blueprint;
use October\Rain\Database\Updates\Migration;
use SCS\NewsAPI\Models\Domain;

class UpdateDomainsTable extends Migration
{
    public function up()
    {
        Schema::table('scs_newsapi_domains', function($table)
        {
            $table->string('name')->nullable();
        });
    }

    public function down()
    {
        Schema::table('scs_newsapi_domains', function($table)
        {
            $table->dropColumn('name');
        });
    }
}
