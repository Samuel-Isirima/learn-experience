<?php namespace SCS\NewsAPI\Widgets;

use Input;
use Session;
use RainLab\Blog\Models\Post;
use SCS\NewsAPI\Classes\NewsAPIService;
use Backend\Classes\WidgetBase;
use SCS\NewsAPI\Models\Article;
use SCS\NewsAPI\Models\Domain;

class Field
{
    public $attributes;
    public $placeholder;
    public $name;
    public $id;
    public $options;
    public $value;
    public $selectedValues;
}

class NewsList extends WidgetBase
{
    public function fillDomains()
    {
        $items = Domain::all();
        $options = [];
        foreach ($items as $item) {
            $options[$item->domain] = $item->name;
        }
        $field = new Field;
        $field->placeholder = 'Select News Domain';
        $field->name = 'domain';
        $field->options = $options;
        $field->attributes = 'multiple="multiple"';
        $field->value = null;
        $field->selectedValues = ['forbes.com'];

        $this->vars['field'] = $field;
    }

    public function render()
    {
        $this->vars['articles'] = null;
        $this->fillDomains();
        return $this->makePartial('newslist');
    }

    public function onGetNewsFromAPI()
    {
        // TODO: add Source dropdown, date range fields
        // example query "baseball mlb nba nfl"
        $query = Input::get('query');
        $limit = Input::get('limit');
        $domain = Input::get('domain');
        $from = Input::get('from');
        $to = Input::get('to');
        if ($domain) {
            $domain = implode(',', $domain);
        }
        if ($from) {
            $from = explode(' ', $from)[0];
        }
        if ($to) {
            $to = explode(' ', $to)[0];
        }
        $articles = NewsAPIService::getNewsList($query, $domain, $from, $to, $limit);
        foreach ($articles as $article) {
            $slug = str_slug($article->title, "-");
            $date = $article->publishedAt;
            $exists = Article::getCountOfArticlesBySlugAndDate($slug, $date) > 0;
            $article->flags = $exists ? 'disabled="disabled" checked="checked"' : '';
        }
        $this->vars['articles'] = $articles;
        Session::put('articles', $articles);
    }

    public function onAddNewsToDB()
    {
        $items = Session::pull('articles', []);
        $all = Input::all();
        foreach ($all as $key => $value) {
            if (str_starts_with($key, 'checkbox_') && $value == 'on') {
                $parts = explode('_', $key);
                if (count($parts) == 2) {
                    $index = intval($parts[1]);
                    $item = $items[$index];
                    $post = Post::make();
                    $post->title = $item->title;
                    $post->slug = str_slug($item->title, "-");
                    $post->excerpt = $item->description;
                    $format_newlineToBr = preg_replace('/\\r\\n|\n|\r/', "<br/>", $item->content);
                    $basicFormatting = $format_newlineToBr;
                    $post->content = $basicFormatting;
                    $post->forceSave();
                    $article = Article::getBlogPost($post);
                    $article->source = $item->source->name;
                    $article->author = $item->author;
                    $article->url = $item->url;
                    $article->image_url = $item->urlToImage;
                    $article->use_image = $item->urlToImage ? true : false;
                    $datetime = new \DateTime($item->publishedAt);
                    $article->published_at = $datetime;
                    $article->forceSave();
                }
            }
        }
        $this->fillDomains();
        \Flash::success('News added successfully.');
    }
}
