<?php
$break = 1;

var_dump($this);

/*


<div class="form-group span-left">
                <label>Domains</label>
                <select
                        id="<?= $field->id ?>"
                        name="<?= $field->name ?>[]"
                        class="form-control custom-select"
                    <?= $field->attributes ?>>
                    <?php if ($field->placeholder): ?>
                    <option value="" disabled><?= $field->placeholder ?></option>
                    <?php endif ?>
                    <?php foreach ($fieldOptions as $value => $option): ?>
                        <?php
                                    if (!is_array($option)) $option = [$option];
                                ?>
                        <option selected="selected"

                        <?= in_array($value, $selectedValues)  ? 'selected="selected"' : '' ?>
                        value="<?= $value ?>">
                        <?= $option[0] ?>
                        </option>
                    <?php endforeach ?>
                </select>
            </div>

<?php
 //$series = __SELF__.series
?>

{% if series | length %}
    <div class="list-group">
        {% for item in series %}
            <a href="{{ item.url }}" class="list-group-item">
                {{ item.title }}
            </a>
        {% endfor %}
    </div>
{% else %}
    {{ "ginopane.blogtaxonomy::lang.components.related_series.no_series_message" | trans }}
{% endif %}

*/
?>
