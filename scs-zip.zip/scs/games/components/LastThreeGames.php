<?php namespace SCS\Games\Components;

use Cms\Classes\ComponentBase;
use SCS\Osdb\classes\ES\Games;

class LastThreeGames extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'Last (3) Games Component',
            'description' => 'show last (3) games'
        ];
    }

    public function defineProperties()
    {
        return [ ];
    }

    public $lastgames;
    protected $_limit;
    protected $_teamslug;

    public function onRender()
    {
        $this->_teamslug = $this->page['teamslug'] = $this->property('teamslug');
        $this->_limit = $this->page['limit'] = $this->property('limit');

        $this->lastgames = $this->page['lastgames'] = $this->getlastGames($this->_teamslug, $this->_limit);
    }

    public function getlastGames($teamslug, $limit) {

         $games = Games::getLastGames($teamslug, $limit);

         $rtnGames = array();
         foreach ($games as $game)
         {
            $homepoints = array_get($game, 'home.points');
            $awaypoints = array_get($game, 'away.points');

            if( array_get($game, 'home.slug') == $teamslug)
            {
                $opponentSlug = array_get($game, 'away.slug');
                $gameIdx = array(
                            "opponent" => [
                                "slug" => $opponentSlug,
                                "name" => array_get($game, 'away.name'),
                                "logo" => "https://osdb-assets.s3.us-west-2.amazonaws.com/images/league/". strtolower(array_get($game, 'league.alias')) . "/". $opponentSlug ."/logo-light.svg"
                        ]);

                if( $homepoints > $awaypoints )
                {
                    $gameIdx["result"] = "W";
                }
                else if( $homepoints < $awaypoints )
                {
                    $gameIdx["result"] = "L";
                }
                else
                {
                    $gameIdx["result"] = "T";
                }

            }
            else
            {
                $opponentSlug = array_get($game, 'home.slug');

                $gameIdx = array(
                            "opponent" => [
                                "slug" => $opponentSlug,
                                "name" => array_get($game, 'home.name'),
                                "logo" => "https://osdb-assets.s3.us-west-2.amazonaws.com/images/league/". strtolower(array_get($game, 'league.alias')) . "/". $opponentSlug ."/logo-light.svg"
                        ]);

                if( $homepoints < $awaypoints )
                {
                    $gameIdx["result"] = "W";
                }
                else if( $homepoints > $awaypoints )
                {
                    $gameIdx["result"] = "L";
                }
                else
                {
                    $gameIdx["result"] = "T";
                }
            }

            $gameIdx["scheduled"] = array_get($game, 'scheduled');
            $gameIdx["home"]["points"] = $homepoints;
            $gameIdx["away"]["points"] = $awaypoints;

            array_push($rtnGames, $gameIdx);
         }

         return $rtnGames;
    }
}
