<?php namespace SCS\Games\Components;

use Cms\Classes\ComponentBase;
use SCS\Osdb\classes\ES\Games;
use SCS\Osdb\Classes\ES\Leagues;
use SCS\Osdb\Models\Player;

class TopPerformers extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'Game Top Performers component',
            'description' => 'Shows information about game top performers'
        ];
    }

    public function defineProperties()
    {
        return [ ];
    }

    public $players;

    protected $_gameId;
    protected $_league;

    public function onRender()
    {
        $this->_league = $this->page['league'] = $this->property('league');
        $this->_gameId = $this->page['gameId'] = $this->property('gameId');

        $this->players = $this->page['players'] = $this->getTopPerformers($this->_league, $this->_gameId);
    }

    public function getTopPerformers($league, $gameId) {

        // TODO hardcode leagues WILL NOT WORK -RWC
        // TODO: also filters should not be hardcoded, should be placed into taxonomy
        $statList = [];
        switch ($this->_league) {
            case 'nfl':
                $filter_stat = 'player.statistics_nfl.receiving.touchdowns';
                $statList['TD'] = 'statistics_nfl.receiving.touchdowns';
                $statList['PASS YDS'] = 'statistics_nfl.passing.yards';
                $statList['RUSH YDS'] = 'statistics_nfl.rushing.yards';
                break;
            case 'nba':
                $filter_stat = 'player.statistics_nba.points';
                $statList['PTS'] = 'statistics_nba.points';
                $statList['AST'] = 'statistics_nba.assists';
                $statList['REB'] = 'statistics_nba.rebounds';
                break;
            case 'mlb':
                $filter_stat = 'player.statistics_mlb.hitting.overall.onbase.hr';
                $statList['HR'] = 'hitting.overall.onbase.hr'; // Home Runs
                $statList['ERA'] = 'pitching.overall.era'; // Earned Run Average
                $statList['AVG'] = 'hitting.overall.avg'; // Batting Average
                break;
            default:
                \Log::error('~~ TopPerformers->getTopPerformers - invalid top performers league lookup: ' . $this->_league);
                return \Redirect::to('404')->with('message', 'Cannot find that league');
            /* NOTE: using redirect instead of error for better UX
                >>> throw new \ApplicationException('Cannot find that league '.$this->_league);
            */
        }

        $players = Games::getGameTopPerformers($league, $gameId, $filter_stat, 3);
        $dbPlayers = Player::whereIn('guid', array_column($players, 'id'))->select('guid', 'custom_headshot', 'slug')->get()->all();
        $players = Leagues::addCustomHeadshotUrl($players, $dbPlayers);
        foreach ($players as &$player){
            $player['stats'] = [];
            foreach ($statList as $key => $value) {
                $player['stats'][$key] = intval(array_get($player, $value));
            }
        }
        return $players;
    }

 }
