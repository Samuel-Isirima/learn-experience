<?php namespace SCS\Games\Components;

use Cms\Classes\ComponentBase;
use SCS\Osdb\classes\ES\Games;

class GameSeriesInfo extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'Game Series Info component',
            'description' => 'Shows information about game series for game'
        ];
    }

    public function defineProperties()
    {
        return [ ];
    }

    public $games;
    public $info;

    protected $_seriesId;
    protected $_league;

    public function onRender()
    {
        $this->_league = $this->page['league'] = $this->property('league');
        $this->_seriesId = $this->page['seriesId'] = $this->property('seriesId');

        $this->games = $this->page['games'] = $this->getGamesInSeries($this->_league, $this->_seriesId);
        $this->info = $this->page['info'] = $this->getGameSeriesInfo($this->games);
    }

    public function getGamesInSeries($league, $seriesId) {

        $games = Games::getGamesInSeries($league, $seriesId);
        return $games;
    }

    public function getGameSeriesInfo($games)
    {
        $team1 = [ 'id' => null, 'alias' => null, 'wins' => 0];
        $team2 = [ 'id' => null, 'alias' => null, 'wins' => 0];
        foreach ($games as $game){
            if ($team1['id'] == null){
                $team1['alias'] = $game['home']['alias'];
                $team1['id'] = $game['home']['id'];
                $team2['alias'] = $game['away']['alias'];
                $team2['id'] = $game['away']['id'];
            }
            if ($game['home_points'] && $game['away_points'] && $game['home_team'] && $game['away_team']){
                if ($game['home_points'] > $game['away_points']) {
                    if ($game['home_team'] == $team1['id']) $team1['wins']++;
                    else $team2['wins']++;
                }
                else if ($game['home_points'] < $game['away_points']){
                    if ($game['away_team'] == $team1['id']) $team1['wins']++;
                    else $team2['wins']++;
                }
            }
        }
        $team1Wins = $team1['wins'];
        $team2Wins = $team2['wins'];
        if ($team1Wins == $team2Wins) return "TIED SERIES $team1Wins-$team1Wins";
        if ($team1Wins > $team2Wins) return $team1['alias']." WINS SERIES $team1Wins-$team2Wins";
        return $team2['alias']." WINS SERIES $team2Wins-$team1Wins";
    }
}
