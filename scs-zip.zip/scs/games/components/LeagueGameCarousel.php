<?php namespace SCS\Games\Components;

use Cms\Classes\ComponentBase;
use SCS\Osdb\classes\ES\Games;

class LeagueGameCarousel extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'League Games Carousel component',
            'description' => 'Shows league games'
        ];
    }

    public function defineProperties()
    {
        return [
            'league' => [
                'title' => '(dynamic) League is set by URL of the page',
                'type' => 'string',
            ],
            'limit' => [
                'title' => 'number of games to fetch',
                'type' => 'string',
                'default' => '6',
            ],
            'gamesPage' => [
                'title' => 'for pagination of games',
                'type' => 'string',
                'default' => '{{ :page }}',
            ],
        ];
    }

    public $games;
    protected $_limit;
    protected $_league;

    public function onRender()
    {
        $this->_league = $this->page['league'] = $this->property('league');
        $this->_limit = $this->page['limit'] = $this->property('limit');
        $this->games = $this->page['games'] = $this->getGames($this->_league, $this->_limit);
    }

    public function getGames($league, $limit) {

        //$startDate = date('Y-m-d H:i:s', strtotime('-2 days'));
        $games = Games::getGameList($league, null, "now-2d", null);
        // TODO: move into tables? Is this required?
        foreach ($games as &$game) {
            // NOTE: league slugs are coming dynamically from the URL, this switch is okay in v1.0 but will need to be manually updated for additional leagues
            switch ($this->property('league')){
                case 'mlb':
                    $game['sr_match_id'] = $game['match_id'];
                    break;
                case 'nba':
                    $game['sr_match_id'] = $game['match_id'];
                    break;
                case 'nfl':
                    $game['sr_match_id'] = 'sd:match:'.$game['id'];
                    break;
            }
            if (!isset($game['sr_match_id']) || empty($game['sr_match_id'])) {
                \Log::error('~~ LeagueGameCarousel - no match_id for '.$this->property('league').': '.$game['id']);
            }
        }
        // TODO: explore using a curl GET for these matches, storing in cache if possible
        return $games;
    }
}
