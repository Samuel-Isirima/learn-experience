<?php namespace SCS\Games\Components;

use Cms\Classes\ComponentBase;
use SCS\Osdb\classes\ES\Games;

class NextThreeGames extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'Next (3)  Games Component',
            'description' => 'show the (3) next games'
        ];
    }

    public function defineProperties()
    {
        return [ ];
    }

    public $nextgames;
    protected $_limit;
    protected $_teamslug;

    public function onRender() {
        $this->_teamslug = $this->page['teamslug'] = $this->property('teamslug');
        $this->_limit = $this->page['limit'] = $this->property('limit');

        $this->nextgames = $this->page['nextgames'] = $this->getNextGames($this->_teamslug, $this->_limit);
    }

    public function getNextGames($teamslug, $limit)
    {

         $games = Games::getNextGames($teamslug, $limit);

         $rtnGames = array();
         foreach ($games as $game)
         {
            if( array_get($game, 'home.slug') == $teamslug)
            {
                $opponentSlug = array_get($game, 'away.slug');
                $gameIdx = array(
                            "opponent" => [
                                "slug" => $opponentSlug,
                                "name" => array_get($game, 'away.name'),
                                "logo" => "https://osdb-assets.s3.us-west-2.amazonaws.com/images/league/". strtolower(array_get($game, 'league.alias')) . "/". $opponentSlug ."/logo-light.svg"
                        ]);
            }
            else
            {
                $opponentSlug = array_get($game, 'home.slug');

                $gameIdx = array(
                            "opponent" => [
                                "slug" => $opponentSlug,
                                "name" => array_get($game, 'home.name'),
                                "logo" => "https://osdb-assets.s3.us-west-2.amazonaws.com/images/league/". strtolower(array_get($game, 'league.alias')) . "/". $opponentSlug ."/logo-light.svg"
                        ]);
            }

            $gameIdx["scheduled"] = array_get($game, 'scheduled');

            array_push($rtnGames, $gameIdx);
         }

         return $rtnGames;

    }
}
