<?php namespace SCS\Games;

use Backend;
use System\Classes\PluginBase;

class Plugin extends PluginBase
{

    public function pluginDetails()
    {
        return [
            'name'        => 'Games',
            'description' => 'Handles display of game data',
            'author'      => 'SCS',
            'icon'        => 'icon-cube'
        ];
    }

    public function register() {}

    public function boot() {}

    public function registerComponents()
    {
        return [
            'SCS\Games\Components\NextThreeGames' => 'nextThreeGames',
            'SCS\Games\Components\LastThreeGames' => 'lastThreeGames',
            'SCS\Games\Components\LeagueGameCarousel' => 'leagueGameCarousel',
            'SCS\Games\Components\GameSeriesInfo' => 'gameSeriesInfo',
            'SCS\Games\Components\TopPerformers' => 'gameTopPerformers',
        ];
    }

    public function registerPermissions()
    {
        return [];
    }

    public function registerNavigation()
    {
        return [];
    }

    public function registerMarkupTags() {
        return [
            'filters' => [
                'status' => [$this, 'getStatus']
            ]
        ];
    }

    public function getStatus($game)
    {
        // TODO: in progress
        switch ($game['status']){
            case "closed":
                return "FINAL";
            case "delayed":
                return "DLYD";
            case "postponed":
                return "PPD";
            case "canceled":
                return "CXLD";
            case "scheduled":
                return $game['scheduled'];
            default: return null;
        }
    }
}
