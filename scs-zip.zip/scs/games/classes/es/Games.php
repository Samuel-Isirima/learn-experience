<?php namespace SCS\games\classes\ES;

use SCS\Osdb\Classes\Services\ElasticsearchService;

class Games
{
    protected static $index = 'games';

    public static function getById($id)
    {
        $result = ElasticsearchService::instance()->get(static::$index, $id);
        
        return $result;
    }

    
    public static function getLastGames($teamSlug, $limit = 3)
    {
        $jsonQuery =   '{"sort" : [{"scheduled": "desc"}],
                        "query":
                        {
                          "bool":
                          {
                          "must":[
                              {
                                "term":{"status":"closed"}
                              },
                              {
                                "bool":{
                                "should":[{"term":{"home.slug":"'. $teamSlug .'"}},
                                          {"term":{"away.slug":"'. $teamSlug .'"}}]      
                                }
                              }
                            ]
                          }
                        }}';
        
       //echo($jsonQuery);

        $response = ElasticsearchService::instance()->match_jsonQuery(static::$index, json_decode($jsonQuery), $limit);

        $result = [];
        foreach ($response['hits']['hits'] as $item){
            $result[] = $item['_source'];
        }
        return $result;
    }

    public static function getNextGames($teamSlug, $limit = 3)
    {

        $jsonQuery =   '{"sort" : [{"scheduled": "desc"}],
                        "query":
                        {
                          "bool":
                          {
                          "must":[
                              {
                                "range":{"scheduled":
                                          {"gte":"now"}
                                }
                              },
                              {
                                "bool":{
                                "should":[{"term":{"home.slug":"'. $teamSlug .'"}},
                                          {"term":{"away.slug":"'. $teamSlug .'"}}]      
                                }
                              }
                            ]
                          }
                        }}';
        
       //echo($jsonQuery);

        $response = ElasticsearchService::instance()->match_jsonQuery(static::$index, json_decode($jsonQuery), $limit);

        $result = [];
        foreach ($response['hits']['hits'] as $item){
            $result[] = $item['_source'];
        }
        return $result;
    }
}
