<?php

use Cms\Classes\Page;
use SCS\Osdb\Classes\ES\Players;
use SCS\Osdb\Classes\ES\Teams;
use SCS\Osdb\Controllers\Player;

Route::get('api/widgets/get-player-url', function () {
    $id = $_REQUEST['id'] ?? null;
    if (null === $id) {
        return null;
    }
    $player = Players::getPlayerByWidgetPlayerId($id);
    if (isset($player)) {
        return ['result' => Page::url('player', [
            'leagueSlug' => strtolower($player['league']['alias']),
            'playerName' => Player::encodeName($player['full_name']),
                'slug' => $player['slug']
        ])];
    }
    return null;
});

Route::get('api/widgets/get-team-url', function () {
    $id = $_REQUEST['id'] ?? null;
    if (null === $id) {
        return null;
    }
    $team = Teams::getTeamByWidgetTeamId($id);
    if (isset($team)) {
        return ['result' => Page::url('team', [
            'leagueSlug' => strtolower($team['league']['alias']),
            'slug' => $team['slug']
        ])];
    }
    return null;
});
