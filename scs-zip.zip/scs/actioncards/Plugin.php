<?php namespace SCS\ActionCards;

use Backend;
use System\Classes\PluginBase;

class Plugin extends PluginBase
{

    public function pluginDetails()
    {
        return [
            'name'        => 'ActionCards',
            'description' => 'Teams and/or Players action cards',
            'author'      => 'SCS',
            'icon'        => 'icon-cube'
        ];
    }

    public function register() {}

    public function boot() {}

    public function registerComponents()
    {
        return [
            'SCS\ActionCards\Components\Section' => 'actionCardsSection'
        ];
    }

    public function registerPermissions()
    {
        return [];
    }

    public function registerNavigation()
    {
        return [];

    }

    public function registerMarkupTags() {
        return [
            'filters' => [
                'ordinal' => [$this, 'getOrdinal']
            ]
        ];
    }

    public function getOrdinal($number)
    {
        $ends = array('th','st','nd','rd','th','th','th','th','th','th');
        if ((($number % 100) >= 11) && (($number%100) <= 13))
            return 'TH';
        else
            return strtoupper($ends[$number % 10]);
    }
}
