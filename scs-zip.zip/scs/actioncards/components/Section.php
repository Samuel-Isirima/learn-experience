<?php namespace SCS\ActionCards\Components;

use Cms\Classes\ComponentBase;
use Cms\Classes\Page;
use SCS\Osdb\Classes\ES\Leagues;
use SCS\Osdb\Classes\ES\TeamSeasons;
use SCS\Osdb\Classes\ES\Players;
use SCS\Osdb\Classes\ES\Teams;
use SCS\Osdb\Models\Player;
use SCS\Osdb\Models\League;
use SCS\Osdb\Models\Team;

class Section extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name'        => 'Action cards section',
            'description' => 'Teams and/or Players action cards section'
        ];
    }

    public function defineProperties()
    {
        return [
            'content' => [ 'title' => 'content', 'type' => 'string', 'default' => null ],
            'league' => [ 'title' => 'league', 'type' => 'string', 'default' => null ],
            'team' => [ 'title' => 'team', 'type' => 'string', 'default' => null ],
            'limit' => [ 'title' => 'limit', 'type' => 'integer', 'default' => 7 ],
        ];
    }

    public function init()
    {

    }

    // Mapped properties
    public $_content;
    public $_league;
    public $_team;
    public $_limit;

    public $teamSeasonList;
    public $featuredPlayers;

    public function onRun()
    {
        $this->_content = $this->property('content');
        $this->_league = $this->property('league');
        $this->_team = $this->property('team');
        $this->_limit = $this->property('limit');

        if (empty($this->_content) || $this->_content == 'team') {
            // TODO: use properties for filtration
            $this->teamSeasonList = $this->page['teamSeasonList'] = $this->getTeamSeasonListInternal($this->_league, $this->_limit);
        }
        if ($this->_content != 'team') {
            // TODO: use properties for filtration
            $this->players = $this->page['players'] = $this->getPlayersInternal($this->_league, $this->_team, $this->_limit);
        }
    }

    public function getTeamSeasonListInternal($league = null, $limit = 7)
    {
        $year = date("Y");
        $featuredTeamIds = Team::isFeatured()->pluck('guid')->toArray();

        $teams = [];
        // we need a varietty of teams from all leagues
        $leagues = League::pluck('slug')->toArray();
        foreach ($leagues as $key => $l) {
            $teams[($l)] = TeamSeasons::getTeamSeasonRankingList($l, $featuredTeamIds, 3);
        }

        // No featured teams
        if (!empty($featuredTeamIds) && empty($teams)) {
            // $teams = TeamSeasons::getList($league, $year, [], $limit);
            // $teams = TeamSeasons::getTeamSeasonRankingList($league, [], $limit);
            foreach ($leagues as $key => $l) {
                $teams[$l] = TeamSeasons::getTeamSeasonRankingList($l, [], 3);
            }
        }
        return $teams;
    }

    public function getPlayersInternal($league = null, $team = null, $limit = 7)
    {
        return $this->getHomepagePlayersInternal($league , $team , $limit );
    }


    public function getHomepagePlayersInternal($league = null, $team = null, $limit = 7)
    {
        $players_limit = 99; // client asked for increase in featured players, this will remove the 7 player cap

        // if team
        if (!empty($team)) {
            $esTeam = Teams::getBySlug($team);
            $ids = [];

            if ($esTeam) {
                foreach ($esTeam['players'] as $player) {
                    if (!array_key_exists('active', $player) || $player['active'])
                        $ids[] = $player['id'];
                }
            }
            $result = Leagues::getPlayers(null, $team, $ids, null, true);
            $dbPlayers = Player::whereIn('guid', array_column($result, 'id'))->select('guid', 'custom_headshot', 'slug')->get()->all();
            $result = Leagues::addCustomHeadshotUrl($result, $dbPlayers);
            return $result;
        }

        // if league
        if (!empty($league)) {
            $dbFeaturedPlayers = Player::isFeatured()->orderBy('updated_at', 'desc')->select('guid', 'custom_headshot', 'slug')->get()->all();
            $featuredPlayerIds = array_column($dbFeaturedPlayers, 'guid');
            if (!empty($featuredPlayerIds)) {
                $featuredPlayers = Leagues::getPlayers($league, null, $featuredPlayerIds, $players_limit);
                $featuredPlayers = Leagues::addCustomHeadshotUrl($featuredPlayers, $dbFeaturedPlayers);
            } else {
                $featuredPlayers = [];
            }
            $featuredPlayersCount = count($featuredPlayers);

            // if we have less than 7 players for this league get more for this league from random teams
            if ($featuredPlayersCount < $limit) {
                $_league = League::where('slug', $league)->first();
                $getTeams = Team::where('league_guid', $_league->guid)->inRandomOrder()->take($limit - $featuredPlayersCount)->get();
                $dbPlayers = [];
                foreach ($getTeams as $team) {
                    $esTeam = Teams::getBySlug($team->slug);
                    $ids = [];
                    if (!isset($esTeam) || !array_key_exists('players', $esTeam)) {
                        continue;
                    }
                    foreach ($esTeam['players'] as $player) {
                        if (!array_key_exists('active', $player) || $player['active']) $ids[] = $player['id'];
                    }
                    $dbPlayers[] = Player::isFeatured(0)
                        ->where('team_guid', $team->guid)
                        ->whereIn('guid', $ids)
                        ->orderBy('updated_at', 'desc')
                        ->select('guid', 'custom_headshot', 'slug')->first();
                }
                $playerIds = array_column($dbPlayers, 'guid');
                $nonFeaturedPlayers = Leagues::getPlayers($league, null, $playerIds);
                $nonFeaturedPlayers = Leagues::addCustomHeadshotUrl($nonFeaturedPlayers, $dbPlayers);
                $featuredPlayers = array_merge($featuredPlayers, $nonFeaturedPlayers);
            }
            return $featuredPlayers;
        }

        $dbFeaturedPlayers = Player::isFeatured()->orderBy('updated_at', 'desc')->select('guid', 'custom_headshot', 'slug')->get()->all();
        $featuredPlayerIds = array_column($dbFeaturedPlayers, 'guid');
        if (!empty($featuredPlayerIds)) {
            $featuredPlayers = Leagues::getPlayers(null, null, $featuredPlayerIds, $players_limit);
            $featuredPlayers = Leagues::addCustomHeadshotUrl($featuredPlayers, $dbFeaturedPlayers);
        } else {
            $featuredPlayers = [];
        }
        $featuredPlayersCount = count($featuredPlayers);

        if ($featuredPlayersCount < $limit) {
            $getTeams = Team::inRandomOrder()->take($limit - $featuredPlayersCount)->get();
            $dbPlayers = [];
            foreach ($getTeams as $team) {
                $dbPlayers[] = Player::isFeatured(0)->where('team_guid', $team->guid)->orderBy('updated_at', 'desc')->select('guid', 'custom_headshot', 'slug')->first();
            }
            $playerIds = array_column($dbPlayers, 'guid');
            $nonFeaturedPlayers = Leagues::getPlayers($league, null, $playerIds);
            $nonFeaturedPlayers = Leagues::addCustomHeadshotUrl($nonFeaturedPlayers, $dbPlayers);
            $featuredPlayers = array_merge($featuredPlayers, $nonFeaturedPlayers);
        }
        return $featuredPlayers;
    }

    // function onGetPlayerGuid(){
    /**
     * @deprecated use API method /api/widgets/get-player-url which allows to get player url on pages without the plugin
     * @return string|null
     */
    function onGetPlayerUrl(){
        $id = post('id');
        if (null === $id) {
            return null;
        }
        $player = Players::getPlayerByWidgetPlayerId($id);
        if (isset($player)) {
            return Page::url('player', [
                'leagueSlug' => strtolower($player['league']['alias']),
                'playerName' => \SCS\Osdb\Controllers\Player::encodeName($player['full_name']),
                'slug' => $player['slug']
            ]);
        }
        return null;
    }

    /**
     * @deprecated use API method /api/widgets/get-team-url which allows to get team url on pages without the plugin
     * @return string|null
     */
    function onGetTeamUrl()
    {
        $id = post('id');
        if (null === $id) {
            return null;
        }
        $team = Teams::getTeamByWidgetTeamId($id);
        if (isset($team)) {
            return Page::url('team', [
                'leagueSlug' => strtolower($team['league']['alias']),
                'slug' => $team['id']
            ]);
        }
        return null;
    }
}
